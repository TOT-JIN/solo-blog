title: LAMP--5.测试 php 解析
date: '2017-10-04 21:49:27'
updated: '2017-10-04 21:49:27'
tags: [lamp, php]
permalink: /articles/2017/10/04/1507124967673.html
---
# LAMP--5.测试 php 解析
```e-bash
[root@localhost php-5.6.10]# vim /usr/local/apache2/htdocs/1.php
<?php
    echo "php works.";
?>
```



保存后，继续测试：

```e-bash
[root@localhost php-5.6.10]# curl localhost/1.php
php works.
```



php works. 只有显示这个信息，才算正常解析。否则就是没有成功解析。当然，也可以用真机上的浏览器通过 ip 访问，比如虚拟机ip为192.168.56.128，那么在浏览器输入 http://192.168.56.128/1.php 看是否只显示一行 php works。如果访问不太顺利，检测 iptables 规则。
