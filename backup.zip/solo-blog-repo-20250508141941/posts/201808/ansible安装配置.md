title: ansible 安装配置
date: '2018-08-02 07:11:44'
updated: '2018-08-02 07:11:44'
tags: [ansible, 自动化运维]
permalink: /articles/2018/08/02/1533165104832.html
---
# ansible 安装配置
## 一、安装ansible

&emsp;&emsp;准备两台机器 192.168.56.128  192.168.56.133

&emsp;&emsp;只需在133上安装ansible即可

&emsp;&emsp;安装epel扩展源

```
[root@server ~]# yum install -y epel-release
```


&emsp;&emsp;安装ansible

```
[root@server ~]# yum install -y ansible
```


## 二、ansible 配置密钥

&emsp;&emsp;133 上生成密钥对

&emsp;&emsp;使用 ssh-keygen -t rsa 命令生成，这里不去设置密钥密码

```
[root@server ~]# ssh-keygen -t rsa

Generating public/private rsa key pair.

Enter file in which to save the key (/root/.ssh/id_rsa):          //输入保存私钥的路径，不输入直接回车选用括号中的路径

Created directory '/root/.ssh'.

Enter passphrase (empty for no passphrase):                        //设置一个私钥的密码，这里为空了

Enter same passphrase again:

Your identification has been saved in /root/.ssh/id_rsa.

Your public key has been saved in /root/.ssh/id_rsa.pub.

The key fingerprint is:

d4:5c:9c:36:41:42:b2:a2:fa:4f:54:c0:5c:d0:52:91 root@server

The key's randomart image is:

+--[ RSA 2048]----+

|     oo==+oo+o   |

|      +.E= o=    |

|      ..+ o. .   |

|     . +         |

|    . . S        |

|   . .           |

|  .   .          |

|   . .           |

|    ...          |

+-----------------+
```


&emsp;&emsp;去对应目录里查看一下

```
[root@server ~]# ls -la /root/.ssh/

总用量 16

drwx------  2 root root 4096 7月  10 22:24 .

dr-xr-x---. 4 root root 4096 7月  10 22:23 ..

-rw-------  1 root root 1675 7月  10 22:24 id_rsa

-rw-r--r--  1 root root  393 7月  10 22:24 id_rsa.pub
```

&emsp;&emsp;把公钥中的内容分别拷贝到服务端和客户端中，以客户端为例：

```
[root@server ~]# cat /root/.ssh/id_rsa.pub

ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAoy3POadrIGR4W3FFq+b3Gb+VRdJphHn83Jrags9pdzngusHIduxD+zDavkok/C2tgiQgtEfth9wftsOBCSiglUMVXJ0S2YEUx6PvQtd5DDPS57PKYV7LFr31JD980Y6jIrE7mr0FJ1TdapIrUn2Oj6mfsgYOmOXQFcBLqo4dDwsx983rC/l6svDAswpYxTR0f1ADeZLKFKddn4gRt3j5DRWgEXvpl6nNCa303SlqOVdUp2Yz5izwNd/n1GmLvdnZeGVpNdVB9y6ikxPJfOKAH4JTxRHDHOhWImPhgMJuNjYsggFBe1xVe53S54Dl5eJeAxZG66sigKcVPtytIm8kWQ== root@server

[root@client ~]# vim /root/.ssh/authorized_keys

ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAoy3POadrIGR4W3FFq+b3Gb+VRdJphHn83Jrags9pdzngusHIduxD+zDavkok/C2tgiQgtEfth9wftsOBCSiglUMVXJ0S2YEUx6PvQtd5DDPS57PKYV7LFr31JD980Y6jIrE7mr0FJ1TdapIrUn2Oj6mfsgYOmOXQFcBLqo4dDwsx983rC/l6svDAswpYxTR0f1ADeZLKFKddn4gRt3j5DRWgEXvpl6nNCa303SlqOVdUp2Yz5izwNd/n1GmLvdnZeGVpNdVB9y6ikxPJfOKAH4JTxRHDHOhWImPhgMJuNjYsggFBe1xVe53S54Dl5eJeAxZG66sigKcVPtytIm8kWQ== root@server

```

&emsp;&emsp;验证一下

```
[root@server ~]# ssh client.test.com

The authenticity of host 'client.test.com (192.168.56.128)' can't be established.

RSA key fingerprint is 0d:d3:7e:b4:f9:e8:c0:56:ae:9e:c7:e1:97:50:87:b5.

Are you sure you want to continue connecting (yes/no)? yes

Warning: Permanently added 'client.test.com,192.168.56.128' (RSA) to the list of known hosts.

Last login: Sun Jul 10 22:12:32 2016 from 192.168.56.1

[root@client ~]#


[root@client ~]# exit

logout

Connection to client.test.com closed.

[root@server ~]#
```
