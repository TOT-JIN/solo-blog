title: puppet 安装和配置
date: '2018-06-02 12:41:24'
updated: '2018-06-02 12:41:24'
tags: [puppet, 自动化运维]
permalink: /articles/2018/06/02/1527428594832.html
---
# puppet 安装和配置
## 一、准备工作

&emsp;准备两台机器：192.168.56.128（客户端） 192.168.56.133（服务端）

&emsp;两台机器关闭selinux，清空iptables规则，保存

&emsp;设置 hostname

&emsp;128上hostname

```
[root@client ~]# vim /etc/sysconfig/network

NETWORKING=yes

HOSTNAME=client.test.com


         133上hostname

[root@server ~]# vim /etc/sysconfig/network

NETWORKING=yes

HOSTNAME=server.test.com
```


&emsp;编辑hosts文件，两台机器上都加入以下信息：

```
[root@client ~]# vim /etc/hosts

127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4

::1         localhost localhost.localdomain localhost6 localhost6.localdomain6

192.168.56.128 client.test.com

192.168.56.133 server.test.com

[root@server ~]# vim /etc/hosts

127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4

::1         localhost localhost.localdomain localhost6 localhost6.localdomain6

192.168.56.128 client.test.com

192.168.56.133 server.test.com
```


&emsp;测试一下：

```
[root@client ~]# ping server.test.com

PING server.test.com (192.168.56.133) 56(84) bytes of data.

64 bytes from server.test.com (192.168.56.133): icmp_seq=1 ttl=64 time=0.517 ms

64 bytes from server.test.com (192.168.56.133): icmp_seq=2 ttl=64 time=0.509 ms

^C

--- server.test.com ping statistics ---

2 packets transmitted, 2 received, 0% packet loss, time 1324ms

rtt min/avg/max/mdev = 0.509/0.513/0.517/0.004 ms

[root@client ~]# ping client.test.com

PING client.test.com (192.168.56.128) 56(84) bytes of data.

64 bytes from client.test.com (192.168.56.128): icmp_seq=1 ttl=64 time=0.084 ms

64 bytes from client.test.com (192.168.56.128): icmp_seq=2 ttl=64 time=0.048 ms

^C

--- client.test.com ping statistics ---

2 packets transmitted, 2 received, 0% packet loss, time 1132ms

rtt min/avg/max/mdev = 0.048/0.066/0.084/0.018 ms
```


&emsp;server端测试省略了

        

&emsp;两台机器上都安装ntpdate，并建立自动同步时间的任务计划：（server配置省略）

```
[root@client ~]# yum install -y ntp

[root@client ~]# crontab -e

*/10 * * * * ntpdate time.windows.com >/dev/null 2>&1
```


## 二、安装服务端

&emsp;在server上安装puppet源

```
[root@server ~]# rpm -ivh [http://yum.puppetlabs.com/el/6/products/x86_64/puppetlabs-release-6-7.noarch.rpm](http://yum.puppetlabs.com/el/6/products/x86_64/puppetlabs-release-6-7.noarch.rpm)

[root@server ~]# ls /etc/yum.repos.d/

CentOS-Base.repo       CentOS-Media.repo  epel-testing.repo

CentOS-Debuginfo.repo  CentOS-Vault.repo  puppetlabs.repo

CentOS-fasttrack.repo  epel.repo

//已经有了yum源了，yum list可以找到puppet相关包

[root@server ~]# yum clean all

[root@server ~]# yum makecache
```


&emsp;安装服务端程序

```
[root@server ~]# yum install -y puppet-server
```


&emsp;启动服务

```
[root@server ~]# service puppetmaster start

启动 puppetmaster：                                        [确定]
```


&emsp;开机启动

```
[root@server ~]# chkconfig puppetmaster on
```


## 三、安装客户端

&emsp;在client上

&emsp;安装puppet源

```
[root@client ~]# rpm -ivh [http://yum.puppetlabs.com/el/6/products/x86_64/puppetlabs-release-6-7.noarch.rpm](http://yum.puppetlabs.com/el/6/products/x86_64/puppetlabs-release-6-7.noarch.rpm)

[root@client ~]# yum clean all

[root@client ~]# yum makecache
```


&emsp;安装客户端程序

```
[root@client ~]# yum install -y puppet
```


&emsp;修改配置文件 /etc/puppet/puppet.conf 在最后添加如下语句：

```
[root@client ~]# vim /etc/puppet/puppet.conf

    server = server.test.com

    runinterval = 30       //主动更新，间隔30s

```
&emsp;启动服务
```
[root@client ~]# service puppet start

Starting puppet agent:                                     [确定]
```


&emsp;开机启动

```
[root@client ~]# chkconfig puppet on
```
