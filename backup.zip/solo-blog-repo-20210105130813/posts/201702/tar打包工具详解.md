title: tar 打包工具详解
date: '2017-02-01 16:29:49'
updated: '2017-02-01 16:29:49'
tags: [tar, Linux]
permalink: /articles/2017/02/01/1485937789856.html
---
# tar 打包工具详解
tar 本身为一个打包工具，可以把目录打包成一个文件，它的好处是把所有文件整合成一个大文件整体，便于拷贝或移动。

语法：tar [-zjxcvfpP] filename

tar 目录有多个选项：

-z：同时用gzip压缩

-j：同时用bzip2压缩

-x：解包或者解压缩

-t：查看 tar 包里面的文件

-c：建立一个 tar 包或者压缩文件包

-v：可视化

-f：后面跟文件名，压缩时跟“-f 文件名”，意思是压缩后的文件名为filename，解压时跟“-f 文件名”，意思是解压filename，为了避免错误识别，多个选项并用时，把 f 放在后面。

-p ：使用原文件的属性，压缩前什么属性压缩后还什么属性（不常用）

-P：可以使用绝对路径（不常用）

--exclude filename：在打包或者压缩时，不要将 filename 文件包括在内（不常用）

```e-bash
[root@localhost test]# mkdir test111
[root@localhost test]# touch test111/test2.txt
[root@localhost test]# echo "nihao">!$
echo "nihao">test111/test2.txt
[root@localhost test]# ls
test111  test.txt.xz
[root@localhost test]# tar -cvf test111.tar test111
test111/
test111/test2.txt
[root@localhost test]# ls
test111  test111.tar  test.txt.xz
```



**可以不加 -v 即不可视化。**

```e-bash
[root@localhost test]# rm -f test111.tar
[root@localhost test]# tar -cf test.tar test111 test.txt.xz
[root@localhost test]# ls
test111  test.tar  test.txt.xz
```



**解压包：**

```e-bash
[root@localhost test]# rm -rf test111
[root@localhost test]# ls
test.tar  test.txt.xz
[root@localhost test]# tar -xvf test.tar
test111/
test111/test2.txt
test.txt.xz
```



**--exclude 使用：**

```e-bash
[root@localhost test]# tar -cvf test111.tar --exclude test3.txt test111
test111/
test111/test2.txt
test111/test4.txt
test111/test5/
[root@localhost test]# rm -f test111.tar
[root@localhost test]# tar -cvf test111.tar --exclude test5 test111
test111/
test111/test2.txt
test111/test3.txt
test111/test4.txt
```



---

tar 打包和压缩并用

**tar命令支持gzip压缩和bzip2压缩以及xz。**

```e-bash
[root@localhost test]# tar -czvf test111.tar.gz test111
test111/
test111/test2.txt
test111/test3.txt
test111/test4.txt
test111/test5/
[root@localhost test]# ls
test111  test111.tar  test111.tar.gz  test.tar  test.txt.xz
```



**这里起主要作用的是 -z 选项，表示使用 gzip 压缩。“-tf“可以查看包或压缩包的文件列表：**

```e-bash
[root@localhost test]# tar -tf test111.tar.gz
test111/
test111/test2.txt
test111/test3.txt
test111/test4.txt
test111/test5/
```



**”-zxvf“用来解压 .tar.gz 的压缩包**

```e-bash
[root@localhost test]# rm -rf test111
[root@localhost test]# ls
test111.tar  test111.tar.gz  test.tar  test.txt.xz
[root@localhost test]# tar -zxvf test111.tar.gz
test111/
test111/test2.txt
test111/test3.txt
test111/test4.txt
test111/test5/
[root@localhost test]# ls
test111  test111.tar  test111.tar.gz  test.tar  test.txt.xz
```




**bzip2的压缩包使用”-cjvf“选项来实现**

```e-bash
[root@localhost test]# tar -cjvf test111.tar.bz2 test111
test111/
test111/test2.txt
test111/test3.txt
test111/test4.txt
test111/test5/
[root@localhost test]# ls
test111  test111.tar  test111.tar.bz2  test111.tar.gz  test.tar  test.txt.xz
[root@localhost test]# tar -tf test111.tar.bz2
test111/
test111/test2.txt
test111/test3.txt
test111/test4.txt
test111/test5/
```



**解压用”-jxvf“**

```e-bash
[root@localhost test]# rm -rf test111
[root@localhost test]# tar -jxvf test111.tar.bz2
test111/
test111/test2.txt
test111/test3.txt
test111/test4.txt
test111/test5/
[root@localhost test]# ls
test111  test111.tar  test111.tar.bz2  test111.tar.gz  test.tar  test.txt.xz
```




**打包使用 xz 的形式压缩与解压：**

```e-bash
[root@localhost test]# tar -cJvf test111.tar.xz test111
test111/
test111/test2.txt
test111/test3.txt
test111/test4.txt
test111/test5/
[root@localhost test]# ls
test111      test111.tar.bz2  test111.tar.xz  test.txt.xz
test111.tar  test111.tar.gz   test.tar
[root@localhost test]# rm -rf test111
[root@localhost test]# tar -Jxvf test111.tar.xz
test111/
test111/test2.txt
test111/test3.txt
test111/test4.txt
test111/test5/
[root@localhost test]# ls
test111      test111.tar.bz2  test111.tar.xz  test.txt.xz
test111.tar  test111.tar.gz   test.tar
```
