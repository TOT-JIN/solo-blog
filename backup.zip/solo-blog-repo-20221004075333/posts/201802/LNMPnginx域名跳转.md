title: LNMP--nginx 域名跳转
date: '2018-02-07 11:34:43'
updated: '2018-02-07 11:34:43'
tags: [lnmp, nginx, 域名跳转]
permalink: /articles/2018/02/07/1517974483733.html
---
# LNMP--nginx 域名跳转
&emsp;在对应虚拟主机配置文件中添加如下语句：



```
server

{

    listen 80;

    server_name  www.123.com www.test.com;  //增加一个域名

    index index.html index.htm index.php;

    root /data/www;



    if ($host != 'www.123.com'){

        rewrite ^/(.*)$ http://www.123.com/$1 permanent;

    }

    location ~ \.php$ {

        include fastcgi_params;

        fastcgi_pass unix:/tmp/php-fcgi.sock;

        fastcgi_index index.php;

        fastcgi_param SCRIPT_FILENAME /data/www$fastcgi_script_name;

    }

    location /uc_server/ {

        auth_basic  "Auth";

        auth_basic_user_file  /usr/local/nginx/conf/htpasswd;

    }

}
```




&emsp;&emsp;检测加载：

```
[root@localhost ~]# /usr/local/nginx/sbin/nginx -t

nginx: the configuration file /usr/local/nginx/conf/nginx.conf syntax is ok

nginx: configuration file /usr/local/nginx/conf/nginx.conf test is successful

[root@localhost ~]# /usr/local/nginx/sbin/nginx -s reload
```




&emsp;&emsp;浏览器访问 [www.test.com](http://www.test.com/) 后会自动跳转到 [www.123.com](http://www.123.com/) 下。

&emsp;&emsp;使用 curl 命令：

```
[root@localhost ~]# curl -I www.test.com

HTTP/1.1 301 Moved Permanently

Server: nginx/1.8.0

Date: Wed, 29 Jun 2016 00:26:04 GMT

Content-Type: text/html

Content-Length: 184

Connection: keep-alive

Location: http://www.123.com/
```
