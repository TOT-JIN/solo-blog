title: netstat 查看端口
date: '2016-08-12 12:15:45'
updated: '2016-08-12 12:15:45'
tags: [netstat, 端口, cli]
permalink: /articles/2016/08/12/1470975345345.html
---
# netstat 查看端口
&emsp;&emsp;netstat 命令用来打印网络连接状况、系统所开放端口、路由表等信息。关于netstat的最常用的命令是 netstat -lnp（打印当前系统启动哪些端口）以及 netstat -an（打印网络连接状况）这两个命令非常有用。
![屏幕快照20200618下午1.08.08.png](https://b3logfile.com/file/2020/06/屏幕快照20200618下午1.08.08-f9c989b4.png)

![屏幕快照20200618下午1.08.42.png](https://b3logfile.com/file/2020/06/屏幕快照20200618下午1.08.42-451c1322.png)




&emsp;&emsp;如果管理着一台提供web服务（80端口）的服务器，那么就可以使用 netstat -an|grep 80 来查看当前连接web服务的有哪些ip了。
