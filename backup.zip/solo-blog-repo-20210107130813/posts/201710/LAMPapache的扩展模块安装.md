title: LAMP--apache 的扩展模块安装
date: '2017-10-27 22:38:41'
updated: '2017-10-27 22:38:41'
tags: [lamp, httpd, 扩展模块]
permalink: /articles/2017/10/27/1509115121673.html
---
# LAMP--apache 的扩展模块安装
在配置域名 301 跳转时，发现 mod_rewrite.c 模块没有加载，所以以此为例。

这个用到了 apache 的扩展工具 apxs 

在使用这个功能之前，先确认是否已经加载 mod_so 模块，方法是：

```e-bash
[root@localhost ~]# /usr/local/apache2/bin/httpd -l
```



在列出的列表里有 mod_so 模块，则说明已经加载。

然后在源码包下找模块的C文件。

```e-bash
[root@localhost ~]# cd /usr/local/src/httpd-2.2.31
[root@localhost httpd-2.2.31]# find . -name mod_rewrite.c
./modules/mappers/mod_rewrite.c
[root@localhost httpd-2.2.31]# cd ./modules/mappers/
[root@localhost mappers]# pwd
/usr/local/src/httpd-2.2.31/modules/mappers
[root@localhost mappers]# /usr/local/apache2/bin/apxs -i -a -c mod_rewrite.c
/usr/local/apache2/build/libtool --silent --mode=compile gcc -prefer-pic   -DLINUX -D_REENTRANT -D_GNU_SOURCE -g -O2 -pthread -I/usr/local/apache2/include  -I/usr/local/apache2/include   -I/usr/local/apache2/include   -c -o mod_rewrite.lo mod_rewrite.c && touch mod_rewrite.slo
/usr/local/apache2/build/libtool --silent --mode=link gcc -o mod_rewrite.la  -rpath /usr/local/apache2/modules -module -avoid-version    mod_rewrite.lo
/usr/local/apache2/build/instdso.sh SH_LIBTOOL='/usr/local/apache2/build/libtool' mod_rewrite.la /usr/local/apache2/modules
/usr/local/apache2/build/libtool --mode=install cp mod_rewrite.la /usr/local/apache2/modules/
cp .libs/mod_rewrite.so /usr/local/apache2/modules/mod_rewrite.so
cp .libs/mod_rewrite.lai /usr/local/apache2/modules/mod_rewrite.la
cp .libs/mod_rewrite.a /usr/local/apache2/modules/mod_rewrite.a
chmod 644 /usr/local/apache2/modules/mod_rewrite.a
ranlib /usr/local/apache2/modules/mod_rewrite.a
PATH="$PATH:/sbin" ldconfig -n /usr/local/apache2/modules
----------------------------------------------------------------------
Libraries have been installed in:
   /usr/local/apache2/modules
If you ever happen to want to link against installed libraries
in a given directory, LIBDIR, you must either use libtool, and
specify the full pathname of the library, or use the `-LLIBDIR'
flag during linking and do at least one of the following:
   - add LIBDIR to the `LD_LIBRARY_PATH' environment variable
     during execution
   - add LIBDIR to the `LD_RUN_PATH' environment variable
     during linking
   - use the `-Wl,--rpath -Wl,LIBDIR' linker flag
   - have your system administrator add LIBDIR to `/etc/ld.so.conf'
See any operating system documentation about shared libraries for
more information, such as the ld(1) and ld.so(8) manual pages.
----------------------------------------------------------------------
chmod 755 /usr/local/apache2/modules/mod_rewrite.so
[activating module `rewrite' in /usr/local/apache2/conf/httpd.conf]
```



根据：

Libraries have been installed in:

   /usr/local/apache2/modules

知道模块安装到了哪里。
