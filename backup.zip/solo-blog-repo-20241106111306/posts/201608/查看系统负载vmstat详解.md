title: 查看系统负载 vmstat 详解
date: '2016-08-09 09:43:14'
updated: '2016-08-09 09:43:14'
tags: [系统负载, 运维, vmstat]
permalink: /articles/2016/08/09/1470706994345.html
---
# 查看系统负载 vmstat 详解
&emsp;&emsp;查看具体设备有无压力可以通过vmstat得知，vmstat命令打印的结果分为6部分：procs，memory，swap，io，system，cpu。重点关注r b si so bi bo 几列。



```
[root@localhost ~]# vmstat

procs -----------memory---------- ---swap-- -----io---- --system-- -----cpu-----

 r  b   swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st

 0  0    832 373600  22176 523896    0    0     3     3    5    6  0  0 100  0  0

[root@localhost ~]# vmstat 1

procs -----------memory---------- ---swap-- -----io---- --system-- -----cpu-----

 r  b   swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st

 0  0    832 373600  22280 523896    0    0     3     3    5    6  0  0 100  0  0

 0  0    832 373568  22280 523896    0    0     0     0   15   15  0  0 100  0  0

 0  0    832 373568  22280 523896    0    0     0     0   13   14  0  0 100  0  0

 0  0    832 373568  22280 523896    0    0     0     0   12   16  0  0 100  0  0

 0  0    832 373568  22280 523896    0    0     0     0   12   14  0  0 100  0  0

 0  0    832 373568  22280 523896    0    0     0     0   11   15  0  0 100  0  0

 0  0    832 373568  22280 523896    0    0     0     0   14   19  0  0 100  0  0

^C
```



&emsp;（1）procs 显示进程相关信息

&emsp;&emsp; r：表示运行和等待cpu时间片的进程数。如果长时间大于服务器cpu的个数，则说明cpu不够用了。

&emsp;&emsp;b：表示等待资源的进程数。比如，等待I/O、内存等，这列的值如果长时间大于1，则需要关注一下了。

&emsp;（2）memory 内存相关信息

&emsp;&emsp;swpd：表示切换到交换分区中的内存数量。

&emsp;&emsp;free：当前空闲的内存数量。

&emsp;&emsp;buff：缓冲大小（即将写入磁盘的）

&emsp;&emsp;cache：缓存大小（从磁盘中读取的）

&emsp;（3）swap 内存交换情况

&emsp;&emsp;si：由交换区写入到内存的数据量

&emsp;&emsp;so：由内存写入到交换区的数据量

&emsp;（4）io 磁盘使用情况

&emsp;&emsp;bi：从块设备读取数据的量（读磁盘）

&emsp;&emsp;bo：从块设备写入数据的量（写磁盘）

&emsp;（5）system 显示采集间隔内发生的中断次数

&emsp;&emsp;in：表示在某一时间间隔中观测到的每秒设备中断数

&emsp;&emsp;cs：表示每秒产生的上下文切换次数

&emsp;（6）CPU 显示cpu的使用状态

&emsp;&emsp;us：显示了用户下所花费cpu时间的百分比

&emsp;&emsp;sy：显示系统花费cpu时间百分比

&emsp;&emsp;id：表示cpu处于空闲状态的时间百分比

&emsp;&emsp;wa：表示I/O等待所占用cpu时间百分比

&emsp;&emsp;st：表示被偷走的cpu所占百分比（一般为 0，不用关注）



&emsp;&emsp;以上各个参数中，需要经常关注 r 列， b 列和 wa 列。IO部分的 bi 以及 bo 也是要经常参考的对象，如果磁盘io压力很大时，这两列的数值会比较高。另外当 si 、so 两列的数值比较高，并且在不断变化时，说明内存不够了，内存中的数据频繁交换到交换分区中，这往往对系统性能影响极大。

&emsp;&emsp;使用vmstat查看系统状态时，通常用这两种形式来看：

```[root@localhost ~]# vmstat 1 5```

或

`[root@localhost ~]# vmstat 1`

&emsp;&emsp;前面表示，每隔一秒钟输出一次状态，共输出5次。而后面的表示每隔1秒输出一次状态且一直输出，除非我们按Ctrl+c结束。
