title: cut   sort   wc  uniq  tee  tr  split
date: '2016-10-03 22:52:15'
updated: '2016-10-03 22:52:15'
tags: [cut, sort, wc, uniq]
permalink: /articles/2016/10/03/1475506335856.html
---
# cut   sort   wc  uniq  tee  tr  split
**命令 : cut**

用来截取某一个字段
语法： `cut -d '分隔字符' [-cf] n` 这里的n是数字

`-d` ：后面跟分隔字符，分隔字符要用单引号括起来

`-c` ：后面接的是第几个字符

`-f` ：后面接的是第几个区块

```
[root@localhost ~]# cat /etc/passwd |cut -d ':' -f 1 |head -n5
root
bin
daemon
adm
lp
```

`-d` 后面跟分隔字符，这里使用冒号作为分割字符，-f 1 就是截取第一段，-f和1之间的空格可有可无。

```
[root@localhost ~]# head -n2 /etc/passwd|cut -c2
o
i
[root@localhost ~]# head -n2 /etc/passwd|cut -c1
r
b
[root@localhost ~]# head -n2 /etc/passwd|cut -c1-10
root:x:0:0
bin:x:1:1:
[root@localhost ~]# head -n2 /etc/passwd|cut -c5-10
:x:0:0
x:1:1:
```

`-c` 后面可以是1个数字n，也可以是一个区间n1-n2，还可以是多个数字n1,n2,n3

```
[root@localhost ~]# head -n2 /etc/passwd|cut -c1,3,10
ro0
bn:
```

**命令 : sort**

sort 用做排序
语法： `sort [-t 分隔符] [-kn1,n2] [-nru]` 这里的n1 < n2

`-t` ：分隔符，作用跟cut的-d一个意思

`-n` ：使用纯数字排序

`-r` ：反向排序

`-u` ：去重复

`-kn1,n2` ：由n1区间排序到n2区间，可以只写-kn1，即对n1字段排序

```
[root@localhost ~]# head -n5 /etc/passwd |sort
adm:x:3:4:adm:/var/adm:/sbin/nologin
bin:x:1:1:bin:/bin:/sbin/nologin
daemon:x:2:2:daemon:/sbin:/sbin/nologin
lp:x:4:7:lp:/var/spool/lpd:/sbin/nologin
root:x:0:0:root:/root:/bin/bash
```

如果sort不加任何选项，则从首字符向后，依次按ASCII码值进行比较，最后将他们按升序输出。

```
[root@localhost ~]# head -n5 /etc/passwd |sort -t: -k3 -n
root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/sbin/nologin
daemon:x:2:2:daemon:/sbin:/sbin/nologin
adm:x:3:4:adm:/var/adm:/sbin/nologin
lp:x:4:7:lp:/var/spool/lpd:/sbin/nologin
```

-t 后面跟分隔符，-k后面跟数字，表示对第几个区域的字符串排序，-n 则表示使用纯数字排序

```
[root@localhost ~]# head -n5 /etc/passwd |sort -t: -k3,5 -r
lp:x:4:7:lp:/var/spool/lpd:/sbin/nologin
adm:x:3:4:adm:/var/adm:/sbin/nologin
daemon:x:2:2:daemon:/sbin:/sbin/nologin
bin:x:1:1:bin:/bin:/sbin/nologin
root:x:0:0:root:/root:/bin/bash
```

-k3,5 表示从第3到第5区域间的字符串排序，-r表示反向排序

**命令 : wc**

用于统计文档的行数、字符数、词数，常用的选项为：

`-l` ：统计行数

`-m` ：统计字符数

`-w` ：统计词数

```
[root@localhost ~]# wc /etc/passwd
  27   37 1220 /etc/passwd
[root@localhost ~]# wc -l /etc/passwd
27 /etc/passwd
[root@localhost ~]# wc -m /etc/passwd
1220 /etc/passwd
[root@localhost ~]# wc -w /etc/passwd
37 /etc/passwd
```

wc 不跟任何选项，直接跟文档，则会把行数、词数、字符数依次输出。

**命令 : uniq**

去重复的行，阿铭最常用的选项只有一个：

`-c` ：统计重复的行数，并把行数写在前面

```
[root@localhost ~]# vim testb.txt
```

把下面的内容写入testb.txt, 保存。

```
111
222
111
333
```

使用uniq 的前提是需要先给文件排序，否则不管用。

```
[root@localhost ~]# uniq testb.txt
111
222
111
333
[root@localhost ~]# sort testb.txt |uniq
111
222
333
[root@localhost ~]# sort testb.txt |uniq -c
      2 111
      1 222
      1 333
```

**命令 : tee**

后跟文件名，类似与重定向 “>”, 但是比重定向多了一个功能，在把文件写入后面所跟的文件中的同时，还显示在屏幕上。

```
[root@localhost ~]# echo "aaaaaaaaaaaaaaaaaaaaaaaaaaa" |tee testb.txt
aaaaaaaaaaaaaaaaaaaaaaaaaaa
[root@localhost ~]# cat testb.txt
aaaaaaaaaaaaaaaaaaaaaaaaaaa
```

tee 常用语管道符 “|” 后。

**命令 : tr**

替换字符，常用来处理文档中出现的特殊符号，如DOS文档中出现的^M符号。常用的选项有两个：

`-d` ：删除某个字符，-d 后面跟要删除的字符

`-s` ：把重复的字符去掉

最常用的就是把小写变大写: tr ‘[a-z]’ ‘[A-Z]’

```
[root@localhost ~]# head -n2 /etc/passwd |tr '[a-z]' '[A-Z]'
ROOT:X:0:0:ROOT:/ROOT:/BIN/BASH
BIN:X:1:1:BIN:/BIN:/SBIN/NOLOGIN
```

当然替换一个字符也是可以的。

```
[root@localhost ~]# grep 'root' /etc/passwd |tr 'r' 'R'
Root:x:0:0:Root:/Root:/bin/bash
opeRatoR:x:11:0:opeRatoR:/Root:/sbin/nologin
```

不过替换、删除以及去重复都是针对一个字符来讲的，有一定局限性。如果是针对一个字符串就不再管用了，所以阿铭建议你只需简单了解这个tr即可，以后你还会学到更多可以实现针对字符串操作的工具。

**命令 : split**

切割文档，常用选项：

`-b` ：依据大小来分割文档，单位为byte

```
[root@localhost ~]# mkdir split_dir
[root@localhost ~]# cd !$
cd split_dir
[root@localhost split_dir]# cp /etc/passwd ./
[root@localhost split_dir]# split -b500 passwd
[root@localhost split_dir]# ls
passwd  xaa  xab  xac
```

如果split不指定目标文件名，则会以xaa xab... 这样的文件名来存取切割后的文件。当然我们也可以指定目标文件名：

```
[root@localhost split_dir]# split  -b500 passwd  123
[root@localhost split_dir]# ls
123aa  123ab  123ac  passwd
```

`-l` ：依据行数来分割文档

```
[root@localhost split_dir]# rm -f 123a*
[root@localhost split_dir]# split -l10 passwd
[root@localhost split_dir]# wc -l *
  27 passwd
  10 xaa
  10 xab
  7 xac
  54 总用量
```
