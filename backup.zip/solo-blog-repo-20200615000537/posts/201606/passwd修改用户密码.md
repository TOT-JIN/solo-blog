title: passwd 修改用户密码
date: '2016-06-13 22:43:13'
updated: '2016-06-13 22:43:13'
tags: [passwd, Linux]
permalink: /articles/2016/06/13/1465828993592.html
---
# passwd 修改用户密码
语法 passwd [username]

**等创建完账户后，密码默认是没有的。虽然没有密码，但该账户同样登录不了系统。只有设置好密码后才能登录系统。**

```
[root@localhost ~]# passwd

更改用户 root 的密码 。

新的 密码：

重新输入新的 密码：

passwd： 所有的身份验证令牌已经成功更新。
```

**passwd后不加username则是修改当前账户的密码。如果登录的是root账户，后面可以跟普通用户名，修改指定账户的密码。**

```
[root@localhost ~]# passwd user11

更改用户 user11 的密码 。

新的 密码：

重新输入新的 密码：

passwd： 所有的身份验证令牌已经成功更新。
```

**只有root账户才可以修改其它账户密码，普通账户只能修改自己的密码。**

命令： mkpasswd

**这个命令是用来生成密码的，省的自己去想。默认我们安装的linux是没有这个命令的，需要安装一个包”expect“。**

```
[root@localhost ~]# yum install -y expect

[root@localhost ~]# mkpasswd

)gty49uRI
```

**有时，我们需要生成指定长度的密码。mkpasswd命令也可以满足，比如生成12位长的密码：**

```
[root@localhost ~]# mkpasswd -l 12

h.9vMQuhitb5
```

**还可指定密码中有几个特殊字符，和几个数字。**

```
[root@localhost ~]# mkpasswd -l 12 -s 0 -d 3

i2mrmeVH9c9l
```

**-s 是指定特殊字符的个数，-d指定数字的个数。**

**下面介绍两种一条命令搞定修改用户密码，比较适合用在shell脚本中。**

（1）echo -e "yourpasswd\nyourpasswd"|passwd user1

（2）echo "yourpasswd"|passwd --stidin user1

**第一种方法，echo -e可以使用换行符\n，这样相当于我们人工打了一次回车。第二种， --stidin是passwd命令的一个选项。**
