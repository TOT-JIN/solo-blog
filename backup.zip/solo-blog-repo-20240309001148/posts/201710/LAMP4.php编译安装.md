title: LAMP--4.php 编译安装
date: '2017-10-04 21:43:41'
updated: '2017-10-04 21:43:41'
tags: [lamp, php编译]
permalink: /articles/2017/10/04/1507124621673.html
---
# LAMP--4.php 编译安装
（安装顺序在最后）

把 php 放到最后安装是因为在编译 php 时，需要指定 mysql 和 apache 的路径，如果不先安装好 mysql 和 apache 就没有办法安装 php 。而 apache 和 mysql 的安装顺序就无所谓了。

PHP 官网下载地址：http://www.php.net/downloads.php 。搜狐镜像：[http://mirrors.sohu.com/php/php-5.6.10.tar.gz](http://mirrors.sohu.com/php/php-5.6.10.tar.gz)  。

下载 php：

```e-bash
[root@localhost ~]# cd /usr/local/src
[root@localhost src]# wget http://mirrors.sohu.com/php/php-5.6.10.tar.gz
```



解压源码包：

```e-bash
[root@localhost src]# tar zxf php-5.6.10.tar.gz
```



配置编译参数：

```e-bash
[root@localhost src]# cd php-5.6.10
[root@localhost php-5.6.10]#  ./configure \
--prefix=/usr/local/php \
--with-apxs2=/usr/local/apache2/bin/apxs \
--with-config-file-path=/usr/local/php/etc  \
--with-mysql=/usr/local/mysql \
--with-libxml-dir \
--with-gd \
--with-jpeg-dir \
--with-png-dir \
--with-freetype-dir \
--with-iconv-dir \
--with-zlib-dir \
--with-bz2 \
--with-openssl \
--with-mcrypt \
--enable-soap \
--enable-gd-native-ttf \
--enable-mbstring \
--enable-sockets \
--enable-exif \
--disable-ipv6
```



遇到错误：

```e-bash
 error: xml2-config not found. Please check your libxml2 installation.
# yum install -y libxml2-devel
```



```e-bash
error: Cannot find OpenSSL's <evp.h>
# yum install -y openssl openssl-devel
```



```e-bash
error: Please reinstall the BZip2 distribution
# yum install -y bzip2 bzip2-devel
```



```e-bash
error: png.h not found.
# yum install -y libpng libpng-devel
```



```e-bash
error: freetype.h not found.
# yum install -y freetype freetype-devel
```



```e-bash
error: freetype-config not found.
# yum install -y freetype-devel
```



```e-bash
error: mcrypt.h not found. Please reinstall libmcrypt.
# yum install -y libmcrypt-devel
```



编译

#make

```e-bash
[root@localhost php-5.6.10]# make
crypt -lxml2 -lz -lm -lxml2 -lz -lm -lxml2 -lz -lm -lcrypt  -o sapi/cgi/php-cgi
Generating phar.php
Generating phar.phar
PEAR package PHP_Archive not installed: generated phar will require PHP's phar extension be enabled.
pharcommand.inc
directorytreeiterator.inc
clicommand.inc
directorygraphiterator.inc
invertedregexiterator.inc
phar.inc
Build complete.
Don't forget to run 'make test'.
[root@localhost php-5.6.10]# echo $?
0
```



安装

# make install

```e-bash
[root@localhost php-5.6.10]# make install
Installing PEAR environment:      /usr/local/php/lib/php/
[PEAR] Archive_Tar    - installed: 1.3.12
[PEAR] Console_Getopt - installed: 1.3.1
[PEAR] Structures_Graph- installed: 1.0.4
[PEAR] XML_Util       - installed: 1.2.3
[PEAR] PEAR           - installed: 1.9.5
Wrote PEAR system config file at: /usr/local/php/etc/pear.conf
You may want to add: /usr/local/php/lib/php to your php.ini include_path
/usr/local/src/php-5.6.10/build/shtool install -c ext/phar/phar.phar /usr/local/php/bin
ln -s -f phar.phar /usr/local/php/bin/phar
Installing PDO headers:          /usr/local/php/include/php/ext/pdo/
[root@localhost php-5.6.10]# echo $?
0
```



拷贝 php 配置文件

```e-bash
[root@localhost php-5.6.10]# cp php.ini-production /usr/local/php/etc/php.ini
```



修改 apache 配置文件

```e-bash
[root@localhost php-5.6.10]# vim /usr/local/apache2/conf/httpd.conf
```



找到：

```e-bash
<Directory />
    Options FollowSymLinks
    AllowOverride None
    Order deny,allow
    Deny from all
</Directory>
        改为：
<Directory />
    Options FollowSymLinks
    AllowOverride None
    Order deny,allow
    Allow from all
</Directory>
```



说明：如果不修改这个地方，我们访问网站会禁止访问，显示403。

然后找到：

```e-bash
    AddType application/x-gzip .gz .tgz
```



在该行下面添加：

```e-bash
    AddType application/x-gzip .gz .tgz
    AddType application/x-httpd-php .php
```



说明：要想支持 php 脚本解析，必须要加上对应的类型。

再找到：

```e-bash
<IfModule dir_module>
    DirectoryIndex index.html
</IfModule>
```



改为：

```e-bash
<IfModule dir_module>
    DirectoryIndex index.html index.htm index.php
</IfModule>
```



说明：增加对 php 的索引，如果一个站点默认页为 index.php，那么就得加上这个 index.php 的支持。

再找到：

```e-bash
#ServerName www.example.com:80
```



修改为：

```e-bash
ServerName localhost:80
```



如果不去掉#，则启动 apache 时，会有警告信息“httpd:Could not reliably determine the server's fully qualified domain name,using localhost.localdomain for ServerName”,看起来像是错误，其实没有影响。

  

查看配置文件是否有问题：

```e-bash
[root@localhost php-5.6.10]# /usr/local/apache2/bin/apachectl -t
Syntax OK
```



启动服务：

```e-bash
[root@localhost php-5.6.10]# /usr/local/apache2/bin/apachectl start
```



检查是否正常启动：

```e-bash
[root@localhost php-5.6.10]# ps aux|grep httpd
root      7998  0.0  0.7 196260  7284 ?        Ss   23:45   0:00 /usr/local/apache2/bin/httpd -k start
daemon    7999  0.0  0.4 196396  4920 ?        S    23:45   0:00 /usr/local/apache2/bin/httpd -k start
daemon    8000  0.0  0.4 196396  4920 ?        S    23:45   0:00 /usr/local/apache2/bin/httpd -k start
daemon    8001  0.0  0.4 196396  4920 ?        S    23:45   0:00 /usr/local/apache2/bin/httpd -k start
daemon    8002  0.0  0.4 196396  4920 ?        S    23:45   0:00 /usr/local/apache2/bin/httpd -k start
daemon    8003  0.0  0.4 196396  4920 ?        S    23:45   0:00 /usr/local/apache2/bin/httpd -k start
root      8005  0.0  0.0 103316   900 pts/1    S+   23:45   0:00 grep httpd
```
