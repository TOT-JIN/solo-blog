title: ubuntu 挂载iso文件做apt源
date: '2017-11-27 21:12:44'
updated: '2017-11-27 21:12:44'
tags: [ubuntu, apt, iso]
permalink: /articles/2017/11/27/1511788364856.html
---
# ubuntu 挂载iso文件做apt源
&emsp;&emsp;添加iso文件源：


```
genee@demo:~$ sudo mount -t iso9660 -o loop /usr/local/src/ubuntu-16.04.4-server-amd64.iso /media/cdrom  #挂在镜像文件到/media/cdrom
mount: /dev/loop0 is write-protected, mounting read-only

genee@demo:~$ df -h
Filesystem                   Size  Used Avail Use% Mounted on
udev                         797M     0  797M   0% /dev
tmpfs                        164M   22M  142M  14% /run
/dev/mapper/ubuntu--vg-root  457G   82G  352G  19% /
tmpfs                        816M  5.8M  811M   1% /dev/shm
tmpfs                        5.0M     0  5.0M   0% /run/lock
tmpfs                        816M     0  816M   0% /sys/fs/cgroup
/dev/sda1                    472M  134M  314M  30% /boot
/dev/loop0                   848M  848M     0 100% /media/cdrom
​
genee@demo:~$ sudo apt-cdrom -m -d /media/cdrom add  #添加挂载点镜像文件到更新源

genee@demo:~$ sudo apt-get update
```
