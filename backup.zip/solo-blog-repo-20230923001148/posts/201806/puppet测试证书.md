title: puppet 测试证书
date: '2018-06-02 21:21:14'
updated: '2018-06-02 21:21:14'
tags: [puppet, 自动化运维]
permalink: /articles/2018/06/02/1527945674832.html
---
# puppet 测试证书
&emsp;服务端编辑配置文件

```
[root@server ~]# vim /etc/puppet/manifests/site.pp

node default{

 file {

 "/tmp/123.txt":

 content => "test,test";

}

}
```


&emsp;说明：该配置文件后面还会用到，如果不配置该文件，则客户端不会同步任何数据

&emsp;重启puppetmaster服务

```
[root@server ~]# service puppetmaster restart

停止 puppetmaster：                                        [确定]

启动 puppetmaster：                                        [确定]
```


&emsp;客户端上稍等一会（每隔30s会自动执行服务端上的任务），或者直接命令行 puppet agent --test --server server.test.com ，这样在客户端的/tmp/下会有个123.txt文件，内容为test,test。
