title: LNMP--nginx 配置防盗链
date: '2018-02-15 15:24:13'
updated: '2018-02-15 15:24:13'
tags: [lnmp, nginx, 防盗链]
permalink: /articles/2018/02/15/1518679453733.html
---
# LNMP--nginx 配置防盗链
&emsp;&emsp;也可以和不记录指定文件类型的日志、静态文件过期时间的配置合并。



```
location ~* ^.+\.(gif|jpg|png|swf|flv|rar|zip|doc|pdf|gz|bz2|jpeg|bmp|xls)${

         valid_referers none blocked server_names *.taobao.com *.baidu.com *.google.com *.google.cn *.soso.com;

         # 表示对这些域名的网站不进行盗链。

                   if ($invalid_referer){

         #               return  403;

                          rewrite ^/ http://www.example.com/nophoto.gif;

                   }

}
```


          

&emsp;&emsp;说明：如果前面配置中已经配置了

```
location ~ .*\.(gif|jpg|jpeg|png|bmp|swf)$

{

      expires   30d;

      access_log off;

}
```


&emsp;&emsp;那么会和这部分重复，这时候上面的生效，所以需要把两者合在一起。如下：

```
location ~* ^.+\.(gif|jpg|png|swf|flv|rar|zip|doc|pdf|gz|bz2|jpeg|bmp|xls)${

         expires  30d;

         valid_referers none blocked server_names *.taobao.com *.baidu.com *.google.com *.google.cn *.soso.com;


         # 表示对这些域名的网站不进行盗链。

                   if ($invalid_referer){

         #               return  403;

                          rewrite ^/ http://www.example.com/nophoto.gif;

                   }

         access_log  off;

}
```

&emsp;&emsp;说明：盗用我们图片的人访问这些图片时会跳转到 [http://www.example.com/nophoto.gif](http://www.example.com/nophoto.gif) 这里。当然也可以直接显示 403，即启用 return 403，这样更节省资源。
