title: LNMP--3.nginx启动脚本和配置文件
date: '2018-01-09 18:14:53'
updated: '2018-01-09 18:14:53'
tags: [lnmp, nginx]
permalink: /articles/2018/01/04/1515492893733.html
---
# LNMP--3.nginx启动脚本和配置文件
&emsp;（1）编写 Nginx 启动脚本，并加入系统服务

```
[root@localhost ~]# vim /etc/init.d/nginx
```


&emsp;&emsp;写入：

```
#!/bin/bash

# chkconfig: - 30 21

# description: http service.

# Source Function Library

. /etc/init.d/functions

# Nginx Settings



NGINX_SBIN="/usr/local/nginx/sbin/nginx"

NGINX_CONF="/usr/local/nginx/conf/nginx.conf"

NGINX_PID="/usr/local/nginx/logs/nginx.pid"

RETVAL=0

prog="Nginx"



start() {

        echo -n $"Starting $prog: "

        mkdir -p /dev/shm/nginx_temp

        daemon $NGINX_SBIN -c $NGINX_CONF

        RETVAL=$?

        echo

        return $RETVAL

}



stop() {

        echo -n $"Stopping $prog: "

        killproc -p $NGINX_PID $NGINX_SBIN -TERM

        rm -rf /dev/shm/nginx_temp

        RETVAL=$?

        echo

        return $RETVAL

}



reload(){

        echo -n $"Reloading $prog: "

        killproc -p $NGINX_PID $NGINX_SBIN -HUP

        RETVAL=$?

        echo

        return $RETVAL

}



restart(){

        stop

        start

}



configtest(){

    $NGINX_SBIN -c $NGINX_CONF -t

    return 0

}



case "$1" in

  start)

        start

        ;;

  stop)

        stop

        ;;

  reload)

        reload

        ;;

  restart)

        restart

        ;;

  configtest)

        configtest

        ;;

  *)

        echo $"Usage: $0 {start|stop|reload|restart|configtest}"

        RETVAL=1

esac



exit $RETVAL
```


&emsp;&emsp;保存后，更改权限，设置开机启动

```
[root@localhost ~]# chmod 755 /etc/init.d/nginx

[root@localhost ~]# chkconfig --add nginx

[root@localhost ~]# chkconfig nginx on
```


&emsp;（2）更改 nginx 配置

&emsp;&emsp;首先把原来的配置清空：

```
[root@localhost ~]# >/usr/local/nginx/conf/nginx.conf
```


&emsp;&emsp;单独使用 重定向符号 > 可把一个文本文档快速清空。



```
[root@localhost ~]# vim /usr/local/nginx/conf/nginx.conf
```


&emsp;&emsp;写入：

```
user nobody nobody;

worker_processes 2;

error_log /usr/local/nginx/logs/nginx_error.log crit;

pid /usr/local/nginx/logs/nginx.pid;

worker_rlimit_nofile 51200;



events

{

    use epoll;

    worker_connections 6000;

}



http

{

    include mime.types;

    default_type application/octet-stream;

    server_names_hash_bucket_size 3526;

    server_names_hash_max_size 4096;

    log_format combined_realip '$remote_addr $http_x_forwarded_for [$time_local]'

    '$host "$request_uri" $status'

    '"$http_referer" "$http_user_agent"';

    sendfile on;

    tcp_nopush on;

    keepalive_timeout 30;

    client_header_timeout 3m;

    client_body_timeout 3m;

    send_timeout 3m;

    connection_pool_size 256;

    client_header_buffer_size 1k;

    large_client_header_buffers 8 4k;

    request_pool_size 4k;

    output_buffers 4 32k;

    postpone_output 1460;

    client_max_body_size 10m;

    client_body_buffer_size 256k;

    client_body_temp_path /usr/local/nginx/client_body_temp;

    proxy_temp_path /usr/local/nginx/proxy_temp;

    fastcgi_temp_path /usr/local/nginx/fastcgi_temp;

    fastcgi_intercept_errors on;

    tcp_nodelay on;

    gzip on;

    gzip_min_length 1k;

    gzip_buffers 4 8k;

    gzip_comp_level 5;

    gzip_http_version 1.1;

    gzip_types text/plain application/x-javascript text/css text/htm application/xml;



server

{

    listen 80;

    server_name localhost;

    index index.html index.htm index.php;

    root /usr/local/nginx/html;



    location ~ \.php$ {

        include fastcgi_params;

        fastcgi_pass unix:/tmp/php-fcgi.sock;

        fastcgi_index index.php;

        fastcgi_param SCRIPT_FILENAME /usr/local/nginx/html$fastcgi_script_name;

    }



}



}
```


&emsp;&emsp;检查配置：

```
[root@localhost ~]# /usr/local/nginx/sbin/nginx -t

nginx: the configuration file /usr/local/nginx/conf/nginx.conf syntax is ok

nginx: configuration file /usr/local/nginx/conf/nginx.conf test is successful
```


&emsp;&emsp;重启nginx

```
[root@localhost ~]# service nginx restart

停止 Nginx：                                               [确定]

正在启动 Nginx：                                           [确定]
```




```
[root@localhost ~]# ps aux|grep nginx

root     30886  0.0  0.0  23860   820 ?        Ss   03:34   0:00 nginx: master process /usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/nginx.conf

nobody   30887  0.1  0.3  26304  3528 ?        S    03:34   0:00 nginx: worker process

nobody   30888  0.0  0.3  26304  3436 ?        S    03:34   0:00 nginx: worker process

root     30890  0.0  0.0 103324   868 pts/0    S+   03:36   0:00 grep nginx
```


&emsp;&emsp;创建测试文件：

```
[root@localhost nginx-1.8.0]# vim /usr/local/nginx/html/2.php

<?php

   echo "test php scripts.";

?>
```


&emsp;&emsp;测试：

```
[root@localhost ~]# curl localhost/2.php

test php scripts.[root@localhost ~]#
```
