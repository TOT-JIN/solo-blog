title: 【CDH6】Hue的安装及使用
date: '2020-12-20 22:21:50'
updated: '2020-12-20 22:21:50'
tags: [大数据, CDH, Hue]
permalink: /articles/2020/12/20/1608474110157.html
---
## Hue 的安装

HUE是一个开源的Apache Hadoop UI系统，早期由Cloudera开发，它是基于Python Web框架Django实现，后来贡献给开源社区。它包括3个部分hue ui，hue server，hue db。通过使用Hue我们可以通过浏览器方式操纵Hadoop集群，查看修改hdfs的文件，管理hive的元数据，运行Sqoop，编写Oozie工作流等大量工作。Hue的安装可以依赖hive和oozie，所以这里先安装了Hive和oozie。

1. 选择集群，添加服务：
   ![image20201218155913421.png](https://b3logfile.com/file/2020/12/image20201218155913421-51ccebb5.png)
2. 添加服务向导：
   选择“hue”服务，点击“继续”：
   ![image20201218160115136.png](https://b3logfile.com/file/2020/12/image20201218160115136-8141c397.png)
   选择依赖，点击“继续”：
   ![image20201218160432737.png](https://b3logfile.com/file/2020/12/image20201218160432737-5be65ea7.png)
   角色按照默认配置即可，点击“继续”，完成hue的安装
   ![image20201218160610471.png](https://b3logfile.com/file/2020/12/image20201218160610471-323af51f.png)
   当点击“继续”后，需要给hue配置数据库，需要在cm-s1节点上连接mysql，执行创建数据库及分配权限语句：

   ```
   [root@cm-s1 ~]# mysql -hcm-s1 -pAz123456_ -e "create database hue DEFAULT CHARACTER SET utf8;grant all on hue.* TO 'hue'@'%' IDENTIFIED BY 'Az123456_';flush privileges;"
   ```


   在弹出的页面中选择数据库，填写用户名及密码，点击“测试连接”，测试数据库连接成功后，点击“继续”：
   ![image20201218160957019.png](https://b3logfile.com/file/2020/12/image20201218160957019-82ba98aa.png)
   等待服务向导完成，点击“继续” -> “完成”，完成hue安装
   ![image20201218161138627.png](https://b3logfile.com/file/2020/12/image20201218161138627-512722a0.png)

## Hue 的使用

以上将hue安装在cm-s1节点上，这里登陆hue时，地址为：[http://cm-s1:8889](http://cm-s1:8889)，首次登陆hue需要登陆hue的账号密码，这里输入user:myhue，password:myhue。最好这里使用hdfs用户。因为hdfs用户可以操作hdfs中的文件，如果使用其他用户只能在当前用户的目录下创建文件。

![image20201218215243709.png](https://b3logfile.com/file/2020/12/image20201218215243709-a072f46b.png)

1. hue 创建用户
   点击“管理用户”->“添加用户”可以创建用户，并且可以指定权限，是否在HDFS中创建主目录等。
   ![image20201219131700865.png](https://b3logfile.com/file/2020/12/image20201219131700865-d4fbb2e8.png)
   ![image20201219131819888.png](https://b3logfile.com/file/2020/12/image20201219131819888-ed5fefbb.png)
2. hue 操作 HDFS 文件
   可以创建新的文件，也可以修改，最好HDFS中大文件不要在hue中操作。hue中的用户默认是进入当前用户的主目录进行操作。
   ![image20201219141624972.png](https://b3logfile.com/file/2020/12/image20201219141624972-1b3460a5.png)
   ![image20201219143330314.png](https://b3logfile.com/file/2020/12/image20201219143330314-36dab9c0.png)
   点击以上“文件”进入到HDFS文件系统，进行创建上传文件夹或者文件，还可以对文件进行编辑。
   ![image20201219145914777.png](https://b3logfile.com/file/2020/12/image20201219145914777-37af3553.png)
3. Hue 操作hive中的数据
   登录hue之后，点击“查询” -> “编辑器” -> “Hive”，编写SQL创建Hive表：
   ![image20201219144759105.png](https://b3logfile.com/file/2020/12/image20201219144759105-a0fd6b7e.png)
   创建完成后，点击hive数据库刷新，可以看到刚才创建的Hive表,创建表完成之后，可以右键表找到“在浏览器中打开”，可以查询、导入、删除表等操作，导入数据时选择的数据可以是HDFS中也可以是本地中的文件数据：
   ![image20201219151004538.png](https://b3logfile.com/file/2020/12/image20201219151004538-92b16945.png)
   点击“提交”将HDFS中文件数据导入到表中。点击“查询”查询表中的数据，如下：
   ![image20201219151314668.png](https://b3logfile.com/file/2020/12/image20201219151314668-227e2f6c.png)
   在Hive SQL面板中还可以查询数据，在查询编辑器中执行查询sql语句：
   ![image20201219151742409.png](https://b3logfile.com/file/2020/12/image20201219151742409-39e207de.png)
   执行sql语句之后，hql转换成MR作业，可以点击“作业”查看任务：
   ![image20201219152515160.png](https://b3logfile.com/file/2020/12/image20201219152515160-eb3a91f3.png)
4. Hue 添加 RDBMS 数据库
   hue也支持RDBMS关系数据库的展示及操作。启动Cloudera Manager 登录Hue之后，在配置中搜索“hue_safety_valve.ini”配置项，配置如下内容，保存更改：

   ```
   [librdbms]
   [[databases]]
   [[[mysql]]]
   nice_name="all mysql databases"
   engine=mysql
   host=cm-s1
   port=3306
   user=root
   password=Az123456_
   options={ "init_command":"SET NAMES 'utf8'"}

   [notebook]
   [[interpreters]]
   [[[hive]]]
   name=Hive
   [[[mysql]]]
   name=Mysql
   interface=rdbms
   [[[java]]]
   name=Java
   interface=oozie
   [[[spark2]]]
   name=Spark
   interface=oozie
   [[[shell]]]
   name=Shell
   interface=oozie
   [[[sqoop1]]]
   name=Sqoop1
   interface=oozie
   [[[distcp]]]
   name=Distcp
   interface=oozie
   ```

   ![image20201219153219089.png](https://b3logfile.com/file/2020/12/image20201219153219089-e7b59b3a.png)
   以上参数中，nice_name指定在hue中显示的连接名称。name指定连接的mysql数据库名称，不指定这个参数，将默认显示全部的数据库。engine指定mysql数据库类型。host指定数据库地址。port指定数据库端口号。user指定连接用户名。password指定密码。options中指定的“init_command”指定数据库编码为utf8，防止有中文时乱码。
   此外，在配置“[notebook]”时，可以只需要配置Hive 与Mysql即可。以上配置完成之后，重启hue。重新进入hue webui中，点击“查询”->“编辑器”，可以看到“MySQL”标签，点击在主页右侧“SQL”中也会出现对应的MySQL中的数据库及表信息。
   ![image20201219153717122.png](https://b3logfile.com/file/2020/12/image20201219153717122-9c0c4237.png)
