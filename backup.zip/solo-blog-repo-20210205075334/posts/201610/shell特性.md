title: shell特性
date: '2016-10-01 12:43:12'
updated: '2016-10-01 12:43:12'
tags: [shell, history, alias, 追加重定向]
permalink: /articles/2016/10/01/1475296992856.html
---
# shell特性
&emsp;&emsp;我们敲过的命令，Linux是会有记录的，预设可以记录1000条历史命令。这些命令保存在用户的家目录中的.bash_history文件中。只有当用户正常退出当前shell时，在当前shell中运行的命令才会保存至.bash_history文件中。



**history** 查看曾经用过的命令

root用户的命令历史在 /.bash_history 里。默认1000条，echo $HISTSIZE 可查看。

快捷键：

`!!` 表示上一条命令

`!$` 表示上一条命令的最后一个参数

`!n` 表示运行命令历史中第n个命令 例：!950

`!x` 表示运行最近运行过的一次以 x 字母开头的命令

`tab`键 用于补全命令或路径 若需按两次，则可能补全的情况有多个，会列出全部以供选择



`alias` 直接运行不加参数会列出已有的别名，alias aaa='cat 1.txt' 则用于设置别名，但此时只在当前shell中生效，除非写到配置文件中

`unalias` 用于删除已有的别名，如 unalias aaa

**ls \*.txt**   &emsp;`*`号表示通配符，可把所有.txt结尾的文件列出来 ,也可变通使用

**ls ?.txt** &emsp;`？`号表示只包含一个字符的通配符

`|`   管道符，把之前的命令的结果丢给后边的命令 ， ifconfig | less

`>` 重定向， echo "sjdflksdjlfksd" > 1.txt   ,  此命令会把1.txt中原有的内容覆盖掉

`>>` 追加重定向，与重定向区别为 不会覆盖原有内容，而会在原有内容之后追加

`<` 反向重定向，会把一个文件的内容送给一个命令 ， wc -l < 1.txt

`2>` `2>>` 错误重定向 错误追加重定向  一个命令的执行结果可对可错，执行结果错误的命令是不能用 > 来追加的，需要用 2> 或 2>>不覆盖追加。例： 没有1111文件   ls 1111 > 1.txt  ; cat 1.txt 结果为空，而用 ls 1111 2> 1.txt ; cat 1.txt  结果为错误输出 ，再次追加 ls 1111 2>> 1.txt ; cat 1.txt 结果为两次错误输出。

---


**作业控制**

 

&emsp;&emsp;当运行一个进程时，可以使它暂停（Ctrl+z），然后使用 fg 命令恢复它，利用 bg 命令使它到后台运行，也可以使它终止（Ctrl+c）。



```
[root@localhost ~]# vmstat 1 > /tmp/1.log

^Z

[1]+  Stopped                 vmstat 1 > /tmp/1.log

[root@localhost ~]# jobs

[1]+  Stopped                 vmstat 1 > /tmp/1.log

[root@localhost ~]# vim test1.txt



[2]+  Stopped                 vim test1.txt

[root@localhost ~]# jobs

[1]-  Stopped                 vmstat 1 > /tmp/1.log

[2]+  Stopped                 vim test1.txt

[root@localhost ~]# fg

vim test1.txt



[2]+  Stopped                 vim test1.txt

[root@localhost ~]# jobs

[1]-  Stopped                 vmstat 1 > /tmp/1.log

[2]+  Stopped                 vim test1.txt

[root@localhost ~]# fg 1

vmstat 1 > /tmp/1.log

^Z

[1]+  Stopped                 vmstat 1 > /tmp/1.log

[root@localhost ~]# jobs

[1]+  Stopped                 vmstat 1 > /tmp/1.log

[2]-  Stopped                 vim test1.txt

[root@localhost ~]# bg

[1]+ vmstat 1 > /tmp/1.log &

[root@localhost ~]# jobs

[1]-  Running                 vmstat 1 > /tmp/1.log &

[2]+  Stopped                 vim test1.txt
```

&emsp;&emsp;运行一个任务时，使用Ctrl+z暂停，jobs查看，fg命令恢复任务到前台，bg命令恢复任务到后台。如若有多个被暂停会显示ID，fg、bg默认会恢复优先级较高的，可以加ID恢复指定任务。也可在建立任务时直接丢到后台去运行：

```
[root@localhost ~]# vmstat 1 > /tmp/1.log &

[3] 51134

[root@localhost ~]# jobs

[2]+  Stopped                 vim test1.txt

[3]-  Running                 vmstat 1 > /tmp/1.log &
```

 
&emsp;&emsp;丢到后台的任务在没有退出刚才的shell的情况下，可以通过使用 fg id 把任务掉到前台，然后使用 Ctrl+c 结束任务。

```
[root@localhost ~]# fg

vmstat 1 > /tmp/1.log

^C

[root@localhost ~]# jobs

[2]+  Stopped                 vim test1.txt
```

&emsp;&emsp;如果关闭了当前的shell，再次打开另一个shell时，使用jobs命令并不会显示在后台运行或者被暂停的任务，要想停掉它的话，则需要知道其pid，然后使用 kill 命令杀死那个进程。


```
[root@localhost ~]# jobs

[root@localhost ~]# ps aux|grep vmstat

root     51134  0.0  0.0   6260   688 ?        S    11:28   0:00 vmstat 1

root     51155  0.0  0.0 103316   896 pts/0    S+   11:35   0:00 grep vmstat

[root@localhost ~]# kill 51134

[root@localhost ~]# ps aux|grep vmstat

root     51157  0.0  0.0 103316   896 pts/0    S+   11:36   0:00 grep vmstat
```

&emsp;&emsp;kill命令很简单，直接在后面加pid即可，如果遇到杀不死的进程时，可以在kill后面加一个选项：`kill -9 [pid]`
