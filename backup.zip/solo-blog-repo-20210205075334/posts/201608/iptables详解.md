title: iptables 详解
date: '2016-08-13 21:15:42'
updated: '2016-08-13 21:15:42'
tags: [iptables, 防火墙]
permalink: /articles/2016/08/13/1471094142345.html
---
# iptables 详解
&emsp;&emsp;iptables是防火墙（netfileter）的一个实现工具，功能非常丰富，CentOS上默认是设有iptables规则的，这个规则很安全，但是可能会造成某些影响，所以建议先清楚规则，再保存一下。



```
[root@localhost ~]# iptables -nvL

Chain INPUT (policy ACCEPT 0 packets, 0 bytes)

 pkts bytes target     prot opt in     out     source               destination

 102K   99M ACCEPT     all  --  *      *       0.0.0.0/0            0.0.0.0/0           state RELATED,ESTABLISHED

    0     0 ACCEPT     icmp --  *      *       0.0.0.0/0            0.0.0.0/0

    2   120 ACCEPT     all  --  lo     *       0.0.0.0/0            0.0.0.0/0

   17   884 ACCEPT     tcp  --  *      *       0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:22

 4214  328K REJECT     all  --  *      *       0.0.0.0/0            0.0.0.0/0           reject-with icmp-host-prohibited



Chain FORWARD (policy ACCEPT 0 packets, 0 bytes)

 pkts bytes target     prot opt in     out     source               destination

    0     0 REJECT     all  --  *      *       0.0.0.0/0            0.0.0.0/0           reject-with icmp-host-prohibited



Chain OUTPUT (policy ACCEPT 172 packets, 32208 bytes)

 pkts bytes target     prot opt in     out     source               destination



Chain VL (0 references)

 pkts bytes target     prot opt in     out     source               destination




[root@localhost ~]# iptables -F;/etc/init.d/iptables save

iptables：将防火墙规则保存到 /etc/sysconfig/iptables：     [确定]
```


&emsp;&emsp;-nvL 就是查看规则，-F 是把当前规则清除，但这个只是临时的，重启系统或者重启iptables服务后还会加载已经保存的规则，所以需要使用“/etc/init.d/iptables save”保存规则，防火墙规则被保存在 /etc/sysconfig/iptables 里。



&emsp;&emsp;**iptables 的三个表**



&emsp;&emsp;filter 表主要用于过滤包，是系统预设的表，内建三个链 INPUT、OUTPUT 以及 FORWARD。INPUT作用于进入本机的包，OUTPUT作用于本机送出的包，FORWARD 作用于那些跟本机无关的包。

&emsp;&emsp;nat 表主要用于网络地址转换，也有三个链。PREROUTING 链的作用是在包刚刚到达防火墙时改变它的目的地址。 OUTPUT链改变本地产生的包的目的地址。POSTROUTING 链在包就要离开防火墙之前改变其源地址。

&emsp;&emsp;mangle 表主要是用于给数据打标记，然后根据标记去操作哪些包。



&emsp;&emsp;**iptables 基本语法**



&emsp;&emsp;（1）查看规则以及清除规则



```
[root@localhost ~]# iptables -t nat -nvL

Chain PREROUTING (policy ACCEPT 0 packets, 0 bytes)

 pkts bytes target     prot opt in     out     source               destination



Chain POSTROUTING (policy ACCEPT 0 packets, 0 bytes)

 pkts bytes target     prot opt in     out     source               destination



Chain OUTPUT (policy ACCEPT 0 packets, 0 bytes)

 pkts bytes target     prot opt in     out     source               destination
```



&emsp;&emsp;-t 后面跟表名，-nvL即查看该表的规则，其中-n表示不针对IP反解析主机名，-L表示列出的意思，而 -v 表示列出的信息更加详细。如果不加 -t ，则打印filter表的相关信息。



```
[root@localhost ~]# iptables -F

[root@localhost ~]# iptables -Z
```


&emsp;&emsp;不加 -t 默认是对表 filter 来操作的， -F 表示把所有规则全部删除，-Z 表示把包以及流量计数器置零。



&emsp;&emsp;（2）增加/删除一条规则



```
[root@localhost ~]# iptables -A INPUT -s 10.72.11.12 -p tcp --sport 1234 -d 10.72.137.159 --dport 80 -j DROP
```




&emsp;&emsp;这就是增加了一条规则，省略了-t，所以针对的是filter表。-A 表示增加一条规则，另外 -I 表示插入一条规则， -D 删除一条规则。后面的 INPUT 即链名称，还可以是OUTPUT , FORWARD。 -s 后跟源地址， -p 协议（tcp，udp，icmp），--sport/--dport 后跟源端口/目标端口，-d 后跟目的IP（主要针对内网或者外网），-j 后跟动作（DROP即把包丢掉，REJECT即报拒绝，ACCEPT即允许包）。例：



```
[root@localhost ~]# iptables -I INPUT -s 1.1.1.1 -j DROP
```


&emsp;&emsp;此例表示：插入一条规则，把来自1.1.1.1的所有数据包丢掉。



```
[root@localhost ~]# iptables -D INPUT -s 1.1.1.1 -j DROP
```


&emsp;&emsp;此例表示：删除上例中建立的规则，要注意的是删除规则时，要和建立的规则一致，即只有 -I 和 -D 不一样，其他都一样。



```
[root@localhost ~]# iptables -I INPUT -s 2.2.2.2 -p tcp --dport 80 -j DROP
```


&emsp;&emsp;此例表示：把来自2.2.2.2并且是tcp协议到本机的80端口的数据包丢掉。--dport/--sport 必须要和 -p 选项一起使用，否则会出错。



```
[root@localhost ~]# iptables -I OUTPUT -p tcp --dport 22 -d 10.0.1.14 -j DROP
```


&emsp;&emsp;此例表示：把发送到10.0.1.14的22端口的数据包丢掉。



```
[root@localhost ~]# iptables -I INPUT -m iprange --src-range 61.4.176.0-61.4.191.255 -j DROP
```


&emsp;&emsp;此例表示：插入一条规则，把来自61.4.176.0-61.4.191.255网段的数据包丢掉。



&emsp;&emsp;总结：



&emsp;&emsp;&emsp;-A/-D：增加或删除一条规则；

&emsp;&emsp;&emsp;-I：插入一条规则，跟 -A 的区别在于它能插队；

&emsp;&emsp;&emsp;-p：指定协议，可以是 tcp，udp，icmp；

&emsp;&emsp;&emsp;--dport：跟 -p 一起使用，指定目标端口；

&emsp;&emsp;&emsp;--sport：跟 -p 一起使用，指定源端口；

&emsp;&emsp;&emsp;-s：指定源 IP（可以是一个ip段）；

&emsp;&emsp;&emsp;-d：指定目的 IP（可以是一个ip段）；

&emsp;&emsp;&emsp;-j：后跟动作，其中ACCEPT表示允许包，DROP表示丢掉包，REJECT表示拒绝包；

&emsp;&emsp;&emsp;-i：指定网卡；

&emsp;&emsp;&emsp;-m iprange --src-range：针对一个网段，比192.168.1.0/24的形式灵活



```
[root@localhost ~]# iptables -A INPUT -s 192.168.1.0/24 -i eth0 -j ACCEPT

[root@localhost ~]# iptables -nvL |grep '192.168.1.0/24'

    0     0 ACCEPT     all  --  eth0   *       192.168.1.0/24       0.0.0.0/0
```


&emsp;&emsp;此例表示，把来自 192.168.1.0/24 这个网段的作用在 eth0 上的包放行。



&emsp;&emsp;利用ID删除规则：

&emsp;&emsp;有时iptables过多了，想删除某条规则时想不起来当时创建的规则了，可以用一种简单的方法。



```
[root@localhost ~]# iptables -nvL --line-numbers

Chain INPUT (policy ACCEPT 100 packets, 8032 bytes)

num   pkts bytes target     prot opt in     out     source               destination

1        0     0 ACCEPT     all  --  eth0   *       192.168.1.0/24       0.0.0.0/0



Chain FORWARD (policy ACCEPT 0 packets, 0 bytes)

num   pkts bytes target     prot opt in     out     source               destination



Chain OUTPUT (policy ACCEPT 68 packets, 8016 bytes)

num   pkts bytes target     prot opt in     out     source               destination



Chain VL (0 references)

num   pkts bytes target     prot opt in     out     source               destination
```


&emsp;&emsp;这时可用num项删除： -D后跟链名，然后是规则num。



```
[root@localhost ~]# iptables -D INPUT 1

[root@localhost ~]# iptables -nvL

Chain INPUT (policy ACCEPT 24 packets, 1856 bytes)

 pkts bytes target     prot opt in     out     source               destination



Chain FORWARD (policy ACCEPT 0 packets, 0 bytes)

 pkts bytes target     prot opt in     out     source               destination



Chain OUTPUT (policy ACCEPT 15 packets, 1592 bytes)

 pkts bytes target     prot opt in     out     source               destination



Chain VL (0 references)

 pkts bytes target     prot opt in     out     source               destination
```




&emsp;&emsp;iptables 还有一个选项经常用到，-P 选项，表示预设策略。



```
[root@localhost ~]# iptables -P INPUT DROP
```


&emsp;&emsp;-P 后面跟链名，策略内容或者为DROP或者为ACCEPT，默认是ACCEPT。注意如果是在远程连接服务器，敲完这个命令就断掉了。这个策略一旦设定，只能使用 iptables -P INPUT ACCEPT 才能恢复成原始状态，而不能使用 -F 参数。

     

&emsp;&emsp;应用例子：

&emsp;&emsp;只针对filter表，预设策略INPUT链DROP，其他两个链ACCEPT，然后针对192.168.56.0/24 开放 22 端口，对所有网段开放80端口，对所有网段开放21端口。多条规则，最好写成脚本的形式。



```
[root@localhost ~]# cat /usr/local/sbin/iptables.sh

#!/bin/bash

ipt="/sbin/iptables"

$ipt -F

$ipt -P INPUT DROP

$ipt -P OUTPUT ACCEPT

$ipt -P FORWARD ACCEPT

$ipt -A INPUT -s 192.168.56.0/24 -p tcp --dport 22 -j ACCEPT

$ipt -A INPUT -p tcp --dport 80 -j ACCEPT

$ipt -A INPUT -p tcp --dport 21 -j ACCEPT
```


&emsp;&emsp;完成脚本的编写后，直接运行 /bin/sh   /usr/local/sbin/iptables.sh 即可。如果想开机启动初始化防火墙规则，需要在 /etc/rc.d/rc.local 中添加一行“/bin/sh  /usr/local/sbin/iptables.sh”



```
[root@localhost ~]#sh /usr/local/sbin/iptables.sh

[root@localhost ~]# iptables -nvL

Chain INPUT (policy ACCEPT 37 packets, 3688 bytes)

 pkts bytes target     prot opt in     out     source               destination

 5223  253K ACCEPT     tcp  --  *      *       192.168.56.0/24      0.0.0.0/0           tcp dpt:22

    0     0 ACCEPT     tcp  --  *      *       0.0.0.0/0            0.0.0.0/0           tcp dpt:80

    0     0 ACCEPT     tcp  --  *      *       0.0.0.0/0            0.0.0.0/0           tcp dpt:21



Chain FORWARD (policy ACCEPT 0 packets, 0 bytes)

 pkts bytes target     prot opt in     out     source               destination



Chain OUTPUT (policy ACCEPT 9527 packets, 2596K bytes)

 pkts bytes target     prot opt in     out     source               destination



Chain VL (0 references)

 pkts bytes target     prot opt in     out     source               destination
```


          

&emsp;&emsp;关于icmp的包有一个比较常用的应用：



```
[root@localhost ~]# iptables -I INPUT -p icmp --icmp-type 8 -j DROP
```


&emsp;&emsp;--icmp-type 选项是要跟 -p icmp 一起使用的，后面指定类型编号。这个8指的是能在本机ping通其他机器，而其他机器不能ping通本机。



&emsp;&emsp;**nat 表的应用**



&emsp;&emsp;路由转发功能。我们日常生活中用到的路由器的功能就是分享上网。本来一根网线过来（一个公网IP），通过路由器后，路由器分配了一个网段（私网IP），这样连接路由器的多台PC机都能连接internet，而远端的设备认为你的IP就是那个连接路由器的公网IP。这个路由器的功能其实就是由Linux的netfileter的nat表实现的。

&emsp;&emsp;举个例子，假设机器上有两块网卡 eth0 和 eth1，其中 eth0 的 IP 为10.0.2.68，eth1 的 IP 为192.168.1.1 。eth0 连接了internet 但 eth1 没有连接，现在有另一台机器（192.168.1.2）和 eth1 是互通的，那么就可以设置让连接 eth1 的这台机器连接 internet 了。



```
[root@localhost ~]# echo "1" > /proc/sys/net/ipv4/ip_forward

[root@localhost ~]# iptables -t nat -A POSTROUTING -s 192.168.1.0/24 -o eth0 -j MASQUERADE
```


&emsp;&emsp;第一个命令涉及到了内核参数相关的配置文件，它的目的是为了打开路由转发功能。第二个命令是对 nat 表做了一个 IP 转发的操作，-o 选项后跟设备名，表示出口的网卡，MASQUERADE 表示伪装的意思。



&emsp;&emsp;**保存以及备份 iptables 规则**

&emsp;&emsp;之前设定的规则只是保存在内存中，并没有保存到某一个文件中，所以当系统重启后以前设定的规则就没有了，所以设定好的规则要保存一下。



```
[root@localhost ~]# service iptables save

iptables：将防火墙规则保存到 /etc/sysconfig/iptables：     [确定]
```


&emsp;&emsp;它会提示把防火墙规则保存到了/etc/sysconfig/iptables文件内，这个文件就是iptables的配置文件了。备份防火墙规则的任务就是拷贝一份这个文件的副本。

&emsp;&emsp;有时，可以使用iptables -F把防火墙规则清除，但是最好的办法是把防火墙服务停止：



```
[root@localhost ~]# service iptables stop

iptables：将链设置为政策 ACCEPT：filter nat                [确定]

iptables：清除防火墙规则：                                 [确定]

iptables：正在卸载模块：                                   [确定]
```


&emsp;&emsp;这样防火墙就失效了，但是一旦重新设定规则后，防火墙服务就会自动开启。

&emsp;&emsp;备份防火墙规则和恢复规则：



```
[root@localhost ~]# sh /usr/local/sbin/iptables.sh

[root@localhost ~]# iptables-save > myipt.rule

[root@localhost ~]# cat myipt.rule

# Generated by iptables-save v1.4.7 on Mon May 16 19:57:00 2016

*filter

:INPUT DROP [0:0]

:FORWARD ACCEPT [0:0]

:OUTPUT ACCEPT [32:3360]

-A INPUT -s 192.168.56.0/24 -p tcp -m tcp --dport 22 -j ACCEPT

-A INPUT -p tcp -m tcp --dport 80 -j ACCEPT

-A INPUT -p tcp -m tcp --dport 21 -j ACCEPT

COMMIT

# Completed on Mon May 16 19:57:00 2016

[root@localhost ~]# iptables-restore < myipt.rule
```


&emsp;&emsp;首先设定一下规则，让防火墙服务启动。使用iptables-save 命令重定向到一个文件。而恢复规则使用 iptables-restore < myipt.rule 。
