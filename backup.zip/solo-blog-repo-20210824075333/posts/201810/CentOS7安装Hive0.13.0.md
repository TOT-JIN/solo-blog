title: CentOS7 安装 Hive-0.13.0
date: '2018-10-04 09:53:35'
updated: '2018-10-04 09:53:35'
tags: [Hadoop, Hive, 大数据]
permalink: /articles/2018/10/04/1538618015733.html
---
## 0. 准备安装环境

继 [CentOS7 安装 hadoop-1.2.1](https://17kblog.com/articles/2018/10/03/1538531615733.html) 准备安装环境

## 1.安装 MySQL 服务端和客户端

### 1.1 添加 mysql5.7 仓库

```bash
[root@master ~]# rpm -ivh https://dev.mysql.com/get/mysql57-community-release-el7-11.noarch.rpm
[root@master ~]# yum makecache fast
```

### 1.2 安装 MySQL

```bash
[root@master ~]# yum -y install mysql-community-server
```

### 1.3 启动

```bash
[root@master ~]# systemctl start mysqld
```

### 1.4 安全设置

* 查看默认 root 密码：

  ```bash
  [root@master ~]# cat /var/log/mysqld.log | grep -i 'temporary password'
  ```
* 更改 root 密码，移除匿名用户：

  ```bash
  [root@master ~]# mysql_secure_installation
  ```

## 2.安装 Hive

下载 Hive 安装包到 */usr/local/src* 目录

> https://archive.apache.org/dist/hive/hive-0.13.0/apache-hive-0.13.0-bin.tar.gz

解压到 */usr/local* 目录下

```bash
[root@master local]# pwd
/usr/local
[root@master local]# ls src/apache-hive-0.13.0-bin.tar.gz
src/apache-hive-0.13.0-bin.tar.gz
[root@master local]# tar zxf src/apache-hive-0.13.0-bin.tar.gz
[root@master local]# cd apache-hive-0.13.0-bin/
[root@master apache-hive-0.13.0-bin]# pwd
/usr/local/apache-hive-0.13.0-bin
```

创建配置文件

```xml
[root@master conf]# pwd
/usr/local/apache-hive-0.13.0-bin/conf
[root@master conf]# cat hive-site.xml
<configuration>
    <property>
        <name>javax.jdo.option.ConnectionURL</name>
        <value>jdbc:mysql://localhost:3306/hive?createDatabaseIfNotExist=true&useSSL=false</value>
    </property>

    <property>
        <name>javax.jdo.option.ConnectionDriverName</name>
        <value>com.mysql.jdbc.Driver</value>
    </property>

    <property>
        <name>javax.jdo.option.ConnectionUserName</name>
        <value>root</value>
    </property>

    <property>
        <name>javax.jdo.option.ConnectionPassword</name>
        <value>Az123456_</value>
    </property>
</configuration>
```

修改 bashrc，配置环境变量

```bash
[root@master ~]# tail -n10 /etc/bashrc
# Hbase conf
export HBASE_HOME=/usr/local/hbase-0.98.24-hadoop1
export HBASE_CLASSPATH=$HBASE_HOME/conf
export HBASE_LOG_DIR=$HBASE_HOME/logs

# Hive conf
export HIVE_HOME=/usr/local/apache-hive-0.13.0-bin

export CLASSPATH=.:$CLASSPATH:$JAVA_HOME/lib
export PATH=$JAVA_HOME/bin:/usr/local/hadoop-1.2.1/bin:$ZOOKEEPER_HOME/bin:$HBASE_HOME/bin:$HIVE_HOME/bin:$PATH
[root@master ~]# source /etc/bashrc
```

将 *mysql-connector-java-5.1.41-bin.jar* 拷贝到 hive home 的 lib 目录下，以支持 hive 对 mysql 的连接操作。

```bash
[root@master lib]# pwd
/usr/local/apache-hive-0.13.0-bin/lib
[root@master lib]# ls mysql-connector-java-5.1.41-bin.jar
mysql-connector-java-5.1.41-bin.jar
```

测试 Hive

```bash
[root@master ~]# hive

Logging initialized using configuration in jar:file:/usr/local/apache-hive-0.13.0-bin/lib/hive-common-0.13.0.jar!/hive-log4j.properties
hive> show tables;
OK
Time taken: 0.385 seconds
```

## 3. 简单操作

* 创建表

```bash
hive> create EXTERNAL TABLE w_a
    > (
    > usrid STRING,
    > age STRING,
    > sex STRING
    > )
    > ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    > LINES TERMINATED BY '\n';
OK
Time taken: 0.241 seconds
hive> show tables;
OK
w_a
Time taken: 0.02 seconds, Fetched: 1 row(s)
```

> 此时 hive 会在 hdfs 中创建对应目录
>
> ```
> [root@master ~]# hadoop fs -ls /user/hive/warehouse
> Warning: $HADOOP_HOME is deprecated.
>
> Found 1 items
> drwxr-xr-x   - root supergroup          0 2019-12-06 09:54 /user/hive/warehouse/w_a
> ```
