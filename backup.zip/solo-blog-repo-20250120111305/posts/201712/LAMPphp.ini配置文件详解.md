title: LAMP--php.ini 配置文件详解
date: '2017-12-15 08:24:51'
updated: '2017-12-15 08:24:51'
tags: [lamp, php]
permalink: /articles/2017/12/15/1513297491673.html
---
# LAMP--php.ini 配置文件详解
在/usr/local/php/etc/目录下面有个 php.ini 文件，是之前编译安装php时拷贝进去的。有的时候我们并不知道 php.ini 所在路径，这时候就需要通过命令来查一查在哪儿。

```e-bash
[root@localhost ~]# /usr/local/php/bin/php -i |head
phpinfo()
PHP Version => 5.6.10
System => Linux localhost 2.6.32-573.el6.x86_64 #1 SMP Thu Jul 23 15:44:03 UTC 2015 x86_64
Build Date => May 17 2016 22:49:08
Configure Command =>  './configure'  '--prefix=/usr/local/php' '--with-apxs2=/usr/local/apache2/bin/apxs' '--with-config-file-path=/usr/local/php/etc' '--with-mysql=/usr/local/mysql' '--with-libxml-dir' '--with-gd' '--with-jpeg-dir' '--with-png-dir' '--with-freetype-dir' '--with-iconv-dir' '--with-zlib-dir' '--with-bz2' '--with-openssl' '--with-mcrypt' '--enable-soap' '--enable-gd-native-ttf' '--enable-mbstring' '--enable-sockets' '--enable-exif' '--disable-ipv6'
Server API => Command Line Interface
Virtual Directory Support => disabled
Configuration File (php.ini) Path => /usr/local/php/etc
Loaded Configuration File => /usr/local/php/etc/php.ini
```



Loaded Configuration File 一行指示了 php.ini 的位置，如果这里为 None ，那么就说明没有加载到具体的 php.ini 。找到 php.ini 后，用 vim 打开它，会发现好多行都是以 ; 号开头的，这个符号在 php.ini 中作为注释符号。而 php.ini 中常用的配置如下：

（1）配置 disable_function

在php中有非常多的函数，在这些函数中有一些是不×××全的，所以有必要把它们禁掉，像 exec，shell_exec 都是在 php 代码中执行 linux shell 命令，很危险，要禁掉。使用 vim 打开 php.ini ，找到 disable_functions = 这一行，默认是没有东西的，我们在后面添加：

```e-bash
[root@localhost ~]# vim /usr/local/php/etc/php.ini
disable_functions = eval,assert,popen,passthru,escapeshellarg,escapeshellcmd,passthru,exec,system,chroot,scandir,chgrp,chown,escapeshellcmd,escapeshellarg,shell_exec,proc_get_status,ini_alter,ini_restore,dl,pfsockopen,openlog,syslog,readlink,symlink,leak,popepassthru,stream_socket_server,popen,proc_open,proc_close
```



（2）配置 error_log

作为运维人员，理应学会简单的 php 错误排查技能，其实 php 的错误跟 linux 下其他服务都是一样的，遇到错误后要查看错误日志，根据报错信息来判断错误的原因。那如何查看 php 的错误信息呢？遇到错误时，我们访问的网站通常会显示白页，什么都没有，状态码是 500。两种查看方法，第一种是直接把错误信息显示在浏览器中，配置方法是在 php.ini 中找到 display_error=on，重启 apache 服务后，刷新网页，发现不再是空白，而是具体的错误。这就可以根据错误来调试 php 代码了。这种情况适合临时调试，不适合长期配置，因为所有的错误信息都会显示在浏览器上，那么用户就会直接看到这些错误，这样不合适。所以有第二种方法，把错误信息输出到一个日志文件中，具体配置如下：

```e-bash
[root@localhost ~]# vim /usr/local/php/etc/php.ini
display_errors = Off
log_errors = On
error_log=/usr/local/php/logs/error.log       // 该文件一开始不存在，为了避免权限问题不能自动生成该文件，可以先创建该文件，并且修改权限为 777
error_reporting = E_ALL | E_STRICT
```



说明：首先要把错误不在浏览器显示，第二打开错误日志开关，然后指定错误日志的路径，最后是定义错误日志的级别。配置完成后记得要重启 apache 服务，才会生效。

（3）配置 open_basedir

在 php 中是有这个 open_basedir 概念的，它的意思是，把执行 php 的用户限定在指定的路径下，这样通过权限缩小的方式达到安全目的。作为一个网站，只需要让 php 用户访问到网站的代码即可，没有必要让它去访问其他目录。

```e-bash
[root@localhost ~]# vim /usr/local/php/etc/php.ini
open_basedir = /dir1/:/dir2
```



说明：/dir1 和 /dir2 为我们允许 php 可以访问的两个目录，同样也可以是多个，目录之间用 ： 分隔。一旦限定后，如果 php 试图去访问 /dir1 和 /dir2 之外的目录下的文件时，就会报错了。错误类似于，Warning: file_exists() [function.file-exists]: open_basedir restriction in effect. File(../123.php) is not with in the allowed path(s):

          

除了在 php.ini 中定义 open_basedir 外，还可以在apache的配置文件中定义，因为一个 apache下可能有多个站点，我们要针对不同的站点做不同的限制，打开主机配置文件或虚拟主机配置文件，添加如下语句：

```e-bash
 [root@localhost ~]# vim /usr/local/apache2/conf/extra/httpd-vhosts.conf
php_admin_value open_basedir "/dir1/:/dir2/"
```
