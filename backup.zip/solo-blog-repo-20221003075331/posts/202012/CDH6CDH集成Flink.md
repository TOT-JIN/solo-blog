title: 【CDH6】CDH 集成 Flink
date: '2020-12-20 22:31:48'
updated: '2020-12-20 22:31:48'
tags: [大数据, CDH, Flink]
permalink: /articles/2020/12/20/1608474708314.html
---
1. 下载Flink jar 工具包
   Flink jar 工具包主要是让 Cloudera Manager 来支持 Flink 服务安装，下载Flink jar工具包并上传到本地服务器：

   ```
   [root@cm-s1 ~]# wget https://archive.cloudera.com/csa/1.0.0.0/csd/FLINK-1.9.0-csa1.0.0.0-cdh6.3.0.jar -P /opt/cloudera/csd
   ```
2. 下载 Flink parcels 文件
   Flink parcels文件中含有Flink的安装包，下载Flink Parcels时，需要下载以下三个文件：

   ```
   [root@cm-s1 ~]# wget https://archive.cloudera.com/csa/1.0.0.0/parcels/FLINK-1.9.0-csa1.0.0.0-cdh6.3.0-el7.parcel -P /opt/cloudera/parcel-repo
   [root@cm-s1 ~]# wget https://archive.cloudera.com/csa/1.0.0.0/parcels/FLINK-1.9.0-csa1.0.0.0-cdh6.3.0-el7.parcel.sha -P /opt/cloudera/parcel-repo
   [root@cm-s1 ~]# wget https://archive.cloudera.com/csa/1.0.0.0/parcels/manifest.json -O /opt/cloudera/parcel-repo/manifest.json
   ```
3. 分配 parcel 进行安装
   进入Cloudea Manager平台中，点击“主机”，选择“Parcel”，进入parcel管理页面。
   ![image20201220210237796.png](https://b3logfile.com/file/2020/12/image20201220210237796-4790918f.png)
   点击“检查新Parcel”，刷新几次就可以看到对应的Flink Parcel出现，如下图：
   ![image20201220210638446.png](https://b3logfile.com/file/2020/12/image20201220210638446-21e0155f.png)
   点击分配，会将parcel分发到其他Agent节点，并自动完成解压。
   ![image20201220210833111.png](https://b3logfile.com/file/2020/12/image20201220210833111-d6b5bc92.png)
   点击激活，激活就是在Linux中创建对应的Flink一些目录和用户，激活成功后可以在集群中添加Flink服务。
4. 重启Cloudera Manager服务
   需重启CM服务，加载Flink jar 工具包，以支持Flink服务。

   ```
   [root@cm-s1 ~]# systemctl restart cloudera-scm-server.service
   [root@cm-s1 ~]# for i in `seq 0 3`;do ssh root@192.168.0.5$i systemctl restart cloudera-scm-agent.service;done
   ```

   重新访问CM，并根据提示在页面上点击重启CM Serivce
   ![image20201220212018007.png](https://b3logfile.com/file/2020/12/image20201220212018007-29956a34.png)
5. 添加 Flink 服务
   打开CM主页，找到对应的集群，添加 Flink 服务。
   ![image20201220212220212.png](https://b3logfile.com/file/2020/12/image20201220212220212-ef98fa56.png)
   ![image20201220212323191.png](https://b3logfile.com/file/2020/12/image20201220212323191-35aecdc3.png)
   选择Flink HistoryServer和Flink客户端：
   ![image20201220212624791.png](https://b3logfile.com/file/2020/12/image20201220212624791-b994dd80.png)
   点击“继续”，“审核更改”中可以不做修改，点击“继续”->”完成”。最后结果Flink服务实例安装完成。
   ![image20201220214239646.png](https://b3logfile.com/file/2020/12/image20201220214239646-df255814.png)
