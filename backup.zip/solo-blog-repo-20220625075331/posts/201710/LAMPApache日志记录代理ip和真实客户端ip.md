title: LAMP--Apache 日志记录代理 ip 和真实客户端 ip
date: '2017-10-31 19:52:11'
updated: '2017-10-31 19:52:11'
tags: [lamp, httpd, 代理]
permalink: /articles/2017/10/31/1509450731673.html
---
# LAMP--Apache 日志记录代理 ip 和真实客户端 ip
默认的log日志格式在主配置文件 httpd.conf 中可以看到：

```e-bash
[root@localhost ~]# vim /usr/local/apache2/conf/httpd.conf
    LogFormat "%h %l %u %t \"%r\" %>s %b \"%{Referer}i\" \"%{User-Agent}i\"" combined
    LogFormat "%h %l %u %t \"%r\" %>s %b" common
```



其中 %h 是记录访问者的 IP，如果在 web 的前端有一层代理，那么这个 %h 其实就是代理机器的 IP，这不是我们想要的。在这种情况下，%{X-FORWARDED-FOR}i 字段会记录客户端真实的ip。所以配置文件改为：

```e-bash
    LogFormat "%h %{X-FORWARDED-FOR}i %l %u %t \"%r\" %>s %b \"%{Referer}i\" \"%{User-Agent}i\"" combined
    LogFormat "%h %l %u %t \"%r\" %>s %b" common
```
