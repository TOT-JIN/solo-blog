title: MacOS 挂载目录到另一个目录
date: '2020-12-22 11:37:07'
updated: '2020-12-22 11:40:37'
tags: [MacOS, mount, bindfs, 开机启动]
permalink: /articles/2020/12/22/1608608227214.html
---
需求场景：系统盘太小需要将占用存储空间较大的目录放到其他硬盘上，而又希望能在finder中的原位置进行管理
系统环境：已经将第二块硬盘分区并挂载到了指定目录：

```
~/ cat /etc/fstab   #开机挂载分区到指定目录 /exsdd 下，不希望默认挂载到 /Volumes/xxx 目录
UUID=446B26AD-A387-4BEF-8F1A-07780B5F7955   /exsdd  apfs    rw,auto,nobrowse
~/ mount
/dev/disk4s1 on / (apfs, local, journaled)
devfs on /dev (devfs, local, nobrowse)
/dev/disk4s4 on /private/var/vm (apfs, local, noexec, journaled, noatime, nobrowse)
/dev/disk3s1 on /exsdd (apfs, local, journaled, nobrowse)
/dev/disk0s2 on /Volumes/snap (hfs, local, journaled)
```

# Mac OS X下使用bindfs实现mount的目录绑定功能

Linux下的mount命令有一个 `--bind`参数，将目录挂载到另一个目录下。Mac OS X的mount命令不支持 `--bind`，不过我们可以使用[bindfs](http://code.google.com/p/bindfs/)实现相同的功能。

bindfs是一个基于[FUSE](http://fuse.sourceforge.net/)的文件系统实现，并非Mac OS X的预装工具，但通过Homebrew安装非常简单。

```
brew install bindfs
```

bindfs的使用也非常简单，跟 `mount --bind`基本一样。

## 创建并挂载目录

此时，我们将用户家目录下的Downloads和Movies目录外挂到另一块硬盘（分区）所在的目录中。

1. 在/exsdd目录下创建源目录:

   ```
   sudo mkdir /exsdd/Downloads /exsdd/Movies
   sudo chown username:admin /exsdd/Downloads /exsdd/Movies
   ```
2. 挂载源目录到目标目录
   对于具有权限的目录，可以不用 sudo

   ```
   sudo bindfs /exsdd/Downloads /Users/username/Downloads
   sudo bindfs /exsdd/Movies /Users/username/Movies
   ```


   执行 `mount`命令，可查看挂载情况

## 配置开机启动挂载

这里仍然采用 Linux 中/etc/rc.local的形式，但Mac OS没有/etc/rc.local这个文件，需要创建并让它识别。

1. 修改LaunchDaemons的配置
   进入 `/Library/LaunchDaemons`目录，并创建 `local.localhost.startup.plist`文件

   ```
   cd /Library/LaunchDaemons
   sudo vim local.localhost.startup.plist
   ```

   写入如下内容：

   ```
   <?xml version="1.0" encoding="UTF-8"?>
   <!DOCTYPE plist PUBLIC "-//Apple Computer//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
   <plist version="1.0">
       <dict>
           <key>Label</key>
           <string>local.localhost.startup</string>
           <key>Disabled</key>
           <false/>
           <key>RunAtLoad</key>
           <true/>
           <key>KeepAlive</key>
           <false/>
           <key>LaunchOnlyOnce</key>
           <true/>
           <key>ProgramArguments</key>
           <array>
               <string>/etc/rc.local</string>
           </array>
       </dict>
   </plist>
   ```

   加载 `local.localhost.startup.plist`文件

   ```
   sudo launchctl load -w ./local.localhost.startup.plist
   ```
2. 创建 rc.local 文件
   创建 `/etc/rc.loca`文件，并写入开机即执行的命令:

   ```
   sudo vim /etc/rc.local
   ```
   ```
   #!/usr/local/bin/bash
   /usr/local/bin/bindfs /exsdd/Downloads /Users/username/Downloads
   /usr/local/bin/bindfs /exsdd/Movies /Users/username/Movies
   ```

   赋予rc.local文件可执行权限

   ```
   sudo chmod a+x /etc/rc.local
   ```
3. 重启系统，验证生效
