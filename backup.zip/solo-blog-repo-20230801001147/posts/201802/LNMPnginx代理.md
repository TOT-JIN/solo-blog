title: LNMP--nginx 代理
date: '2018-02-21 11:24:31'
updated: '2018-02-21 11:24:31'
tags: [lnmp, nginx, 代理]
permalink: /articles/2018/02/21/1519183471733.html
---
# LNMP--nginx 代理
&emsp;&emsp;如果Nginx后面有多天Web服务器，如果同事代理，那Nginx在这里就起到一个负载均衡的作用。




```
$ vim proxy.conf

server{

        listen 80;

        server_name test.com;

​

        location / {

               proxy_pass         http://192.168.0.23/;

               proxy_set_header Host          $host;

               proxy_set_header X-Real-IP         $remote_addr;

               proxy_set_header X-Forwarded-For        $proxy_add_x_forwarded_for;

        }

}

```


&emsp;&emsp;负载均衡



```
upstream 123.com {

      server 127.0.0.1:8881;

      server 127.0.0.1:8882;

      server 127.0.0.1:8888;

}
```


```
server{

    listen 80;

    server_name 123.com;

    location / {

        proxy_pass         http://123.com;

        proxy_set_header   Host             $host;

        proxy_set_header   X-Real-IP        $remote_addr;

        proxy_set_header   X-Forwarded-For  $proxy_add_x_forwarded_for;

    }

}
```
