title: selinux 关闭
date: '2016-08-13 11:45:52'
updated: '2016-08-13 11:45:52'
tags: [selinux]
permalink: /articles/2016/08/13/1471059952345.html
---
# selinux 关闭
&emsp;&emsp;Selinux是Redhat/CentOS系统特有的安全机制。不过因为其限制太多，配置繁琐所以几乎没人用它。所以一般装完系统，都把它关掉，以免引起不必要的麻烦。
&emsp;&emsp;关闭selinux的方法为，使“SELINUX=disabled”，默认为enforcing。



```
[root@localhost ~]# vim /etc/selinux/config



# This file controls the state of SELinux on the system.

# SELINUX= can take one of these three values:

#     enforcing - SELinux security policy is enforced.

#     permissive - SELinux prints warnings instead of enforcing.

#     disabled - No SELinux policy is loaded.

#SELINUX=enforcing

SELINUX=disabled

# SELINUXTYPE= can take one of these two values:

#     targeted - Targeted processes are protected,

#     mls - Multi Level Security protection.

SELINUXTYPE=targeted
```



&emsp;&emsp;保存该配置文件后，重启Linux方可生效，临时关闭selinux的命令为：

```
[root@localhost ~]# setenforce 0

     可以使用getenforce命令获得当前selinux的状态：

[root@localhost ~]# getenforce

Disabled
```

&emsp;&emsp;如果没有配置文件并重启系统，默认会显示 “enforcing”，当使用 setenforce 0这个命令临时关闭selinux后，getenforce会显示“permissive”。
