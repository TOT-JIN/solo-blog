title: mysql 登陆
date: '2018-09-04 12:42:12'
updated: '2018-09-04 12:42:12'
tags: [mysql]
permalink: /articles/2018/09/04/1536036132812.html
---
# mysql 登陆
&emsp;&emsp;mysql 服务启动时，不仅会监听 IP:Port，还会监听一个 socket，我们安装的mysql是监听在 /tmp/mysql.sock。如果 php 是在本地，那么php和mysql通信可以通过socket通信，如果是远程，就需要通过 tcp/ip 来通信了。在linux命令行下，我们可以通过如下方法来连接mysql服务器。

&emsp; **（1）tcp/ip 的方式**

```
[root@128 ~]# mysql -uroot -h 127.0.0.1
```


&emsp;&emsp;这样就连接上了，因为默认mysql的root用户密码为空，所以不用加 -p 选项，我们可以给他设置一个密码：

```
[root@128 ~]# mysqladmin -uroot password 'test123'
```


&emsp;&emsp;这是第一次设置密码时的情况，当要再次设置密码时，就需要先前的密码了。

```
[root@128 ~]# mysqladmin -uroot -ptest123 password 'test1'
```


&emsp;&emsp;此时再去连接，就需要密码了

```
[root@128 ~]# mysql -uroot -ptest1 -h 127.0.0.1

Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 9
Server version: 5.1.73-log MySQL Community Server (GPL)

Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql>
```


&emsp;&emsp; 其中 -h 指定 ip，那如果是远程机器，则 -h 后面跟远程服务器 ip，默认port是3306，如果是其他端口，需要用 -P 来定义。

```
[root@128 ~]# mysql -uroot -ptest1 -h 127.0.0.1 -P3306
```


&emsp;**（2）socket 方式**

&emsp;&emsp;这种只适合连接本机的mysql，命令为：

```
[root@128 ~]# mysql -uroot -S /tmp/mysql.sock -ptest1
```


&emsp;&emsp;其中-S可以省略掉。
