title: shell 变量
date: '2016-10-02 22:13:42'
updated: '2016-10-02 22:13:42'
tags: [shell, 变量]
permalink: /articles/2016/10/02/1475417622856.html
---
# shell 变量
&emsp;&emsp;**曾经学过环境变量PATH，这个环境变量就是shell预设的一个变量。通常shell预设的变量都是大写的。变量，就是一个较简单的字符串来替代某些具有特殊意义的设定以及数据。就拿PATH来讲，这个PATH就替代了所有常用命令的绝对路径的设定。因为有了PATH这个变量，所以我们运行某个命令时不再去输入全局路径，直接敲命令名即可。可以使用 echo 命令显示变量的值。**

```
[root@localhost ~]# echo $PATH
/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
[root@localhost ~]# echo $HOME
/root
[root@localhost ~]# echo $PWD
/root
[root@localhost ~]# echo $LOGNAME
root
```

&emsp;&emsp;**命令 env**

```
[root@localhost ~]# env
HOSTNAME=localhost
TERM=xterm
SHELL=/bin/bash
HISTSIZE=1000
SSH_CLIENT=192.168.56.1 49924 22
SSH_TTY=/dev/pts/0
USER=root
LS_COLORS=rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=01;05;37;41:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arj=01;31:*.taz=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.zip=01;31:*.z=01;31:*.Z=01;31:*.dz=01;31:*.gz=01;31:*.lz=01;31:*.xz=01;31:*.bz2=01;31:*.tbz=01;31:*.tbz2=01;31:*.bz=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.rar=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.jpg=01;35:*.jpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.axv=01;35:*.anx=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=01;36:*.au=01;36:*.flac=01;36:*.mid=01;36:*.midi=01;36:*.mka=01;36:*.mp3=01;36:*.mpc=01;36:*.ogg=01;36:*.ra=01;36:*.wav=01;36:*.axa=01;36:*.oga=01;36:*.spx=01;36:*.xspf=01;36:
MAIL=/var/spool/mail/root
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
PWD=/root
LANG=zh_CN.UTF-8
HISTCONTROL=ignoredups
SHLVL=1
HOME=/root
LOGNAME=root
SSH_CONNECTION=192.168.56.1 49924 192.168.56.128 22
LESSOPEN=||/usr/bin/lesspipe.sh %s
G_BROKEN_FILENAMES=1
_=/bin/env
```


&emsp;&emsp;**使用env命令可列出全部系统预设的系统变量。不过登录的用户不一样这些变量的值也不一样。常见的环境变量：**

&emsp;&emsp;&emsp;PATH决定了shell将到哪些目录中寻找命令或程序

&emsp;&emsp;&emsp;HOME 当前用户的主目录

&emsp;&emsp;&emsp;HISTSIZE 历史记录数

&emsp;&emsp;&emsp;LOGNAME 当前用户的登录名

&emsp;&emsp;&emsp;HOSTNAME 指主机的名称

&emsp;&emsp;&emsp;SHELL 当前用户的shell类型

&emsp;&emsp;&emsp;LANG 语音相关的环境变量，多语言可以修改此环境变量

&emsp;&emsp;&emsp;MAIL 当前用户的邮件存放目录

&emsp;&emsp;&emsp;PWD 当前目录

  
&emsp;&emsp;env命令显示的只是环境变量，系统预设的变量还有很多，可以使用set命令把系统预设的全部变量都显示出来。


&emsp;&emsp;**命令 set**

```
[root@localhost ~]# set
BASH=/bin/bash
BASHOPTS=checkwinsize:cmdhist:expand_aliases:extquote:force_fignore:hostcomplete:interactive_comments:login_shell:progcomp:promptvars:sourcepath
BASH_ALIASES=()
BASH_ARGC=()
BASH_ARGV=()
BASH_CMDS=()
BASH_LINENO=()
BASH_SOURCE=()
BASH_VERSINFO=([0]="4" [1]="1" [2]="2" [3]="1" [4]="release" [5]="x86_64-redhat-linux-gnu")
BASH_VERSION='4.1.2(1)-release'
COLORS=/etc/DIR_COLORS
COLUMNS=80
DIRSTACK=()
EUID=0
GROUPS=()
G_BROKEN_FILENAMES=1
HISTCONTROL=ignoredups
HISTFILE=/root/.bash_history
HISTFILESIZE=1000
HISTSIZE=1000
HOME=/root
HOSTNAME=localhost
HOSTTYPE=x86_64
ID=0
IFS=$' \t\n'
LANG=zh_CN.UTF-8
LESSOPEN='||/usr/bin/lesspipe.sh %s'
LINES=24
LOGNAME=root
LS_COLORS='rs=0:di=01;34:ln=01;36:mh=00:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:mi=01;05;37;41:su=37;41:sg=30;43:ca=30;41:tw=30;42:ow=34;42:st=37;44:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arj=01;31:*.taz=01;31:*.lzh=01;31:*.lzma=01;31:*.tlz=01;31:*.txz=01;31:*.zip=01;31:*.z=01;31:*.Z=01;31:*.dz=01;31:*.gz=01;31:*.lz=01;31:*.xz=01;31:*.bz2=01;31:*.tbz=01;31:*.tbz2=01;31:*.bz=01;31:*.tz=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.rar=01;31:*.ace=01;31:*.zoo=01;31:*.cpio=01;31:*.7z=01;31:*.rz=01;31:*.jpg=01;35:*.jpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.svg=01;35:*.svgz=01;35:*.mng=01;35:*.pcx=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.m2v=01;35:*.mkv=01;35:*.ogm=01;35:*.mp4=01;35:*.m4v=01;35:*.mp4v=01;35:*.vob=01;35:*.qt=01;35:*.nuv=01;35:*.wmv=01;35:*.asf=01;35:*.rm=01;35:*.rmvb=01;35:*.flc=01;35:*.avi=01;35:*.fli=01;35:*.flv=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.yuv=01;35:*.cgm=01;35:*.emf=01;35:*.axv=01;35:*.anx=01;35:*.ogv=01;35:*.ogx=01;35:*.aac=01;36:*.au=01;36:*.flac=01;36:*.mid=01;36:*.midi=01;36:*.mka=01;36:*.mp3=01;36:*.mpc=01;36:*.ogg=01;36:*.ra=01;36:*.wav=01;36:*.axa=01;36:*.oga=01;36:*.spx=01;36:*.xspf=01;36:'
MACHTYPE=x86_64-redhat-linux-gnu
MAIL=/var/spool/mail/root
MAILCHECK=60
OPTERR=1
OPTIND=1
OSTYPE=linux-gnu
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
PIPESTATUS=([0]="0")
PPID=51135
PROMPT_COMMAND='printf "\033]0;%s@%s:%s\007" "${USER}" "${HOSTNAME%%.*}" "${PWD/#$HOME/~}"'
PS1='[\u@\h \W]\$ '
PS2='> '
PS4='+ '
PWD=/root
SHELL=/bin/bash
SHELLOPTS=braceexpand:emacs:hashall:histexpand:history:interactive-comments:monitor
SHLVL=1
SSH_CLIENT='192.168.56.1 49924 22'
SSH_CONNECTION='192.168.56.1 49924 192.168.56.128 22'
SSH_TTY=/dev/pts/0
TERM=xterm
UID=0
USER=root
_=env
colors=/etc/DIR_COLORS
```

&emsp;&emsp;set 不仅显示了系统预设的变量，还把用户自定义的变量显示出来了。

```
[root@localhost ~]# myname=test
[root@localhost ~]# echo $myname
test
[root@localhost ~]# set |grep myname
myname=test
```

&emsp;&emsp;此变量只在当前shell中生效。

```
[root@localhost ~]# echo $myname
test
[root@localhost ~]# bash
[root@localhost ~]# echo $myname

[root@localhost ~]# exit
exit
[root@localhost ~]# echo $myname
test
```

**介绍两种设置的变量一直生效的情况：**

&emsp;（1）要想系统内所有用户登录后都能使用该变量**

&emsp;&emsp;需要在”/etc/profile“文件最末行加入 export myname=Aming 然后运行 source /etc/profile 就可以生效了。此时再运行bash命令或直接 su - test账户可以看到效果。

```
[root@localhost ~]# echo "export myname=test">>/etc/profile
[root@localhost ~]# source !$
source /etc/profile
[root@localhost ~]# bash
[root@localhost ~]# echo $myname
test
[root@localhost ~]# exit
exit
[root@localhost ~]# su - test
[test@localhost ~]$ echo $myname
test
```

&emsp;（2）只想让当前用户使用该变量

&emsp;&emsp;**需要在用户主目录下的.bashrc文件最后一行加入 export myname=test 然后运行 source .bashrc 就可以生效了。这时候再登录test账户，myname变量就不会生效了。上面用的source命令的作用是，将目前设定的配置刷新，即不用注销登录也能生效。**

&emsp;&emsp;linux设置自定义变量的规则：

&emsp;&emsp;&emsp;1.设定变量的格式为“a=b”，其中 a 为变量名，b 为变量的内容，等号两边不能有空格；

&emsp;&emsp;&emsp;2.变量名只能由英、数字以及下划线组成，而且不能以数字开头；

&emsp;&emsp;&emsp;3.当变量内容带有特殊字符（如空格）时，需要加上单引号。当变量内容本身带有单引号时，这就需要用双引号了。

```
[test@localhost ~]$ myname='test j'
[test@localhost ~]$ echo $myname
test j
[test@localhost ~]$ myname="test'j"
[test@localhost ~]$ echo $myname
test'j
```

&emsp;&emsp;&emsp;4.可以使用反引号调用其他命令结果赋给变量内容

```
[test@localhost ~]$ myname=`pwd`
[test@localhost ~]$ echo $myname
/home/test
```

&emsp;&emsp;&emsp;5.变量内容可以累加其他变量的内容，需要加双引号

```
[root@localhost ~]# myname="$LOGNAME"test
[root@localhost ~]# echo $myname
roottest
```

&emsp;&emsp;&emsp;对比一下加单引号的效果

```
[root@localhost ~]# myname='$LOGNAME'test
[root@localhost ~]# echo $myname
$LOGNAMEtest
```

&emsp;&emsp;&emsp;对比可知，用双引号时不会取消掉里面出现的特殊字符的作用（$）,而使用单引号则里面的特殊字符全部失去它本身的作用。

**     **

&emsp;&emsp;上述例子中多次使用bash命令，如果在当前shell中运行bash指令后，则会进入一个新的shell，这个shell就是原来shell的子shell了，可以用 pstree 命令查看一下。

```
[root@localhost ~]# pstree |grep bash
     |-login---bash
     |-sshd---sshd---bash-+-grep
```

&emsp;&emsp;**pstree** 会把linux系统下所有进程通过树形结构打印出来。

&emsp;&emsp;在父shell中设定一个变量后，进入子shell后该变量是不会生效的，如果想让这个变量在子shell中生效则要用到export命令。

```
[root@localhost ~]# abc=123
[root@localhost ~]# echo $abc
123
[root@localhost ~]# bash
[root@localhost ~]# echo $abc

[root@localhost ~]# exit
exit
[root@localhost ~]# export abc
[root@localhost ~]# echo $abc
123
[root@localhost ~]# bash
[root@localhost ~]# echo $abc
123
```

&emsp;&emsp;**export** 其实就是声明一下这个变量的意思，让该shell的子shell也知道该变量的值是多少。如果export后面不跟任何变量名，则会声明所有的变量。

**         **

&emsp;&emsp;**取消变量 `unset 变量名`**
