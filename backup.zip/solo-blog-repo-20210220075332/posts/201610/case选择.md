title: case 选择
date: '2016-10-10 07:24:53'
updated: '2016-10-10 07:24:53'
tags: [shell, case]
permalink: /articles/2016/10/10/1476055493856.html
---
# case 选择
&emsp;&emsp;在shell脚本中，除了用 if 来判断逻辑之外，还有一种常用的方式，那就是case了。具体格式为：


&emsp;case    变量   in

&emsp;value 1)
&emsp;&emsp;&emsp;command
&emsp;&emsp;&emsp;;;
&emsp;value 2)
&emsp;&emsp;&emsp;command
&emsp;&emsp;&emsp;;;
&emsp;value 3)
&emsp;&emsp;&emsp;command
&emsp;&emsp;&emsp;;;
&emsp;*)
&emsp;&emsp;&emsp;command
&emsp;&emsp;&emsp;;;
&emsp;esac
&emsp;
&emsp;
&emsp;&emsp;上面的结构中，不限制value的个数， * 则代表除了上面的value以外的其他值。下面写一个判断输入数值是奇数或偶数的脚本：

```
[root@133 ~]# vim case.sh
#!/bin/bash

read -p "Input a number:" n

a=$[$n%2]

case $a in
     1)
      echo "The number is odd."
      ;;
     0)
      echo "The number is even."
      ;;
     *)
      echo "It's not a number!"
      ;;
esac
```


&emsp;&emsp;$a 的值或为 1 或为 0，执行结果为：

```
[root@133 ~]# sh case.sh
Input a number:100
The number is even.

[root@133 ~]# sh case.sh
Input a number:101
The number is odd.
```


&emsp;&emsp;case脚本常用于编写系统服务的启动脚本。例如，/etc/init.d/iptables 中就用到了。另外，在给出的判断选项，即本例中的 1)和0)部分支持写成或结构，即1|0)结构，当然在本例中逻辑上就不通了，但格式上能这么写。
