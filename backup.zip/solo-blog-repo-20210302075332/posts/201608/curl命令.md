title: curl 命令
date: '2016-08-21 18:25:14'
updated: '2016-08-21 18:25:14'
tags: [curl, cli]
permalink: /articles/2016/08/21/1471775114345.html
---
# curl 命令
&emsp;&emsp;curl 是linux系统命令行下用来简单测试web访问的工具，几个常用的选项：

        

&emsp;&emsp;-x  使用代理，可以指定ip和端口，省略写hosts，方便实用

```
[root@localhost ~]# curl -x 192.168.1.1:80 www.qq.com
```



&emsp;&emsp;-I 可以把访问的内容略掉，只显示状态码，-v可以显示详细过程

```
[root@localhost ~]# curl -I www.qq.com

HTTP/1.1 200 OK

Server: squid/3.4.3

Date: Fri, 17 Jun 2016 11:57:53 GMT

Content-Type: text/html; charset=GB2312

Connection: keep-alive

Vary: Accept-Encoding

Vary: Accept-Encoding

Expires: Fri, 17 Jun 2016 11:58:53 GMT

Cache-Control: max-age=60

Vary: Accept-Encoding

Access-Control-Allow-Origin: http://bz.qq.com

X-Cache: HIT from shenzhen.qq.com



[root@localhost ~]# curl -Iv www.qq.com

* About to connect() to www.qq.com port 80 (#0)

*   Trying 182.254.34.74... connected

* Connected to www.qq.com (182.254.34.74) port 80 (#0)

> HEAD / HTTP/1.1

> User-Agent: curl/7.19.7 (x86_64-redhat-linux-gnu) libcurl/7.19.7 NSS/3.19.1 Basic ECC zlib/1.2.3 libidn/1.18 libssh2/1.4.2

> Host: www.qq.com

> Accept: */*

>

< HTTP/1.1 200 OK

HTTP/1.1 200 OK

< Server: squid/3.4.3

Server: squid/3.4.3

< Date: Fri, 17 Jun 2016 11:58:07 GMT

Date: Fri, 17 Jun 2016 11:58:07 GMT

< Content-Type: text/html; charset=GB2312

Content-Type: text/html; charset=GB2312

< Connection: keep-alive

Connection: keep-alive

< Vary: Accept-Encoding

Vary: Accept-Encoding

< Vary: Accept-Encoding

Vary: Accept-Encoding

< Expires: Fri, 17 Jun 2016 11:59:07 GMT

Expires: Fri, 17 Jun 2016 11:59:07 GMT

< Cache-Control: max-age=60

Cache-Control: max-age=60

< Vary: Accept-Encoding

Vary: Accept-Encoding

< Access-Control-Allow-Origin: http://bz.qq.com

Access-Control-Allow-Origin: http://bz.qq.com

< X-Cache: HIT from shenzhen.qq.com

X-Cache: HIT from shenzhen.qq.com



<

* Connection #0 to host www.qq.com left intact

* Closing connection #0
```

&emsp;&emsp;-u 可以指定用户名和密码

```
[root@localhost ~]# curl -u user:password http://test.com
```

&emsp;&emsp;-O 直接下载界面或者对象，-o 可以自定义名字

```
[root@localhost 123]# curl -O https://www.baidu.com/img/bd_logo1.png

  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current

                                 Dload  Upload   Total   Spent    Left  Speed

100  7877  100  7877    0     0  18577      0 --:--:-- --:--:-- --:--:--  183k

[root@localhost 123]# ls

bd_logo1.png

[root@localhost 123]# curl -o baidu.png https://www.baidu.com/img/bd_logo1.png

  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current

                                 Dload  Upload   Total   Spent    Left  Speed

100  7877  100  7877    0     0  31561      0 --:--:-- --:--:-- --:--:--  256k

[root@localhost 123]# ls

baidu.png  bd_logo1.png
```
