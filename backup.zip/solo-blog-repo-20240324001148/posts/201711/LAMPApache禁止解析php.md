title: LAMP--Apache 禁止解析 php
date: '2017-11-27 08:58:21'
updated: '2017-11-27 08:58:21'
tags: [待分类]
permalink: /articles/2017/11/27/1511744301673.html
---
# LAMP--Apache 禁止解析 php
某个目录下禁止解析php，这个很有用，比如某些目录可以上传文件，为了避免上传的文件有木马，所有我们禁用这个目录下面的访问解析 php。

    

       <Directory /data/www/data>

           php_admin_flag engine off

           <filesmatch "(.*)php">

               Order deny,allow

               Deny from all

           </filesmatch>

         </Directory>

说明： php_admin_flag engine off 这个语句就是禁止解析 php 的控制语句，但只这样配置还不够，因为这样配置后用户依然可以访问 php 文件，只不过不解析了，但可以下载，用户下载 php 文件也是不合适的，所以有必要再禁止一下。
