title: LAMP--2.Apache 编译安装
date: '2017-10-03 08:45:16'
updated: '2017-10-03 08:45:16'
tags: [lamp, httpd]
permalink: /articles/2017/10/03/1506991516673.html
---
# LAMP--2.Apache 编译安装
apache 官网下载地址：http://www.apache.org/dyn/closer.cgi 。建议使用国内开源镜像地址：[http://mirrors.aliyun.com/apache/httpd/httpd-2.2.31.tar.bz2](http://mirrors.aliyun.com/apache/httpd/httpd-2.2.31.tar.bz2)  或 [http://mirrors.sohu.com/apache/httpd-2.2.31.tar.bz2](http://mirrors.sohu.com/apache/httpd-2.2.31.tar.bz2) 。所谓的apache，真正的名字是 httpd。

     

下载

```e-bash
[root@localhost ~]# cd /usr/local/src
[root@localhost src]# wget http://mirrors.sohu.com/apache/httpd-2.2.31.tar.bz2
```



解压

```e-bash
[root@localhost src]# tar jxvf httpd-2.2.31.tar.bz2
```



配置编译参数

```e-bash
[root@localhost src]# cd httpd-2.2.31
[root@localhost httpd-2.2.31]#  ./configure \
 --prefix=/usr/local/apache2 \
 --with-included-apr \
 --enable-so \
 --enable-deflate=shared \
 --enable-expires=shared \
 --enable-rewrite=shared \
 --with-pcre
```



--prefix 指定安装到哪里， --enable-so表示启用DSO，--enable-deflate=shared表示动态共享的方式编译deflate模块，后面的参数同理。既然有动态那当然也有静态了，这两者有什么区别呢？apache 编译安装完成后会生成一个核心的二进制可执行文件叫做 httpd，这个文件作为核心文件，提供服务时就是它在处理用户的请求，但是有些功能，比如这里提到的expires就是配置静态文件（图片）过期时间的，也就是说图片可以在用户浏览器的临时缓存目录中缓存多久。这些功能是作为 httpd 的一个扩展模块来工作的，那么这种扩展模块有两种存在的方式，一种是直接在编译的时候和 httpd 文件结合在一起，组成一个体积大的文件，这种方式就叫做静态。而另外一种方式是，扩展模块作为一个独立的文件存在，只有在使用这个模块时再去调用它，这种方式就是动态共享。其中，动态的好处是，核心文件 httpd 比较小，模块随时用随时加载，耗费内存相对较少。而静态的优势是，在服务启动时，会把所有模块加载，到用时很快就执行，效率较高。

./configure 这一步经常会出现错误：

```e-bash
 error: mod_deflate has been requested but can not be built due to prerequisite failures
[root@localhost httpd-2.2.31]# yum install -y zlib-devel
```



为了避免在 make 的时候出现错误，最好是提前先安装好一些库文件：

```e-bash
#yum install -y pcre pcre-devel apr apr-devel
```



编译和安装

#make

#make install

```e-bash
[root@localhost httpd-2.2.31]# make
make[4]: Leaving directory `/usr/local/src/httpd-2.2.31/modules/mappers'
make[3]: Leaving directory `/usr/local/src/httpd-2.2.31/modules/mappers'
make[2]: Leaving directory `/usr/local/src/httpd-2.2.31/modules'
make[2]: Entering directory `/usr/local/src/httpd-2.2.31/support'
make[2]: Leaving directory `/usr/local/src/httpd-2.2.31/support'
make[1]: Leaving directory `/usr/local/src/httpd-2.2.31'
[root@localhost httpd-2.2.31]# echo $?
0
[root@localhost httpd-2.2.31]# make install
make[2]: Entering directory `/usr/local/src/httpd-2.2.31/support'
make[2]: Leaving directory `/usr/local/src/httpd-2.2.31/support'
Installing configuration files
[PRESERVING EXISTING HTDOCS SUBDIR: /usr/local/apache2/htdocs]
[PRESERVING EXISTING ERROR SUBDIR: /usr/local/apache2/error]
[PRESERVING EXISTING ICONS SUBDIR: /usr/local/apache2/icons]
[PRESERVING EXISTING CGI SUBDIR: /usr/local/apache2/cgi-bin]
Installing header files
Installing build system files
Installing man pages and online manual
make[1]: Leaving directory `/usr/local/src/httpd-2.2.31'
[root@localhost httpd-2.2.31]# echo $?
0
```





---

apache 启动脚本加入系统服务列表

```e-bash
[root@localhost php-5.6.10]# cp /usr/local/apache2/bin/apachectl /etc/init.d/httpd
[root@localhost php-5.6.10]# vim /etc/init.d/httpd
```



在第一行#!/bin/sh 下面添加两行文字

```e-bash
#chkconfig: 35 70 30
#description: Apache
```



保存退出

```e-bash
[root@localhost php-5.6.10]# chkconfig --add httpd
[root@localhost php-5.6.10]# chkconfig --level 35 httpd on
```
