title: LNMP--2.Nginx 编译安装
date: '2018-01-04 08:54:23'
updated: '2018-01-04 08:54:23'
tags: [lnmp, nginx, 编译安装]
permalink: /articles/2018/01/04/1515027263733.html
---
# LNMP--2.Nginx 编译安装
&emsp;Nginx 官网：http://nginx.org ，镜像下载地址： [http://mirrors.sohu.com/nginx/nginx-1.8.0.tar.gz](http://mirrors.sohu.com/nginx/nginx-1.8.0.tar.gz)



&emsp;（1）下载、解压 Nginx

```
[root@localhost ~]# cd /usr/local/src/

[root@localhost src]# wget http://mirrors.sohu.com/nginx/nginx-1.8.0.tar.gz

[root@localhost src]# tar zxf nginx-1.8.0.tar.gz
```


&emsp;（2）配置编译选项

```
[root@localhost src]# cd nginx-1.8.0

[root@localhost nginx-1.8.0]# ./configure \

--prefix=/usr/local/nginx \

--with-http_realip_module \

--with-http_sub_module \

--with-http_gzip_static_module \

--with-http_stub_status_module  \

--with-pcre

```

&emsp;&emsp;错误：

```
./configure: error: the HTTP rewrite module requires the PCRE library.

# yum install -y pcre-devel
```


&emsp;（3）编译、安装 Nginx

```
[root@localhost nginx-1.8.0]# make

[root@localhost nginx-1.8.0]# make install

[root@localhost nginx-1.8.0]# echo $?

0
```


&emsp;（4）启动 nginx：

```
[root@localhost nginx-1.8.0]# /usr/local/nginx/sbin/nginx

[root@localhost nginx-1.8.0]# ps aux|grep nginx

root     30621  0.0  0.0  23856   796 ?        Ss   00:50   0:00 nginx: master process /usr/local/nginx/sbin/nginx

nobody   30622  0.1  0.1  24284  1384 ?        S    00:50   0:00 nginx: worker process

root     30624  0.0  0.0 103324   868 pts/1    S+   00:50   0:00 grep nginx
```
