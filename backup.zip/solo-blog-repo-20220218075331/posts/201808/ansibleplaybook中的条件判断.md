title: ansible playbook 中的条件判断
date: '2018-08-07 19:43:14'
updated: '2018-08-07 19:43:14'
tags: [ansible, playbook, 自动化运维]
permalink: /articles/2018/08/07/1533642194832.html
---
# ansible playbook 中的条件判断
&emsp;&emsp;例：

```
[root@server ansible]# vim when.yml

---

- hosts: testhosts

  remote_user: root

  gather_facts: True         //setup中的这个参数会获取到主机的ip

  tasks:

   - name: use when

     shell: touch /tmp/when.txt

     when: facter_ipaddress == "192.168.56.128"   //当gather_facts参数的值满足这个条件时，执行shell命令


        执行：

[root@server ansible]# ansible-playbook when.yml



PLAY [testhosts] ***************************************************************



TASK [setup] *******************************************************************

ok: [client.test.com]

ok: [127.0.0.1]



TASK [use when] ****************************************************************

skipping: [127.0.0.1]

changed: [client.test.com]

 [WARNING]: Consider using file module with state=touch rather than running

touch



PLAY RECAP *********************************************************************

127.0.0.1                  : ok=1    changed=0    unreachable=0    failed=0

client.test.com            : ok=2    changed=1    unreachable=0    failed=0




[root@client ~]# ls -lt /tmp/when.txt

-rw-r--r-- 1 root root 0 7月  11 01:41 /tmp/when.txt
```


&emsp;&emsp;通常情况下，条件判断会用在针对不同发行版使用不同的命令的时候
