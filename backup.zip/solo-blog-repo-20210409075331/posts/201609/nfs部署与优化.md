title: nfs 部署与优化
date: '2016-09-11 18:25:14'
updated: '2016-09-11 18:25:14'
tags: [nfs]
permalink: /articles/2016/09/11/1473589514856.html
---
# nfs 部署与优化
## 服务端配置 NFS

&emsp;&emsp;CentOS上使用NFS服务，需要安装两个包（nfs-utils和rpcbind），不过当使用yum安装nfs-utils时会把rpcbind一起装上。

```
[root@localhost ~]# yum install -y nfs-utils
```


&emsp;&emsp;编辑配置文件 /etc/exports，创建简单的NFS服务器。

&emsp;&emsp;编辑配置文件，默认该文件为空

```
[root@localhost ~]# vim /etc/exports

/home/ 192.168.56.0/24(rw,sync,all_squash,anonuid=501,anongid=501)
```


&emsp;&emsp;这个配置文件就这一行，共分为三个部分，第一部分是本地要共享的目录，第二部分是允许访问的主机（ip或ip段），第三部分是小括号里面的一些权限选项：

&emsp;&emsp;&emsp;rw：读写；

&emsp;&emsp;&emsp;ro：只读；

&emsp;&emsp;&emsp;sync：同步模式，内存中数据时时写入磁盘；

&emsp;&emsp;&emsp;async：不同步，把内存中数据定期写入磁盘中；

&emsp;&emsp;&emsp;no_root_squash：加上这个选项后，root用户就会对共享的目录拥有至高的权限控制，就像是对本机的目录操作一样。不安全，不建议使用。

&emsp;&emsp;&emsp;root_squash：和上面的选项对应，root用户对共享目录的权限不高，只有普通用户的权限，即限制了root；

&emsp;&emsp;&emsp;all_squash：不管使用NFS的用户是谁，他的身份都会被限定为一个指定的普通用户身份；

&emsp;&emsp;&emsp;anonuid/anongid：要和root_squash以及all_squash一同使用，用于指定使用NFS的用户限定后的uid和gid，前提是本机的/etc/passwd 中存在这个uid和gid。



&emsp;&emsp;那么，刚刚配置文件 /etc/exports 中的意思就是，共享的目录为/home/，信任的主机为192.168.56.0/24这个网段，权限为读写，同步，限定所有使用者，并且限定的uid和gid都为501。



&emsp;&emsp;**启动NFS服务：**

```
[root@localhost ~]# /etc/init.d/rpcbind start;/etc/init.d/nfs start

正在启动 rpcbind：                                         [确定]

启动 NFS 服务：                                            [确定]

启动 NFS mountd：                                          [确定]

启动 NFS 守护进程：                                        [确定]

正在启动 RPC idmapd：                                      [确定]
```


&emsp;&emsp;在启动nfs之前，需要先启动rpcbind服务，之前centos老版本中并不是rpcbind，而是portmap。





## 客户端挂载 NFS

&emsp;&emsp;在客户端挂载NFS之前，需要看一下服务端都共享了哪些目录，这需要使用 showmount 命令，但是这个命令是nfs-utils包所带的，所以需要安装一下。

```
[root@localhost ~]# yum install -y nfs-utils
```


&emsp;&emsp;查看服务端共享的目录：

```
[root@localhost ~]# showmount -e 192.168.56.133

Export list for 192.168.56.133:

/home 192.168.56.0/24
```


&emsp;&emsp;可以看到刚刚在服务端配置的共享信息，showmount -e 加IP就可以查看NFS的共享情况。

&emsp;&emsp;**在客户端上挂载NFS：**

```
[root@localhost ~]# mount -t nfs -o nfsvers=3 192.168.56.133:/home/ /mnt/

[root@localhost ~]# df -h

Filesystem            Size  Used Avail Use% Mounted on

/dev/sda3              18G  1.1G   16G   7% /

tmpfs                 495M     0  495M   0% /dev/shm

/dev/sda1             190M   27M  154M  15% /boot

192.168.56.133:/home/

                       28G  1.4G   25G   6% /mnt
```


&emsp;&emsp;说明：-o 后面跟挂载选项，如果不加 -o nfsvers=3 则在挂载目录下的文件属主和组都是nobody，如果指定 nfsvers=3 则显示 501，所以尽量加上这个选项，避免权限混乱。



&emsp;&emsp;**命令 exportfs**

&emsp;&emsp;常用选项：[-aruv]

&emsp;&emsp;&emsp;-a：全部挂载或者卸载

&emsp;&emsp;&emsp;-r：重新挂载

&emsp;&emsp;&emsp;-u：卸载某一个目录

&emsp;&emsp;&emsp;-v：显示共享的目录

&emsp;&emsp;使用exportfs命令，当改变 /etc/exports 配置文件后，不用重启 nfs 服务直接用这个 exportfs 即可，服务端操作：

```
[root@localhost ~]# vim /etc/exports

/home/ 192.168.56.0/24(rw,sync,all_squash,anonuid=501,anongid=501)

/tmp/ 192.168.56.0/24(rw,sync,all_squash)     //增加一行
```

&emsp;&emsp;然后在服务端执行：

```
[root@localhost ~]# exportfs -arv

exporting 192.168.56.0/24:/tmp

exporting 192.168.56.0/24:/home
```


&emsp;&emsp;下面继续在客户端上挂载：

&emsp;&emsp;在之前的命令中就用到了 mount 来挂载nfs，其中 -t nfs 是用来指定挂载的类型为nfs。除 -o nfsvers=3之外还有一个常用的选项就是 -o nolock，即在挂载nfs服务时，不加锁。客户端执行：

```
[root@localhost ~]# mkdir /test

[root@localhost ~]# mount -t nfs -o nolock 192.168.56.133:/tmp/ /test/

[root@localhost ~]# df -h

Filesystem            Size  Used Avail Use% Mounted on

/dev/sda3              18G  1.1G   16G   7% /

tmpfs                 495M     0  495M   0% /dev/shm

/dev/sda1             190M   27M  154M  15% /boot

192.168.56.133:/home/

                       28G  1.4G   25G   6% /mnt

192.168.56.133:/tmp/   28G  1.4G   25G   6% /test
```

&emsp;&emsp;当然，还可以把要挂载的nfs目录放到 client 上的 /etc/fstab 文件中，挂载时只需要执行 mount -a 即可。在 /etc/fstab 里加一行：  192.168.56.133:/tmp/      /test     nfs    nolock   0  0

&emsp;&emsp;先卸载刚刚挂载的test

```
[root@localhost ~]# umount /test/

[root@localhost ~]# vim /etc/fstab

UUID=f77b4c47-ca03-43f9-b420-cc0be633446a /                       ext4    defaults        1 1

UUID=82d89195-8a63-4d3f-944f-03b308893c3f /boot                   ext4    defaults        1 2

UUID=38631717-1603-4987-a781-9e378950bc48 swap                    swap    defaults        0 0

tmpfs                   /dev/shm                tmpfs   defaults        0 0

devpts                  /dev/pts                devpts  gid=5,mode=620  0 0

sysfs                   /sys                    sysfs   defaults        0 0

proc                    /proc                   proc    defaults        0 0

192.168.56.133:/tmp/    /test                   nfs     nolock          0 0
```

&emsp;&emsp;然后执行：

```
[root@localhost ~]# mount -a

[root@localhost ~]# df -h

Filesystem            Size  Used Avail Use% Mounted on

/dev/sda3              18G  1.1G   16G   7% /

tmpfs                 495M     0  495M   0% /dev/shm

/dev/sda1             190M   27M  154M  15% /boot

192.168.56.133:/home/

                       28G  1.4G   25G   6% /mnt

192.168.56.133:/tmp/   28G  1.4G   25G   6% /test
```


&emsp;&emsp;这样也可以挂载上，而且以后开机会自动挂载上。
