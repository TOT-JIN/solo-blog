title: rpm 安装和卸载 rpm 查询
date: '2017-02-26 12:49:14'
updated: '2017-02-26 12:49:14'
tags: [rpm, Linux]
permalink: /articles/2017/02/26/1488084554856.html
---
# rpm 安装和卸载 rpm 查询
**RPM是”Redhat Package Manager“的缩写。RPM 是一种数据库记录的方式来将我们需要的套件安装的linux主机的一套管理程序。也就是说，linux系统中存在着一个关于RPM的数据库，它记录了安装的包以及包与包之间的依赖相关性。RPM包是预先在linux机器上编译好并打包好的文件，安装起来非常快捷，但是缺点是安装的环境必须与编译时的环境一致或相当，包与包之间存在着依赖关系，卸载时需要先把以来的包卸载掉。如果依赖的包是系统所必须的，那就不能卸载这个包，否则会造成系统崩溃。**

**我们可以查看一下系统安装光盘中的RPM包，把光驱挂载到/mnt目录下：**

```e-bash
[root@localhost ~]# mount /dev/cdrom /mnt/
mount: block device /dev/sr0 is write-protected, mounting read-only
[root@localhost ~]# ls /mnt/
CentOS_BuildTag  isolinux                  RPM-GPG-KEY-CentOS-Debug-6
EFI              Packages                  RPM-GPG-KEY-CentOS-Security-6
EULA             RELEASE-NOTES-en-US.html  RPM-GPG-KEY-CentOS-Testing-6
GPL              repodata                  TRANS.TBL
p_w_picpaths           RPM-GPG-KEY-CentOS-6
[root@localhost ~]# ls /mnt/Packages/|head
389-ds-base-1.2.11.15-60.el6.x86_64.rpm
389-ds-base-libs-1.2.11.15-60.el6.x86_64.rpm
abrt-2.0.8-34.el6.centos.x86_64.rpm
abrt-addon-ccpp-2.0.8-34.el6.centos.x86_64.rpm
abrt-addon-kerneloops-2.0.8-34.el6.centos.x86_64.rpm
abrt-addon-python-2.0.8-34.el6.centos.x86_64.rpm
abrt-cli-2.0.8-34.el6.centos.x86_64.rpm
abrt-desktop-2.0.8-34.el6.centos.x86_64.rpm
abrt-gui-2.0.8-34.el6.centos.x86_64.rpm
abrt-libs-2.0.8-34.el6.centos.x86_64.rpm
```





---

RPM安装和卸载

         

**安装一个rpm包**

```e-bash
[root@localhost ~]# rpm -ivh /mnt/Packages/libjpeg-turbo-devel-1.2.1-3.el6_5.x86_64.rpm                                   Preparing...                ########################################### [100%]
   1:libjpeg-turbo-devel    ########################################### [100%]
```



**命令 rpm -ivh filename**

**-i：安装的意思**

**-v:可视化**

**-h：显示安装进度**

**安装rpm包时常用的附带参数：**

**--force：强制安装，即使覆盖属于其他包的文件也要安装。**

**--nodeps：当要安装的rpm包依赖其他包时，即使其他包没有安装，也要安装这个包。**



**升级一个rpm包**

**命令 rpm -Uvh filename**

**-U：即升级的意思**

 

**卸载一个rpm 包**

**命令 rpm -e filename**

**卸载时的filename和安装时是有区别的，安装时是把一个存在的文件作为参数，而卸载时只需要包名就可以了。**

---

RPM查询

**查询一个rpm包是否安装**

**命令 rpm -q rpm包名（这里的包名是不带有平台信息和后缀名的）**

```e-bash
[root@localhost ~]# rpm -q libjpeg-turbo-devel
package libjpeg-turbo-devel is not installed
[root@localhost ~]# rpm -ivh /mnt/Packages/libjpeg-turbo-devel-1.2.1-3.el6_5.x86_64.rpm
Preparing...                ########################################### [100%]
   1:libjpeg-turbo-devel    ########################################### [100%]
[root@localhost ~]# rpm -q libjpeg-turbo-devel
libjpeg-turbo-devel-1.2.1-3.el6_5.x86_64
```



**可以使用 rpm -qa 查询当前系统所有安装过的 rpm 包**

```e-bash
[root@localhost ~]# rpm -qa |head
im-chooser-1.3.1-3.el6.x86_64
setup-2.8.14-20.el6_4.1.noarch
ibus-1.3.4-8.el6.x86_64
xml-common-0.6.3-33.el6.noarch
fontpackages-filesystem-1.41-1.1.el6.noarch
iso-codes-3.16-2.el6.noarch
kbd-misc-1.15-11.el6.noarch
dmz-cursor-themes-0.4-4.el6.noarch
policycoreutils-2.0.83-24.el6.x86_64
ncurses-base-5.7-4.20090207.el6.x86_64
```




**得到一个已安装 rpm 包的相关信息**

**命令 rpm -qi 包名（同样不需要加平台信息与后缀名）**

```e-bash
[root@localhost ~]# rpm -qi libjpeg-turbo-devel
Name        : libjpeg-turbo-devel          Relocations: (not relocatable)
Version     : 1.2.1                             Vendor: CentOS
Release     : 3.el6_5                       Build Date: 2013年12月10日 星期二 07时37分03秒
Install Date: 2016年05月15日 星期日 00时08分36秒      Build Host: c6b10.bsys.dev.centos.org
Group       : Development/Libraries         Source RPM: libjpeg-turbo-1.2.1-3.el6_5.src.rpm
Size        : 321085                           License: wxWidgets
Signature   : RSA/SHA1, 2013年12月10日 星期二 09时01分18秒, Key ID 0946fca2c105b9de
Packager    : CentOS BuildSystem <http://bugs.centos.org>
URL         : http://sourceforge.net/projects/libjpeg-turbo
Summary     : Headers for the libjpeg-turbo library
Description :
This package contains header files necessary for developing programs which
will manipulate JPEG files using the libjpeg-turbo library.
```



        

**列出一个rpm包安装的文件**

**命令 rpm -ql 包名**

```e-bash
[root@localhost ~]# rpm -ql libjpeg-turbo-devel
/usr/include/jconfig.h
/usr/include/jerror.h
/usr/include/jmorecfg.h
/usr/include/jpeglib.h
/usr/lib64/libjpeg.so
/usr/share/doc/libjpeg-turbo-devel-1.2.1
/usr/share/doc/libjpeg-turbo-devel-1.2.1/coderules.txt
/usr/share/doc/libjpeg-turbo-devel-1.2.1/example.c
/usr/share/doc/libjpeg-turbo-devel-1.2.1/jconfig.txt
/usr/share/doc/libjpeg-turbo-devel-1.2.1/libjpeg.txt
/usr/share/doc/libjpeg-turbo-devel-1.2.1/structure.txt
```



**通过上面的命令可以看出安装”libjpeg-turbo-devel“这个rpm包得到这些文件。也可以通过已知文件查找rpm包。**

**列出某一个文件属于哪个rpm包**

**命令 rpm -qf  文件的绝对路径**

```e-bash
[root@localhost ~]# rpm -qf /usr/lib64/libjpeg.so
libjpeg-turbo-devel-1.2.1-3.el6_5.x86_64
```
