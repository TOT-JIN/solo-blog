title: LNMP--nginx 禁止指定 user_agent
date: '2018-02-15 17:34:43'
updated: '2018-02-15 17:34:43'
tags: [lnmp, nginx, user_agent]
permalink: /articles/2018/02/15/1518687283733.html
---
# LNMP--nginx 禁止指定 user_agent
&emsp;&emsp;和apache的相关配置相像，具体如下：



```
location /

{

      if ($http_user_agent ~ 'bingbot/2.0|MJ12bot/v1.4.2|Spider/3.0|YoudaoBot|Tomato|Gecko/20100315'){

            return  403;

      }

}
```
