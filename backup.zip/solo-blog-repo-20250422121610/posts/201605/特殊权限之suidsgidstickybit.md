title: 特殊权限之 suid sgid sticky_bit
date: '2016-05-29 19:11:29'
updated: '2016-05-29 19:11:29'
tags: [suid, sgid, sticky_bit, Linux]
permalink: /articles/2016/05/27/1464520289592.html
---
# 特殊权限之 suid sgid sticky_bit

在之前介绍权限时，一直都是3位数，其实最前面还有一位。 这就是 set uid , set gid , sticky bit 。该权限针对二进制可执行文件，使文件在执行阶段具有文件所有者的权限。比如passwd这个命令就具有该权限。当普通用户执行passwd命令时，可以临时获得root权限，从而可以更改密码。

```
[root@localhost~]# ls -l /usr/bin/passwd
-rwsr-xr-x. 1 root root 25980 2 月 22 2012 /usr/bin/passwd
```

passwd显示的是rws，并非传统的rwx ，用数字表示为4755。当有特殊权限时，第一位数字可以是0 , 1（--t）, 2（-s-）, 3（-st）, 4（s--）, 5（s-t）, 6（ss-）, 7（sst）。passwd文件是s--所以是4。下面自定义一个**set uid**的权限:

```
[root@localhost~]# su - user1
[user1@localhost~]$ ls -l /root/
```

ls : 无法打开目录/root/: 权限不够

```
[user1@localhost~]$ exit
Logout
[root@localhost~]# chmod u+s /bin/ls
[root@localhost~]# ls -l /bin/ls
-rwsr-xr-x. 1 root root 109208 11 月 22 2013 /bin/ls
[root@localhost~]# su - user1
[user1@localhost~]$ ls -l /root/
总用量 36
-rw-------. 1 root root 980 5 月 7 18:00 anaconda-ks.cfg
-rw-r--r--. 1 root root 19305 5 月 7 18:00 install.log
-rw-r--r--. 1 root root 5890 5 月 7 17:58 install.log.syslog
```

说明：su - user1 这个命令可以让root用户临时切换到user1用户下， 以user1的身份去执行命令。普通用户是没有权限查看/root/目录内容的，所以报错了。用exit退出user1，然后给/bin/ls命令加一个set uid权限，再次切换到user1下，再执行ls /root/就可以查看了。这里我们使用了 chmod u+s /bin/ls 来给ls加一个set uid权限。有时候你可能会看到-rwSr-xr-x 这样的权限，s变成了S，这是由于所有者没有了执行权限。

```
[root@localhost~]# chmod u-x /bin/ls
[root@localhost~]# ls -l /bin/ls
-rwSr-xr-x. 1 root root 109208 11 yue  22 2013  /bin/ls
```

---

特殊权限之 **sgid**

该权限可以应用在文件上同样也可以应用在目录上。设置在文件上，作用和set uid类似，前提是这个文件是可执行的二进制文件，当设置 set uid 后，执行该文件的用户会临时以该文件所属组的身份执行。若目录被设置这个权限后，任何用户在此目录下创建的文件或目录都具有和该目录所属的组相同的组。

```
[root@localhost~]# mkdir /tmp/test
[root@localhost~]# chmod 777 /tmp/test
[root@localhost~]# ls -ld /tmp/test
drwxrwxrwx 2 root root 4096 8 月 14 17:58 /tmp/test
[root@localhost~]# chmod g+s /tmp/test
[root@localhost~]# ls -ld /tmp/test
drwxrwsrwx 2 root root 4096 8 月 14 17:58 /tmp/test
[root@localhost~]# su - user1
[user1@localhost~]$ cd /tmp/test
[user1@localhost test]$ mkdri 123
[user1@localhost test]$ touch 1.txt
[user1@localhost test]$ ls -l
总用量 4
drwxrwsr-x 2 user1 root 4096 8 月 14 17:59 123
-rw-rw-r-- 1 user1 root 0 8 月 14 17:59 1.txt
```

说明：给/tmp/test目录设置set gid 权限后，权限由原来的drwxrwxrwx变为drwxrwsrwx，此时以user1的身份在/tmp/test目录里创建目录和文件，其所属组都为root，而不是user1 。

---

特殊权限之 **sticky_bit**

sticky_bit可以理解为防删除位。一个文件是否可以被某用户删除，主要取决于该文件所在目录是否对该用户具有写权限。如果没有写权限，则这个目录下的所有文件都不能被删除，同时也不能添加新的文件。如果希望用户能够添加文件但同时又不想它能够去删除其他用户的文件，则可以对父目录增加该权限。设置它后，就算用户对目录具有写权限，也不能删除其他用户的文件。比如/tmp/目录就设置过该权限。

```
[root@localhost~]# ls -ld /tmp/
drwxrwxrwt. 7 root root 16384 8 月 14 17:58 /tmp/
[root@localhost~]# useradd user2
[root@localhost~]# su - user1
[user1@localhost~]$ touch /tmp/user1.txt
[user1@localhost~]$ echo "121"> /tmp/user1.txt
[user1@localhost~]$ exit
logout
[root@localhost~]#su -user2
[user2@localhost~]$ rm -f /tmp/user1.txt
rm : 无法删除“/tmp/user1.txt”：不允许的操作
```

说明：一个文件能否被删除，取决于该文件父目录的权限， /tmp/目录是777，任何人都可写的，所以说理论上任何人都能删除/tmp/下的所有文件，但是刚才我们做的实验却表明，user2是不可以删除user1的文件的，这就是因为/tmp/目录有一个sticky_bit。

增加sticky_bit权限方法和之前类似

增加 set uid 权限： chmod u+s filename   /  去掉为： chmod u-s filename

增加 set gid 权限： chmod g+s filename

增加 sticky_bit权限： chmod o+t filename
