title: 增加和删除用户组、用户 usermod修改用户属性
date: '2016-06-07 11:31:46'
updated: '2016-06-07 11:31:46'
tags: [groupadd, groupdel, useradd, userdel]
permalink: /articles/2016/06/07/1465270306592.html
---
# 增加和删除用户组、用户 usermod修改用户属性

**增加和删除用户组**

**新增一个组：groupadd**

语法 groupadd [-g GID] groupname



```
[root@localhost ~]# groupadd grptest1

[root@localhost ~]# tail -n1 /etc/group

grptest1:x:500:
```



不加”-g“选项则按照系统默认的gid创建组，跟用户一样，gid也是从500开始的。



```
[root@localhost ~]# groupadd -g 511 grptest2

[root@localhost ~]# tail -n2 /etc/group

grptest1:x:500:

grptest2:x:511:
```



"-g"选项可以自定义gid

**删除组：groupdel**



```
[root@localhost ~]# groupdel grptest2

[root@localhost ~]# tail -n3 /etc/group

sshd:x:74:

slocate:x:21:

grptest1:x:500:
```



该命令没有特殊选项，但有一种情况不能删除组：



```
[root@localhost ~]# groupdel user1

groupdel:cannot remove the primary group of user 'user1'
```



这是因为user1组中包含user1账户，只有删除user1账户后才可以删除该组。

---

**增加和删除用户**

**增加用户：useradd**

语法 useradd [-u UID][-g GID][-d HOME][-M][-s]



-u : 自定义 UID

-g：使其属于已经存在的某个组，后面可以跟组id，也可以跟组名

-d：自定义用户的家目录

-M：不建立家目录

-s：自定义 shell



```
[root@localhost ~]# useradd test10

[root@localhost ~]# tail -n1 /etc/passwd

test10:x:500:501::/home/test10:/bin/bash

[root@localhost ~]# tail -n1 /etc/group

test10:x:501:
```



useradd 不加任何选项直接跟用户名，则会创建一个跟用户名同样名字的组。



```
[root@localhost ~]# useradd -u510 -g 513 -M -s /sbin/nologin user11

useradd: group '513' does not exist

[root@localhost ~]# useradd -u510 -g 500 -M -s /sbin/nologin user11

[root@localhost ~]# useradd -u511 -g grptest1 user12

[root@localhost ~]# tail -n2 /etc/passwd

user11:x:510:500::/home/user11:/sbin/nologin

user12:x:511:500::/home/user12:/bin/bash

[root@localhost ~]# tail -n2 /etc/group

grptest1:x:500:

test10:x:501:
```



-g 选项后面跟一个不存在的gid会报错，提示该组不存在。刚刚上面说过-M选项加上后则不建立用户家目录，但是在/etc/passwd 文件中仍然有这个字段。但是你使用 ls /home/user11 查看一下会提示该目录不存在。所以-M选项的作用只是不创建那个目录。



```
[root@localhost ~]# ls /home/user11

ls: 无法访问/home/user11: 没有那个文件或目录
```



**删除用户：userdel**

语法 userdel [-r] username



```
[root@localhost ~]# ls -ld /home/user12

drwx------ 3 user12 grptest1 4096 5月  14 00:48 /home/user12

[root@localhost ~]# userdel user12

[root@localhost ~]# ls -ld /home/user12

drwx------ 3 511 grptest1 4096 5月  14 00:48 /home/user12

[root@localhost ~]# ls -ld /home/test10

drwx------ 3 test10 test10 4096 5月  14 00:41 /home/test10

[root@localhost ~]# userdel -r test10

[root@localhost ~]# ls -ld /home/test10

ls: 无法访问/home/test10: 没有那个文件或目录
```



-r 选项的作用只有一个，就是删除账户的时候连带账户的家目录一起删除。

---

**usermod 修改用户属性**

usermod 命令和useradd命令的选项很像，唯一不同的是，usermod 是更改已经存在的用户相关属性。常用选项如下：

-u : 更改用户的 uid

-g：更改用户属组，后面可以跟组id，也可以跟组名

-d：更改用户的家目录

-s：更改用户的 shell

-L：锁定

-U：解锁
