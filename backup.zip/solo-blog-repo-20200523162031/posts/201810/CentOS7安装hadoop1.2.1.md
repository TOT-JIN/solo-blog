title: CentOS7 安装 hadoop-1.2.1
date: '2018-10-03 09:53:35'
updated: '2018-10-03 09:53:35'
tags: [Hadoop, hdfs, 大数据]
permalink: /articles/2018/10/03/1538531615733.html
---
分布式环境：

| master | slave1 | slave2 |
| --- | --- | --- |
| centos7 | centos7 | centos7 |
| 1c | 1c | 1c |
| 2G | 1G | 1G |
| 192.168.18.30 | 192.168.18.31 | 192.168.18.32 |

## 0.初始化三个节点

配置环境变量

* 更改主机名分别为 master、slave1、slave2
* 配置 ssh 秘钥验证，达到任一节点无需密码验证登录其他站点 root 用户的效果
* 配置/etc/hosts 文件，使任一节点通过 master、slave1、slave2 即可域名解析到对应节点 IP

关闭防火墙

```bash
[root@master ~]# vim /etc/selinux/config
...
SELINUX=disabled
...
[root@master ~]# setenforce 0
[root@master ~]# getenforce
Permissive
[root@master ~]# systemctl stop firewalld
[root@master ~]# systemctl disable firewalld
另外从节点也要执行
```

## 1.安装 java

下载 hadoop 和 jdk 安装包到/usr/local/src 目录下

> [https://archive.apache.org/dist/hadoop/core/hadoop-1.2.1/hadoop-1.2.1-bin.tar.gz](https://archive.apache.org/dist/hadoop/core/hadoop-1.2.1/hadoop-1.2.1-bin.tar.gz)
> [https://repo.huaweicloud.com/java/jdk/6u45-b06/jdk-6u45-linux-x64.bin](https://repo.huaweicloud.com/java/jdk/6u45-b06/jdk-6u45-linux-x64.bin)

```bash
[root@master src]# ls
hadoop-1.2.1-bin.tar.gz  jdk-6u45-linux-x64.bin
```

给予 `jdk-6u45-linux-x64.bin` 可执行权限，执行如下命令：

```bash
[root@master src]# ./jdk-6u45-linux-x64.bin
```

可得如下目录：

```bash
[root@master src]# ls -ld jdk1.6.0_45
drwxr-xr-x. 8 root root 176 3月  27 2013 jdk1.6.0_45
```

将该目录移动到 `/usr/local` 下（个人习惯）：

```bash
[root@master jdk1.6.0_45]# pwd
/usr/local/jdk1.6.0_45
```

此目录即为 java 的安装目录，现在需要将 java 的相关变量声明命令添加到对于脚本中。在此选择添加到 `/etc/bashrc` 文件中。

```bash
[root@master jdk1.6.0_45]# tail -n 5 /etc/bashrc

export JAVA_HOME=/usr/local/jdk1.6.0_45
export CLASSPATH=.:$CLASSPATH:$JAVA_HOME/lib
export PATH=$PATH:$JAVA_HOME/bin

```

```bash
[root@master jdk1.6.0_45]# source /etc/bashrc
[root@master jdk1.6.0_45]# which java
/usr/local/jdk1.6.0_45/bin/java
[root@master jdk1.6.0_45]# java -version
java version "1.6.0_45"
Java(TM) SE Runtime Environment (build 1.6.0_45-b06)
Java HotSpot(TM) 64-Bit Server VM (build 20.45-b01, mixed mode)
```

如法炮制，在 slave1 和 slave2 节点上安装 java

```bash
[root@slave1 ~]# which java
/usr/local/jdk1.6.0_45/bin/java
```

```bash
[root@slave2 ~]# which java
/usr/local/jdk1.6.0_45/bin/java
```

## 2.安装 hadoop

解压安装包

```bash
[root@master src]# ls
hadoop-1.2.1-bin.tar.gz  jdk-6u45-linux-x64.bin
[root@master src]# tar zxf hadoop-1.2.1-bin.tar.gz
[root@master src]# ls
hadoop-1.2.1  hadoop-1.2.1-bin.tar.gz  jdk-6u45-linux-x64.bin
```

移动新生成的目录到 `/usr/local/` 下

```bash
[root@master hadoop-1.2.1]# pwd
/usr/local/hadoop-1.2.1
```

生成存放运行过程中临时文件的 tmp 目录

```bash
[root@master hadoop-1.2.1]# mkdir tmp
```

进入 conf 目录下，修改配置文件：

```bash
[root@master conf]# pwd
/usr/local/hadoop-1.2.1/conf
```

修改 masters 文件，写入 master 节点的自定义域名

```bash
[root@master conf]# cat masters
master
```

修改 slaves 文件，写入 slave 节点的自定义域名

```bash
[root@master conf]# cat slaves
slave1
slave2
```

修改 core-site.xml 文件

```bash
[root@master conf]# vim core-site.xml
...
<configuration>
        <!--用来指定使用hadoop时产生文件的存放目录-->
        <property>
                <name>hadoop.tmp.dir</name>
                <value>/usr/local/hadoop-1.2.1/tmp</value>
        </property>
        <!--指定namenode的地址-->
        <property>
                <name>fs.default.name</name>
                <value>hdfs://master:9000</value>
        </property>
</configuration>
```

修改 mapred-site.xml 文件

```bash
[root@master conf]# vim mapred-site.xml
...
<configuration>
        <!--作业跟踪管理器的HTTP服务器访问端口和地址-->
        <property>
                <name>mapred.job.tracker</name>
                <value>http://master:9001</value>
        </property>
</configuration>
```

修改 hdfs-site.xml 文件

```bash
[root@master conf]# vim hdfs-site.xml
...
<configuration>
        <!--指定hdfs保存数据的副本数量-->
        <property>
                <name>dfs.replication</name>
                <value>3</value>
        </property>
</configuration>
```

修改 hadoop-env.sh 脚本

```bash
[root@master conf]# tail -n2 hadoop-env.sh

export JAVA_HOME=/usr/local/jdk1.6.0_45
```

将/usr/local/hadoop-1.2.1 目录拷贝到另外两个从节点：

```bash
[root@master hadoop-1.2.1]# rsync -azvP /usr/local/hadoop-1.2.1 root@slave1:/usr/local/
[root@master hadoop-1.2.1]# rsync -azvP /usr/local/hadoop-1.2.1 root@slave2:/usr/local/
```

## 3.启动集群

初始化

```bash
[root@master bin]# pwd
/usr/local/hadoop-1.2.1/bin
[root@master bin]# ./hadoop namenode -format
```

启动

```bash
[root@master bin]# ./start-all.sh
[root@master bin]# jps
13144 JobTracker
12906 NameNode
13254 Jps
13067 SecondaryNameNode
```

尝试执行

```bash
[root@master bin]# ./hadoop fs -ls /
Found 1 items
drwxr-xr-x   - root supergroup          0 2019-02-06 14:51 /usr
[root@master bin]# ./hadoop fs -put /etc/passwd /
[root@master bin]# ./hadoop fs -ls /
Found 2 items
-rw-r--r--   3 root supergroup        892 2019-02-06 14:53 /passwd
drwxr-xr-x   - root supergroup          0 2019-02-06 14:51 /usr
[root@master bin]# ./hadoop fs -cat /passwd
root:x:0:0:root:/root:/bin/bash
bin:x:1:1:bin:/bin:/sbin/nologin
daemon:x:2:2:daemon:/sbin:/sbin/nologin
adm:x:3:4:adm:/var/adm:/sbin/nologin
...
```
