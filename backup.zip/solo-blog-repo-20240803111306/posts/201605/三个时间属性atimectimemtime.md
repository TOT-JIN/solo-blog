title: 三个时间属性 atime ctime mtime
date: '2016-05-31 21:42:47'
updated: '2016-05-31 21:42:47'
tags: [atime, ctime, mtime, Linux]
permalink: /articles/2016/05/31/1464702167592.html
---
# 三个时间属性 atime ctime mtime

文件的Access time 就是 atime，是在读取文件或者执行文件时更改的。

文件的Modified time 就是 mtime，是在写入文件时随文件内容的更改而更改的。

文件的Create time 就是 ctime , 是在写入文件、更改所有者、权限或链接设置时随 inode 的内容更改而更改的。

inode : 译成中文就是索引节点，它用来存放档案及目录的基本信息，包含时间信息、文档名、属主以及属组等。Inode是Unix操作系统中的一种数据结构，本质是结构体，inode是随文件系统创建时生成的，它的个数有限。在linux下，可以通过 df -i 来查看各个分区的 inode 数量。

**stat命令可用来列出文件的 atime 、ctime 和mtime**

```
[root@localhost ~]# stat test/test2
File: "test/test2"
Size: 0               Blocks: 0          IO Block: 4096   普通空文件
Device: 803h/2051d      Inode: 789546      Links: 1
Access: (0644/-rw-r--r--)  Uid: (    0/    root)   Gid: (    0/    root)
Access: 2016-05-13 22:05:11.533002454 +0800
Modify: 2016-05-13 22:05:11.533002454 +0800
Change: 2016-05-13 22:05:11.533002454 +0800
```



**atime 不一定在访问文件之后被修改，因为：使用ext3文件系统的时候，如果在mount的时候使用了noatime参数那么就不会更新atime的信息。总之，这三个time属性值都被放在inode中。若mtime修改inode就一定会改，既然 inode 改了，那ctime也就跟着要改了，atime比较特殊，atime改变ctime不一定变。**
