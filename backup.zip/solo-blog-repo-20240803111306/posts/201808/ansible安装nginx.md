title: ansible 安装 nginx
date: '2018-08-08 18:23:44'
updated: '2018-08-08 18:23:44'
tags: [ansible, playbook, 自动化运维]
permalink: /articles/2018/08/08/1533723824832.html
---
# ansible 安装 nginx
&emsp;&emsp;思路：先在一台机器上编译安装好nginx、打包，然后再用ansible去下发。

```
[root@server ~]# cd /etc/ansible

[root@server ansible]# mkdir nginx_install

[root@server ansible]# cd !$

cd nginx_install

[root@server nginx_install]# mkdir -p roles/{common,install}/{handlers,files,meta,tasks,templates,vars}
```


&emsp;&emsp;说明：roles目录下有两个角色，common为一些准备操作，install为安装nginx的操作。每隔角色下面又有几个目录，handlers下面是当发生改变时要执行的操作，通常用在配置文件发生改变，重启服务时。files为安装时用到的一些文件，meta为说明信息，说明角色依赖等信息，tasks里面是核心的配置文件，templates通常存一些配置文件，启动脚本等模版文件，vars下为定义的变量。

&emsp;&emsp;现server端已有编译安装好的nginx，配置好启动脚本，配置好配置文件，以它来做实验，client端要安好库文件 yum install -y gcc pcre-devel zlib-devel

&emsp;&emsp;打包nginx，并放在roles/install/files/下面。

```
[root@server ~]# cd /usr/local

[root@server local]# ls

bin  etc  games  include  lib  lib64  libexec  nginx  sbin  share  src

[root@server local]# tar czvf nginx.tar.gz nginx

[root@server local]# ls

bin  games    lib    libexec  nginx.tar.gz  share

etc  include  lib64  nginx    sbin          src

[root@server local]# cp nginx.tar.gz /etc/ansible/nginx_install/roles/install/files/

[root@server local]# ls !$

ls /etc/ansible/nginx_install/roles/install/files/

nginx.tar.gz
```


&emsp;&emsp;启动脚本、配置文件要放到 roles/install/templates 下面

```
[root@server ~]# cp /etc/init.d/nginx /etc/ansible/nginx_install/roles/install/templates/ ;cp /usr/local/nginx/conf/nginx.conf /etc/ansible/nginx_install/roles/install/templates/

[root@server ~]# ls !$

ls /etc/ansible/nginx_install/roles/install/templates/

nginx  nginx.conf
```


      

&emsp;&emsp;定义common的tasks，nginx是需要一些依赖包的

```
[root@server ansible]# cd /etc/ansible/nginx_install/roles/

[root@server roles]# vim ./common/tasks/main.yml

- name: Install initializtion require software

  yum: name={{ item }} state=installed

  with_items:

    -zlib-devel

    -pcre-devel

    -openssl-devel
```


&emsp;&emsp;定义变量

```
[root@server roles]# vim ./install/vars/main.yml

nginx_user: www

nginx_basedir: /usr/local/nginx
```


&emsp;&emsp;定义copy文件用于拷贝所有用到的文档到目标机器

```
[root@server roles]# vim ./install/tasks/copy.yml

- name: Copy Nginx Software

  copy: src=nginx.tar.gz dest=/tmp/nginx.tar.gz owner=root group=root

- name: Uncompression Nginx Software

  shell: tar zxf /tmp/nginx.tar.gz -C /usr/local/

- name: Copy Nginx Start Script

  template: src=nginx dest=/etc/init.d/nginx owner=root group=root mode=0755

- name: Copy Nginx Config

  template: src=nginx.conf dest={{ nginx_basedir}}/conf/ owner=root group=root m

ode=0644


```


&emsp;&emsp;定义install文件

```
[root@server roles]# vim ./install/tasks/install.yml

- name: Create Nginx User

  user: name={{ nginx_user }} state=present createhome=no shell=/sbin/nologin

- name: Start Nginx Service

  service: name=nginx state=started

- name: Add Boot Start Nginx Service

  shell: chkconfig --level 345 nginx on

- name: Delete Nginx compression files

  shell: rm -rf /tmp/nginx.tar.gz
```

&emsp;&emsp;定义tasks目录下的入口文件

```
[root@server roles]# vim ./install/tasks/main.yml

- include: copy.yml

- include: install.yml
```

&emsp;&emsp;到此两个roles：common和install就定义完成了，接下来定义一个总入口配置文件。

```
[root@server ansible]# vim /etc/ansible/nginx_install/install.yml

---

- hosts: client.test.com

  remote_user: root

  gather_facts: True

  roles:

   - common

   - install
```



&emsp;&emsp;执行：

```
[root@server nginx_install]# ansible-playbook install.yml
```
