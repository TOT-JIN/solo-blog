title: puppet 安装和配置--配置认证
date: '2018-06-02 19:11:34'
updated: '2018-06-02 19:11:34'
tags: [puppet, 自动化运维]
permalink: /articles/2018/06/02/1527937894832.html
---
# puppet 安装和配置--配置认证
&emsp;&emsp;服务端查看客户端证书列表

```
[root@server ~]# puppet cert list

  "client" (SHA256) 2C:E9:BA:AD:18:A3:87:5C:E4:1D:52:58:AB:5A:48:7D:3C:7E:DD:13:C2:E4:2B:95:39:EF:3D:C7:85:BD:5F:F0

[root@server ~]# puppet cert list --all

  "client" (SHA256) 2C:E9:BA:AD:18:A3:87:5C:E4:1D:52:58:AB:5A:48:7D:3C:7E:DD:13:C2:E4:2B:95:39:EF:3D:C7:85:BD:5F:F0

+ "server" (SHA256) 92:92:D6:47:C1:0B:75:0E:7B:7C:38:AE:11:9B:27:60:28:28:FE:7C:E1:34:B3:B9:28:B9:14:EF:53:88:49:60
```

&emsp;&emsp;不加 all 仅仅显示没有被认证过的，加all会显示全部，被认证过的前面会有 + 号

&emsp;&emsp;客户端上生成ssl证书

```
[root@server ~]# puppet agent --test --server server.test.com
```

&emsp;&emsp;服务端签发指定客户端证书

```
[root@server ~]# puppet cert sign client

Notice: Signed certificate request for client

Notice: Removing file Puppet::SSL::CertificateRequest client at '/var/lib/puppet/ssl/ca/requests/client.pem'

[root@server ~]# puppet cert list --all

+ "client" (SHA256) 01:51:6D:B5:58:43:75:13:97:6F:CF:F5:A4:AB:BB:B4:EC:D0:85:24:FE:D3:70:85:69:40:52:83:46:52:CC:5B

+ "server" (SHA256) 92:92:D6:47:C1:0B:75:0E:7B:7C:38:AE:11:9B:27:60:28:28:FE:7C:E1:34:B3:B9:28:B9:14:EF:53:88:49:60
```


&emsp;&emsp;服务端可以删除指定客户端证书

```
[root@server ~]# puppet cert clean client

Notice: Revoked certificate with serial 3

Notice: Removing file Puppet::SSL::Certificate client at '/var/lib/puppet/ssl/ca/signed/client.pem'

Notice: Removing file Puppet::SSL::Certificate client at '/var/lib/puppet/ssl/certs/client.pem'

[root@server ~]# puppet cert list --all

+ "server" (SHA256) 92:92:D6:47:C1:0B:75:0E:7B:7C:38:AE:11:9B:27:60:28:28:FE:7C:E1:34:B3:B9:28:B9:14:EF:53:88:49:60
```

&emsp;&emsp;连ssl证书都没有了

&emsp;&emsp;删除所有证书

```
[root@server ~]# puppet cert clean --all

Notice: Revoked certificate with serial 2

Notice: Removing file Puppet::SSL::Certificate server at '/var/lib/puppet/ssl/ca/signed/server.pem'

Notice: Removing file Puppet::SSL::Certificate server at '/var/lib/puppet/ssl/certs/server.pem'

Notice: Removing file Puppet::SSL::Key server at '/var/lib/puppet/ssl/private_keys/server.pem'

[root@server ~]# puppet cert list --all

```

&emsp;&emsp;恢复证书，就是再重新生成一个，和以前不一样了。

&emsp;&emsp;因为对服务端而言，客户端和服务端都是它自己，删除时就比较彻底，重新用上面的命令生成一个就可以了。但是对客户端来说，服务端只能删除服务端上的关于客户端的ssl证书，客户端上的还在，这会影响重新生成，所以需要清空该旧证书。

```
[root@client ~]# rm -rf /var/lib/puppet/ssl/*

[root@client ~]# puppet agent --test --server server.test.com

Info: Creating a new SSL key for client

Info: Caching certificate for ca

Info: csr_attributes file loading from /etc/puppet/csr_attributes.yaml

Info: Creating a new SSL certificate request for client

Info: Certificate Request fingerprint (SHA256): AA:08:09:6D:2F:CC:66:A5:64:05:60:C0:CF:CD:E4:F0:F0:54:C0:E3:D3:E5:E3:4E:68:E3:22:C1:50:4E:73:BF

Info: Caching certificate for ca

Exiting; no certificate found and waitforcert is disabled


[root@server ~]# puppet cert list --all

  "client" (SHA256) AA:08:09:6D:2F:CC:66:A5:64:05:60:C0:CF:CD:E4:F0:F0:54:C0:E3:D3:E5:E3:4E:68:E3:22:C1:50:4E:73:BF

  "server" (SHA256) 37:AA:5F:83:19:EC:6D:95:8E:74:8A:E1:06:65:E4:EC:99:75:47:07:55:0C:29:67:6A:48:83:5A:81:0F:79:6A
```


&emsp;&emsp;此时重新认证就好了

---


&emsp;&emsp;puppet 配置自动签发证书

         

&emsp;&emsp;服务端删除客户端证书

&emsp;&emsp;注意：正常情况下，服务端是没有即将被认证的客户端的ssl证书的，但由于我们之前的实验产生了证书，会影响之后的自动认证，所以clean掉它。

```
[root@server ~]# puppet cert clean client
```


&emsp;&emsp;客户端删除ssl相关文件

```
[root@client ~]# rm -rf /var/lib/puppet/ssl/*
```


&emsp;&emsp;服务端创建自动签发的配置文件 /etc/puppet/autosign.conf

```
[root@server ~]# vim /etc/puppet/autosign.conf

*.test.com
```


&emsp;&emsp;服务端编辑配置文件 /etc/puppet/puppet.conf 在 [main] 模块中加入如下语句，打开自动认证开关

```
[root@server ~]# vim /etc/puppet/puppet.conf

    autosign = true
```


&emsp;&emsp;服务端重启puppetmaster服务

```
[root@server ~]# service puppetmaster restart

停止 puppetmaster：                                        [确定]

启动 puppetmaster：                                        [确定]
```


&emsp;&emsp;客户端重启puppet服务

```
[root@client ~]# service puppet restart

Stopping puppet agent:                                     [失败]

Starting puppet agent:                                     [确定]
```


&emsp;&emsp;服务端查看签名，client已被认证

```
[root@server ~]# puppet cert list --all

+ "client" (SHA256) 40:BC:32:10:BB:60:CA:8F:77:39:F9:E4:4A:B6:DE:75:35:63:0F:DE:FE:48:2D:02:9C:C4:D0:CE:CE:E4:A5:61

+ "server" (SHA256) EE:5D:D5:1E:07:E0:08:C7:80:75:D7:3F:23:1C:34:34:F4:19:1C:F7:48:4A:15:72:DF:EF:3E:63:88:44:2F:69
```
