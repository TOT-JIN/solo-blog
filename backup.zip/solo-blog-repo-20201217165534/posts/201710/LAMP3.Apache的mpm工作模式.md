title: LAMP--3.Apache 的 mpm 工作模式
date: '2017-10-04 18:23:41'
updated: '2017-10-04 18:23:41'
tags: [lamp, httpd, mpm]
permalink: /articles/2017/10/03/1507112621673.html
---
# LAMP--3.Apache 的 mpm 工作模式
查看 apache 工作模式的命令是：

```e-bash
[root@localhost ~]# /usr/local/apache2/bin/apachectl -M
httpd: Could not reliably determine the server's fully qualified domain name, using localhost.localdomain for ServerName
Loaded Modules:
 core_module (static)
 authn_file_module (static)
 authn_default_module (static)
 authz_host_module (static)
 authz_groupfile_module (static)
 authz_user_module (static)
 authz_default_module (static)
 auth_basic_module (static)
 include_module (static)
 filter_module (static)
 log_config_module (static)
 env_module (static)
 setenvif_module (static)
 version_module (static)
 mpm_prefork_module (static)
 http_module (static)
 mime_module (static)
 status_module (static)
 autoindex_module (static)
 asis_module (static)
 cgi_module (static)
 negotiation_module (static)
 dir_module (static)
 actions_module (static)
 userdir_module (static)
 alias_module (static)
 so_module (static)
Syntax OK
```





通过这个命令也可以看到哪些模块是动态，哪些模块是静态。其中以 mpm_ 开头的就是 apache 的 mpm 工作模式，2.2版本的httpd默认的mpm工作模式为 prefork 。除了 prefork 外，常见的工作模式还有 worker 以及 event 。2.4版本的 httpd 默认是 event 工作模式。
