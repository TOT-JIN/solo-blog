title: gzip bzip2 zip和unzip 讲解
date: '2016-12-27 16:19:52'
updated: '2016-12-27 16:19:52'
tags: [gzip, bzip2, zip, unzip]
permalink: /articles/2016/12/27/1482826792856.html
---
# gzip bzip2 zip和unzip 讲解
**gzip 讲解**



**语法：gzip [-d#] filename 其中#为1-9的数字**

**-d：解压缩时使用**

**-#：压缩等级，1 压缩最差，9 压缩最好，6 为默认**

```e-bash
[root@localhost ~]# [ -d test ] && rm -rf test
[root@localhost ~]# mkdir test
[root@localhost ~]# touch test/test.txt
[root@localhost ~]# cd test
[root@localhost test]# ls
test.txt
[root@localhost test]# gzip test.txt
[root@localhost test]# ls
test.txt.gz
```



**第一条命令其实是两条命令，[ ]内是一个判断。“ -d test ”判断 test 目录是否存在， && 为一个连接命令符合，当前面的命令执行成功后，后面的命令才执行。gzip 后面直接跟文件名，就在当前目录下把文件给压缩了，而原文件也会消失。**

```e-bash
[root@localhost test]# gzip -d test.txt.gz
[root@localhost test]# ls
test.txt
```



**“ gzip -d ”后面跟压缩文件，会解压压缩文件。gzip是不支持压缩目录的。**

```e-bash
[root@localhost ~]# gzip test
gzip: test is a directory -- ignored
```



**至于“-#”选项，很少用到，使用默认压缩级别就可以了。**

**zcat 查看.gz 的文本文件内容。**

```e-bash
[root@localhost ~]# zcat test/test.txt.gz
```



---

**bzip2 讲解**

**语法： bzip2 [-dz] filename**

**bzip2 只有两个选项需要掌握。**

**-d：解压缩**

**-z：压缩**

**压缩时，可以加“-z”也可以不加，都可以压缩文件，“-d”为解压的选项：**

```e-bash
[root@localhost ~]# cd test
[root@localhost test]# bzip2 test.txt
[root@localhost test]# ls
test.txt.bz2
[root@localhost test]# bzip2 -d test.txt.bz2
[root@localhost test]# bzip2 -z test.txt
[root@localhost test]# ls
test.txt.bz2
```



**bzip2 同样也不可以压缩目录：**

```e-bash
[root@localhost test]# cd ..
[root@localhost ~]# bzip2 test
bzip2: Input file test is a directory.
[root@localhost ~]# cd test
[root@localhost test]# ls
test.txt.bz2
```



**bzcat 查看 .bz2 的文本文件内容**

```e-bash
[root@localhost test]# zcat test.txt.bz2
gzip: test.txt.bz2: not in gzip format
[root@localhost test]# bzcat test.txt.bz2
```



---

zip 和 unzip

**zip 可以压缩目录也可以压缩文件，压缩目录时，需要指定目录下的文件。**

```e-bash
[root@localhost ~]# zip 1.txt.zip 1.txt
[root@localhost ~]# zip dirb.zip dirb/*
```



**说明：zip 后面先跟目标文件名，也就是压缩后的自定义压缩包名，然后是要压缩的文件或者目录。若没有此命令，使用 yum install -y zip 安装。当目录下还有二级子目录或更多级目录时，zip 并不会把二级目录下的文件压缩，而仅仅是把二级目录本身压缩，有个级联的选项 -r**

```e-bash
[root@localhost ~]# zip -r dirb.zip dirb/
  adding: dirb/ (stored 0%)
  adding: dirb/filee (stored 0%)
  adding: dirb/dirc/ (stored 0%)
```



**这样也不需要用 `dirb/*` 了。使用 zip 压缩目录时，必须加 -r 选项。**

**解压命令 unzip ：**

```e-bash
[root@localhost ~]# yum install -y unzip
[root@localhost ~]# unzip 1.txt.zip
Archive:  1.txt.zip
replace 1.txt? [y]es, [n]o, [A]ll, [N]one, [r]ename: y
 extracting: 1.txt
[root@localhost ~]# unzip dirb.zip
Archive:  dirb.zip
replace dirb/filee? [y]es, [n]o, [A]ll, [N]one, [r]ename: y
 extracting: dirb/filee
```



**如果有原文件，会提示是否覆盖**

---

xz 压缩和解压缩

**xz 和 gzip，bzip2用法是一样的。默认系统是没有这个命令的，yum 安装。**

**语法：xz [-dz] filename**

**-d：解压缩**

**-z：压缩**

**压缩时仍然可以加“-z”也可以不加，解压时要加“-d”。**

```e-bash
[root@localhost test]# xz test.txt
[root@localhost test]# ls
test.txt.xz
[root@localhost test]# xz -d test.txt.xz
[root@localhost test]# ls
test.txt
[root@localhost test]# xz -z test.txt
[root@localhost test]# ls
test.txt.xz
```



**xz 同样不能压缩目录。xzcat 查看 .xz的文本文件内容。**

```e-bash
[root@localhost test]# xzcat test.txt.xz
```
