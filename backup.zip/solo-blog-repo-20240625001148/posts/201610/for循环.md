title: for 循环
date: '2016-10-11 19:45:13'
updated: '2016-10-11 19:45:13'
tags: [shell, for]
permalink: /articles/2016/10/11/1476186313856.html
---
# for 循环
简单的 for 循环脚本：

```
[root@133 ~]# vim for.sh
#!/bin/bash

for i in `seq 1 5`;do
   echo $i
done
```

脚本中的seq 1 5表示输出一个从1到5的序列。脚本的执行结果为：

```
[root@133 ~]# sh for.sh
1
2
3
4
5
```

通过这个脚本就可以看到 for 循环的基本结构：

&emsp;for  变量名  in  循环的条件; do
&emsp;&emsp;&emsp;command
&emsp;done


这里的“循环条件”可以写成一组字符串或者数字（用一个或多个空格隔开），也可以是一条命令的执行结果：

```
[root@133 ~]# for i in 1 2 3 a b;do echo $i;done
1
2
3
a
b
```


也可以写成引用系统命令的执行结果，就像那个 seq 1 5 但是需要用反引号括起来：

```
[root@133 ~]# for file in `ls`;do echo $file;done
123.sql
1.txt
anaconda-ks.cfg
case.sh
filename
for.sh
id.txt
if1.sh
if2.sh
if3.sh
install.log
install.log.syslog
```
