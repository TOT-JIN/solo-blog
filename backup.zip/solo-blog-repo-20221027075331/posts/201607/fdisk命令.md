title: fdisk 命令
date: '2016-07-02 14:23:45'
updated: '2016-07-02 14:23:45'
tags: [fdisk, Linux]
permalink: /articles/2016/07/02/1467440625856.html
---
# fdisk 命令
**fdisk 命令**


**语法  fdisk [-l] [设备名称]**

**-l 后边不跟设备名会直接列出系统中所有的磁盘设备以及分区表，加上设备名会列出该设备的分区表。**

```
[root@localhost ~]# fdisk -l

Disk /dev/sda: 21.5 GB, 21474836480 bytes

255 heads, 63 sectors/track, 2610 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x000eb8f3

   Device Boot      Start         End      Blocks   Id  System

/dev/sda1   *           1          26      204800   83  Linux

Partition 1 does not end on cylinder boundary.

/dev/sda2              26         287     2097152   82  Linux swap / Solaris

Partition 2 does not end on cylinder boundary.

/dev/sda3             287        2611    18668544   83  Linux

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x00000000
```

**对比一下：**

```
[root@localhost ~]# fdisk -l /dev/sda

Disk /dev/sda: 21.5 GB, 21474836480 bytes

255 heads, 63 sectors/track, 2610 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x000eb8f3

   Device Boot      Start         End      Blocks   Id  System

/dev/sda1   *           1          26      204800   83  Linux

Partition 1 does not end on cylinder boundary.

/dev/sda2              26         287     2097152   82  Linux swap / Solaris

Partition 2 does not end on cylinder boundary.

/dev/sda3             287        2611    18668544   83  Linux
```

**可以看到一块儿未被分区的磁盘 /dev/sdb 的信息。**



**fdisk 如果不加 -l 则进入另一个模式，在该模式下，可以对磁盘进行分区操作。**

```
[root@localhost ~]# fdisk /dev/sda

WARNING: DOS-compatible mode is deprecated. It's strongly recommended to

         switch off the mode (command 'c') and change display units to

         sectors (command 'u').

Command (m for help): m           //输入 m 会列出常用的命令

Command action

   a   toggle a bootable flag

   b   edit bsd disklabel

   c   toggle the dos compatibility flag

   d   delete a partition

   l   list known partition types

   m   print this menu

   n   add a new partition

   o   create a new empty DOS partition table

   p   print the partition table

   q   quit without saving changes

   s   create a new empty Sun disklabel

   t   change a partition's system id

   u   change display/entry units

   v   verify the partition table

   w   write table to disk and exit

   x   extra functionality (experts only)
```

**p 打印当前磁盘的分区情况：**

```
Command (m for help): p

Disk /dev/sda: 21.5 GB, 21474836480 bytes

255 heads, 63 sectors/track, 2610 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x000eb8f3

   Device Boot      Start         End      Blocks   Id  System

/dev/sda1   *           1          26      204800   83  Linux

Partition 1 does not end on cylinder boundary.

/dev/sda2              26         287     2097152   82  Linux swap / Solaris

Partition 2 does not end on cylinder boundary.

/dev/sda3             287        2611    18668544   83  Linux
```

**n 建立一个新的分区**

**w 保存操作**

**q 退出**

**d 删除一个分区**



**下面把刚刚显示的未分区磁盘 /dev/sdb 进行分区**

```
[root@localhost ~]# fdisk /dev/sdb

Device contains neither a valid DOS partition table, nor Sun, SGI or OSF disklabel

Building a new DOS disklabel with disk identifier 0x4cb6a167.

Changes will remain in memory only, until you decide to write them.

After that, of course, the previous content won't be recoverable.

Warning: invalid flag 0x0000 of partition table 4 will be corrected by w(rite)

WARNING: DOS-compatible mode is deprecated. It's strongly recommended to

         switch off the mode (command 'c') and change display units to

         sectors (command 'u').

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x4cb6a167

   Device Boot      Start         End      Blocks   Id  System

Command (m for help):
```

**可以看到目前/dev/sdb 没有任何分区，下面建立第一个分区：**

```
Command (m for help): n                     //使用 n 命令新建分区

Command action                                 //它会提示是要 e（扩展分区）还是要 p （主分区）。这里选择 p 

   e   extended                                      

   p   primary partition (1-4)

p

Partition number (1-4): 1                      //提示分区数，这里选择1

First cylinder (1-1305, default 1): 1            //提示第一个柱面从哪里开始，默认是1，直接回车也会按1处理。

Last cylinder, +cylinders or +size{K,M,G} (1-1305, default 1305): +1024M            //提示输入最后一个柱面的数值，使用另一种方法：+容量 单位

Command (m for help): p                            //再次查看会发现多出了一个分区

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x4cb6a167

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb1               1         132     1060258+  83  Linux

Command (m for help):
```

**继续上面的操作，一直创建主分区到4，然后再一次创建分区时会提示：**

```
Command (m for help): n

You must delete some partition and add an extended partition first
```

**这是因为在linux系统中最多只能创建4个主分区。如果想要多创建几个分区需要有一个扩展分区，例如把第四个分区创建成扩展分区**

```
Command (m for help): n

Command action

   e   extended

   p   primary partition (1-4)

e

Selected partition 4

First cylinder (397-1305, default 397):

Using default value 397

Last cylinder, +cylinders or +size{K,M,G} (397-1305, default 1305):                   //第四个扩展分区需要把剩余的磁盘空间全部占用

Using default value 1305

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x4cb6a167

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb1               1         132     1060258+  83  Linux

/dev/sdb2             133         264     1060290   83  Linux

/dev/sdb3             265         396     1060290   83  Linux

/dev/sdb4             397        1305     7301542+   5  Extended           //扩展分区，在最后一列显示为 Extended 
```

**继续创建：**

```
Command (m for help): n

First cylinder (397-1305, default 397):          //这时候不再选择主分区还是扩展分区了，而是直接定义大小

Using default value 397

Last cylinder, +cylinders or +size{K,M,G} (397-1305, default 1305): +1024M

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x4cb6a167

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb1               1         132     1060258+  83  Linux

/dev/sdb2             133         264     1060290   83  Linux

/dev/sdb3             265         396     1060290   83  Linux

/dev/sdb4             397        1305     7301542+   5  Extended

/dev/sdb5             397         528     1060258+  83  Linux
```

**当分完三个主分区后，第四个扩展分区要占用全部剩余空间的原因是：分完扩展分区后，再划分新的分区是在已经划分的扩展分区上去划分的。其中/dev/sdb4为扩展分区，它是不可以被格式化的，就相当于一个空壳子，能使用的为/dev/sdb5，这个分区叫做逻辑分区，是/dev/sdb4的子分区。**



**删除某分区： d 命令**

```
Command (m for help): d

Partition number (1-5): 1

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x4cb6a167

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb2             133         264     1060290   83  Linux

/dev/sdb3             265         396     1060290   83  Linux

/dev/sdb4             397        1305     7301542+   5  Extended

/dev/sdb5             397         528     1060258+  83  Linux

Command (m for help): d

Partition number (1-5): 5

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x4cb6a167

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb2             133         264     1060290   83  Linux

/dev/sdb3             265         396     1060290   83  Linux

/dev/sdb4             397        1305     7301542+   5  Extended

Command (m for help): n

Command action

   l   logical (5 or over)

   p   primary partition (1-4)

l

First cylinder (397-1305, default 397):

Using default value 397

Last cylinder, +cylinders or +size{K,M,G} (397-1305, default 1305): +1024M

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x4cb6a167

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb2             133         264     1060290   83  Linux

/dev/sdb3             265         396     1060290   83  Linux

/dev/sdb4             397        1305     7301542+   5  Extended

/dev/sdb5             397         528     1060258+  83  Linux

Command (m for help): d

Partition number (1-5): 4

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0x4cb6a167

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb2             133         264     1060290   83  Linux

/dev/sdb3             265         396     1060290   83  Linux
```


**输入d会提示要删除那个分区，可以选择1-5，其中1-3为主分区。4是扩展分区，5是逻辑分区。如果输入5，则直接把逻辑分区sdb5删除掉，如果输入4，则会把整个扩展分区sdb4干掉，也包含扩展分区里面的逻辑分区。在刚才的界面中直接Ctrl+C退出来，这样刚刚的分区全部都取消了。**



**重新做分区：**

```
[root@localhost ~]#  fdisk /dev/sdb

Device contains neither a valid DOS partition table, nor Sun, SGI or OSF disklabel

Building a new DOS disklabel with disk identifier 0xb2b18b55.

Changes will remain in memory only, until you decide to write them.

After that, of course, the previous content won't be recoverable.

Warning: invalid flag 0x0000 of partition table 4 will be corrected by w(rite)

WARNING: DOS-compatible mode is deprecated. It's strongly recommended to

         switch off the mode (command 'c') and change display units to

         sectors (command 'u').

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0xb2b18b55

   Device Boot      Start         End      Blocks   Id  System

Command (m for help): n

Command action

   e   extended

   p   primary partition (1-4)

e

Partition number (1-4): 1

First cylinder (1-1305, default 1):

Using default value 1

Last cylinder, +cylinders or +size{K,M,G} (1-1305, default 1305):

Using default value 1305

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0xb2b18b55

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb1               1        1305    10482381    5  Extended

Command (m for help): n

Command action

   l   logical (5 or over)

   p   primary partition (1-4)

l

First cylinder (1-1305, default 1):

Using default value 1

Last cylinder, +cylinders or +size{K,M,G} (1-1305, default 1305): +1024M

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0xb2b18b55

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb1               1        1305    10482381    5  Extended

/dev/sdb5               1         132     1060227   83  Linux

Command (m for help): n

Command action

   l   logical (5 or over)

   p   primary partition (1-4)

l

First cylinder (133-1305, default 133):

Using default value 133

Last cylinder, +cylinders or +size{K,M,G} (133-1305, default 1305): +1024M

Command (m for help): p

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0xb2b18b55

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb1               1        1305    10482381    5  Extended

/dev/sdb5               1         132     1060227   83  Linux

/dev/sdb6             133         264     1060258+  83  Linux

Command (m for help): w                                        // w 命令保存配置

The partition table has been altered!

Calling ioctl() to re-read partition table.

Syncing disks.

**查看分区情况**

[root@localhost ~]# fdisk -l /dev/sdb

Disk /dev/sdb: 10.7 GB, 10737418240 bytes

255 heads, 63 sectors/track, 1305 cylinders

Units = cylinders of 16065 * 512 = 8225280 bytes

Sector size (logical/physical): 512 bytes / 512 bytes

I/O size (minimum/optimal): 512 bytes / 512 bytes

Disk identifier: 0xb2b18b55

   Device Boot      Start         End      Blocks   Id  System

/dev/sdb1               1        1305    10482381    5  Extended

/dev/sdb5               1         132     1060227   83  Linux

/dev/sdb6             133         264     1060258+  83  Linux
```
