title: mysql的root密码重置
date: '2018-09-02 22:12:43'
updated: '2018-09-02 22:12:43'
tags: [mysql]
permalink: /articles/2018/09/02/1535897563812.html
---
# mysql的root密码重置
&emsp;&emsp;在日常工作中，不免会遇到mysql root密码忘记的情况，如果是root密码忘记的话，则有单用户，救援模式，mysql也有类似的功能。

&emsp; **（1）编辑 mysql 主配置文件 my.cnf**

&emsp;&emsp;在[mysqld]字段下添加参数 skip-grant

```
[root@128 mysql]# vim /etc/my.cnf


[mysqld]

port            = 3306

socket          = /tmp/mysql.sock

skip-locking

skip-grant

key_buffer_size = 256M

max_allowed_packet = 1M
```


&emsp; **（2）重启数据库服务**

```
[root@128 mysql]# service mysqld restart

Shutting down MySQL.. SUCCESS!

Starting MySQL. SUCCESS!
```


&emsp; **（3）这样就可以进入数据库不用授权了**

```
[root@128 mysql]# mysql -uroot

Welcome to the MySQL monitor.  Commands end with ; or \g.

Your MySQL connection id is 1

Server version: 5.1.73-log MySQL Community Server (GPL)



Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.



Oracle is a registered trademark of Oracle Corporation and/or its

affiliates. Other names may be trademarks of their respective

owners.



Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.



mysql>
```


&emsp; **（4）修改相应用户密码**

```
mysql> use mysql;

Database changed

mysql> update user set password=PASSWORD('test123') where user='root';

Query OK, 3 rows affected (0.01 sec)

Rows matched: 3  Changed: 3  Warnings: 0



mysql> flush privileges;

Query OK, 0 rows affected (0.00 sec)



mysql> quit

Bye
```


&emsp; **（5）修改 /etc/my.cnf 去掉 skip-grant，重启 mysqld 服务**

```
[root@128 mysql]# mysql -uroot

ERROR 1045 (28000): Access denied for user 'root'@'localhost' (using password: NO)

[root@128 mysql]# mysql -uroot -ptest123

Welcome to the MySQL monitor.  Commands end with ; or \g.

Your MySQL connection id is 2

Server version: 5.1.73-log MySQL Community Server (GPL)



Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.



Oracle is a registered trademark of Oracle Corporation and/or its

affiliates. Other names may be trademarks of their respective

owners.



Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.



mysql>
```




---


mysql5.7之root密码更改

http://www.apelearn.com/bbs/forum.php?mod=viewthread&tid=7289&fromuid=7096

(出处: 【阿铭Linux】)











输入上面的密码aJqZsA2m登录，如果你没有把mysql的路径加到path里，那就用绝对路径，mysql -u root -p还可以写成mysql -uroot -paJqZsA2m


三、更改密码

mysql> SET PASSWORD  FOR 'root'@localhost = PASSWORD（'123456'）；
Query OK, 0 rows affected (0.17 sec)
