title: chmod chown 命令及 chattr 文件隐藏属性
date: '2016-05-28 18:10:09'
updated: '2016-05-28 18:10:09'
tags: [chmod, chattr, chown, Linux]
permalink: /articles/2016/05/27/1464430209592.html
---
# chmod chown 命令及 chattr 文件隐藏属性

**CHMOD命令**

在Linux中为了方便更改所有者、所属组以及其他用户对文件的权限，可以使用数字去代替 rwx ，具体规则是 r 等于 4 ， w 等于2 ， x 等于 1 ， - 等于 0 。

举个例子：“-rwxrwx---”用数字表示就是 770，具体是这样实现的; rwx=4+2+1=7 ; rwx=4+2+1=7 ; ---=0+0+0=0 。

**chmod** 语法： chmod  [-R] xyz filename  (xyz 表示数字，如上例中770)

-R 选项表示级联更改

Linux系统中，root用户，默认一个目录的权限为755 ， 而一个文件的权限为644 ，原因是目录实质是一个可执行性文件，故当我们编辑成一个脚本文件想要执行前，必须赋予x 执行权限。

除数字设置外，肯定也支持rwx设置权限。基本上就九个属性分别是（1）user，（2）group，（3）others，我们可以使用u，g，o来代表它们三个的属性，还有， a 代表 all 即全部（ugo）。

例：

```
[root@localhost~]# chmod u=rwx,og=rx test/test2
[root@localhost~]# ls -l test/test2
-rwxr-xr-x 1 user 1 testgroup 0 5 月 10 09：00 test/test2
```



这样可以把“test/test2“文件权限修改为”rwxr-xr-x“。另外还可以针对u、g、o、a 增加或减少某个权限。

例：

```
[root@localhost~]# chmod u-x test/test2
[root@localhost~]# chmod a-x test/test2
[root@localhost~]# chmod u+x test/test2
```

命令 **umask**

在默认的情况下，目录权限值为755，普通文件权限值为644，那么这个值是怎么设定的呢？ 关键因素即为 umask，单单从字形上看，有些像子网掩码netmask，原理相似。首先查看一下预设的umask：

```
[root@localhost~]# umask
0022
```

umask预设是0022，它的含义在于：设置user、group、others的权限的不同，如若初始未设umask（0000），普通文件的权限应为666（-rw-rw-rw-），目录权限应为777（drwxrwxrwx）。

此时umask为0022，所以目录权限为”rwxrwxrwx“ - ”----w--w-“=”rwxr-xr-x“，普通文件的权限为”rw-rw-rw-“-”----w--w-“=”rw-r--r--“。

umask的值是可以自定义的，比如设定umask为002，再创建目录或文件时，默认权限分别为”rwxrwxrwx“ - ”-------w-“=”rwxrwxr-x“

和”rw-rw-rw-“-”-------w-“=”rw-rw-r--“

**umask** 语法： umask xxx     (xxx 代表三个数字，仅能改变umask值的后三位)

---

**CHOWN命令**

对于一个文件来说，会有一个所有者，所属组和其他人的关系，linux这样设置文件属性是为了文件的安全。

我们可以用 ls -l 来查看这些属性。

更改所属组 chgrp

语法  chgrp [组名] [文件名]

```
[root@localhost~]# groupadd testgroup
[root@localhost~]# touch test1
[root@localhost~]# ls -l test1
-rw-r--r-- 1 root root 0 5 月 10 08:41 test1
[root@localhost~]# chgrp testgroup test1
[root@localhost~]# ls -l test1
-rw-r--r-- 1 root testgroup 0 5 月 10 08:41 test1
```



这里用到了”groupadd“命令，其含义为增加一个用户组。chgrp 除了更改文件的所属组，还可以更改目录的所属组，但是只能改变目录本身，而目录下面的文件或目录没有更改，要想级联更改子目录以及子文件，有个选项可以实现：

```
[root@localhost~]# chgrp -R testgroup dirb
[root@localhost~]# ls -l dirb
总用量 8
drwxr-xr-x. 2 root testgroup 4096 5 月 10 05:08 dirc
-rw-r--r--. 1 root testgroup 20 5 月 10 05:37 filee
```

还有一个命令能替代chgrp

更改文件的所有者 chown

语法 chown [-R] 账户名 文件名

chown [-R] 账户名：组名 文件名

-R 选项只作用于目录，作用是级联更改，即不仅更改当前目录，连目录里的目录或文件全部更改。

```
[root@localhost~]# mkdir test
[root@localhost~]# useradd user1
[root@localhost~]# touch test/test2
[root@localhost~]# chown user1 test
[root@localhost~]# ls -l test
总用量 0
-rw-r--r-- 1 root root 0 5 月 10 09:00 test2
[root@localhost~]# ls -ld test
drwxr-xr-x 2 user1 root 4096 5 月 10 09:00 test
[root@localhost~]# ls -l test
总用量 0
-rw-r--r-- 1 root root 0 5 月 10 09:00 test2
[root@localhost~]# chown -R user1:testgroup test
[root@localhost~]# ls -l test
总用量 0
-rw-r--r-- 1 root testgroup 0 5 月 10 09:00 test2
```

”chown -R user1:testgroup“会把test目录以及目录下的文件都修改成所属主为user1，所属组为testgroup。

---

**chattr** 文件隐藏属性

命令 chattr

语法 chattr [+-=][Asaci][文件或目录名]

+-=： 分别为增加、减少、设定

A : 增加该属性后，文件或目录的atime将不可被修改；

S : 增加该属性后，会将数据同步写入磁盘中；

a : 增加该属性后，只能追加不能删除，非root用户将不可设定该属性；

c : 自动压缩该文件，读取时会自动解压；

i : 增加后，使文件不能被删除、重命名、设定链接、写入、新增数据；

其中常用的为 a 和 i 两个选项。

```
[root@localhost~]# chattr +i test2
[root@localhost~]# touch test2/test1
touch:无法创建'test2/test1':权限不够
[root@localhost~]# chattr -i test2
[root@localhost~]# touch test2/test1
[root@localhost~]# chattr +i test2
[root@localhost~]# rm-f test2/test1
rm : 无法删除'test2/test1':权限不够
```



对test2目录增加 i 权限后，即使root用户也不能在test2目录中创建或删除文件。

```
[root@localhost~]# chattr -i test2
[root@localhost~]# touch test2/test3
[root@localhost~]# ls test2
test1 test3
[root@localhost~]# chattr +a test2
[root@localhost~]# rm -f test2/test1
rm :无法删除'test2/test1'：不允许的操作
[root@localhost~]#  touch test2/test4
[root@localhost~]# ls test2
test1 test3 test4
```



test2目录增加 a 权限后，只可以在里面创建文件，而不能删除文件。文件同样可以适用这些权限。

```
[root@localhost~]# chattr +a test2/test1
[root@localhost~]# echo '11111'>test2/test1
-bash：test2/test1：不允许的操作
[root@localhost~]# echo '11111'>>test2/test1
[root@localhost~]#  cat test2/test1
11111
[root@localhost~]# chattr +i test2/test3
[root@localhost~]# echo '11111'>>test2/test3
-bash : test2/test3 : 权限不够
[root@localhost~]# echo '11111'> test2/test3
-bash : test2/test3 : 权限不够
[root@localhost~]# rm -f test2/test3
rm : 无法删除'test2/test3' :权限不够
```



命令  **lsattr**

语法 lsattr [-aR] [文件/目录名]

该命令用来读取文件或目录的特殊权限

-a ：类似与 ls 的 -a 选项，即连同隐藏文件一同列出；

-R ：连同子目录的数据一同列出

```
[root@localhost~]# lsattr test2
-----a-------e- test2/test1
----i--------e- test2/test3
-------------e- test2/test4
[root@localhost~]# lsattr -aR test2
----i--------e- test2/.
-----a-------e- test2/test1
-------------e- test2/..
----i--------e- test2/test3
-------------e- test2/test4
```
