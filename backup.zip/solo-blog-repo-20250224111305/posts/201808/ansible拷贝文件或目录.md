title: ansible 拷贝文件或目录
date: '2018-08-03 22:31:24'
updated: '2018-08-03 22:31:24'
tags: [ansible, 自动化运维]
permalink: /articles/2018/08/03/1533306684832.html
---
# ansible 拷贝文件或目录
&emsp;&emsp;拷贝文件用到的模块是copy

```
[root@server ~]# ansible testhosts -m copy -a "src=/etc/ansible dest=/tmp/ansibletest owner=root group=root mode=0644"

client.test.com | SUCCESS => {

    "changed": true,

    "dest": "/tmp/ansibletest/",

    "src": "/etc/ansible"

}

127.0.0.1 | SUCCESS => {

    "changed": true,

    "dest": "/tmp/ansibletest/",

    "src": "/etc/ansible"

}
```


&emsp;&emsp;注意：源目录会放到目标目录下去，如果目标指定的目录不存在，它会自动创建。如果拷贝的是文件，dest指定的名字和源如果不同，并且它不是一个已经存在的目录，那么就相当于把src指定的文件拷贝过去又重命名。但是，如果dest是目标机器上已经存在的目录，则会直接把文件拷贝到该目录下面。



&emsp;&emsp;例：

```
[root@server ~]# ansible testhosts -m copy -a "src=/etc/passwd dest=/tmp/123"
```


&emsp;&emsp;这里的 /tmp/123和源机器上的/etc/passwd是一致的，但如果目标机器上已经有/tmp/123目录，则会在/tmp/123目录下建立passwd文件。
