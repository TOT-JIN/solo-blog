title: ansible 远程执行脚本
date: '2018-08-04 12:21:14'
updated: '2018-08-04 12:21:14'
tags: [ansible, 自动化运维]
permalink: /articles/2018/08/03/1533356474832.html
---
# ansible 远程执行脚本
&emsp;&emsp;首先创建一个shell脚本

```
[root@server ~]# vim /tmp/test.sh

#!/bin/bash

echo `date` > /tmp/ansible_test.txt
```


&emsp;&emsp;然后把该脚本分发到各个机器上

```
[root@server ~]# ansible testhosts -m copy -a "src=/tmp/test.sh dest=/tmp/test.sh mode=0755"
```


&emsp;&emsp;批量执行该脚本

```
[root@server ~]# ansible testhosts -m shell -a "/tmp/test.sh"

client.test.com | SUCCESS | rc=0 >>



127.0.0.1 | SUCCESS | rc=0 >>
```


&emsp;&emsp;查看一下

```
[root@server ~]# ansible testhosts -m shell -a "cat /tmp/ansible_test.txt"

127.0.0.1 | SUCCESS | rc=0 >>

2016年 07月 10日 星期日 23:44:13 CST



client.test.com | SUCCESS | rc=0 >>

2016年 07月 10日 星期日 23:44:20 CST
```


&emsp;&emsp;shell模块，还支持远程执行命令并且带管道符

```
[root@server ~]# ansible testhosts -m shell -a "cat /etc/passwd|wc -l"

127.0.0.1 | SUCCESS | rc=0 >>

26



client.test.com | SUCCESS | rc=0 >>

26
```
