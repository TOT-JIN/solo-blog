title: LAMP--Apache 禁止指定 user_agent
date: '2017-12-01 12:18:29'
updated: '2017-12-01 12:18:29'
tags: [lamp, httpd, user_agent]
permalink: /articles/2017/12/01/1512101909673.html
---
# LAMP--Apache 禁止指定 user_agent
user_agent 可以当作浏览器标识，目前主流的浏览器有 IE、chrome、Firefox、360、iPhone上的 Safari、Android 手机上的百度搜索引擎、google搜索引擎等很多，每一种浏览器都有对应的 user_agent，下面列出几个常见的 user_agent。

       Mozilla/4.0(compatible; MSIE 6.0; Windows NT 5.1; Trident/4.0; .NET4.0C; .NET4.0E; SE 2.x)

       Mozilla/5.0(Windows NT 5.1) AppleWebKit/537.36 (KHTML,like Gecko) Chrome/31.0.1650.63 Safari/537.36

       Mozilla/5.0(compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)

       Mozilla/4.0(compatible; MSIE 8.0; Windows NT 5.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729;Media Center PC 6.0; .NET4.0C; .NET4.0E; InfoPath.3; 360SE)

针对 user_agent 做一些限制。

配置如下：

            <IfModule mod_rewrite.c>

               RewriteEngine on

               RewriteCond %{HTTP_USER_AGENT} ^*Firefox/4.0* [NC,OR]

               RewriteCond %{HTTP_USER_AGENT} ^*Tomato Bot/1.0* [NC]

               RewriteRule .* - [F]

            </IfModule>

同样是使用 rewrite 模块来实现限制指定 user_agent，在本例中，RewriteRule .* - [F] 可以直接禁止访问，rewritecond 用 user_agent 来匹配， *Firefox/4.0* 表示，只要 user_agent 中含有 Firefox/4.0 就符合条件，其中 * 表示任意字符，NC 表示不区分大小写，OR表示或者，连接下一个条件。假如要把百度的搜索引擎限制掉，可以加一条这样的规则：

           RewriteCond %{HTTP_USER_AGENT} ^*Baiduspider/2.0* [NC]

           RewriteRule .* - [F]

既然有了 或者OR，那也得有并且，只要不写 OR 就是并且的意思。
