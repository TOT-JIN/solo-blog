title: 查看系统负载 命令 w
date: '2016-08-08 18:23:44'
updated: '2016-08-08 18:23:44'
tags: [系统负载, 运维]
permalink: /articles/2016/08/08/1470651824345.html
---
# 查看系统负载 命令 w
```
[root@localhost ~]# w

 19:16:18 up 1 day, 12:02,  2 users,  load average: 0.02, 0.01, 0.00

USER     TTY      FROM              LOGIN@   IDLE   JCPU   PCPU WHAT

root     tty1     -                13:24    5:52m  0.03s  0.03s -bash

root     pts/0    192.168.56.1     19:15    0.00s  0.33s  0.11s w
```



&emsp;&emsp;这个 w 命令是linux系统管理员最常用的命令了，该命令显示的信息还是挺丰富的。第一行从左边开始显示的信息依次为：时间、系统运行时间、登录用户数、平均负载。第二行开始以及下面所有的行显示的信息是，当前登录的都有哪些用户，以及他们是从哪里登录的等。在这些信息中，最应该关注的应该是第一行中的“load average:”后面的三个数值。

&emsp;&emsp;第一个数值表示 1分钟内系统的平均负载值，第二个数值表示 5分钟内系统的平均负载值，第三个数值表示 15分钟内系统的平均负载值。这个值的意义是单位时间段内CPU活动进程数。这个值越大就说明服务器压力越大。一般情况下只要不超过服务器的CPU数量就没有关系。这个CPU数量指的不是物理CPU数量，而是逻辑CPU数量。可以在/proc/cpuinfo 文件下查看。



```
[root@localhost ~]# cat /proc/cpuinfo

processor       : 0

vendor_id       : GenuineIntel

cpu family      : 6

model           : 60

model name      : Intel(R) Xeon(R) CPU E3-1231 v3 @ 3.40GHz

stepping        : 3

microcode       : 25

cpu MHz         : 3392.170

cache size      : 8192 KB

physical id     : 0

siblings        : 2

core id         : 0

cpu cores       : 2

apicid          : 0

initial apicid  : 0

fpu             : yes

fpu_exception   : yes

cpuid level     : 13

wp              : yes

flags           : fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clf                             lush dts mmx fxsr sse sse2 ss ht syscall nx pdpe1gb rdtscp lm constant_tsc arch_perfmon pebs                              bts xtopology tsc_reliable nonstop_tsc aperfmperf unfair_spinlock pni pclmulqdq ssse3 fma cx1                             6 pcid sse4_1 sse4_2 x2apic movbe popcnt aes xsave avx f16c rdrand hypervisor lahf_lm ida ara                             t xsaveopt pln pts dts fsgsbase smep

bogomips        : 6784.34

clflush size    : 64

cache_alignment : 64

address sizes   : 40 bits physical, 48 bits virtual

power management:



processor       : 1

vendor_id       : GenuineIntel

cpu family      : 6

model           : 60

model name      : Intel(R) Xeon(R) CPU E3-1231 v3 @ 3.40GHz

stepping        : 3

microcode       : 25

cpu MHz         : 3392.170

cache size      : 8192 KB

physical id     : 0

siblings        : 2

core id         : 1

cpu cores       : 2

apicid          : 1

initial apicid  : 1

fpu             : yes

fpu_exception   : yes

cpuid level     : 13

wp              : yes

flags           : fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clf                             lush dts mmx fxsr sse sse2 ss ht syscall nx pdpe1gb rdtscp lm constant_tsc arch_perfmon pebs                              bts xtopology tsc_reliable nonstop_tsc aperfmperf unfair_spinlock pni pclmulqdq ssse3 fma cx1                             6 pcid sse4_1 sse4_2 x2apic movbe popcnt aes xsave avx f16c rdrand hypervisor lahf_lm ida ara                             t xsaveopt pln pts dts fsgsbase smep

bogomips        : 6784.34

clflush size    : 64

cache_alignment : 64

address sizes   : 40 bits physical, 48 bits virtual

power management:
```



&emsp;&emsp;/proc/cpuinfo 这个文件记录了 cpu的详细信息。目前市面上的服务器很多是2颗4核cpu，在系统看来，它就是8个cpu。查看这个文件时会显示8段类似的信息，而最后一段信息中processor:后面跟的是7。所以仅仅是查看有几个cpu的话，可以过滤一下：grep -c 'processor' /proc/cpuinfo 。那如何看有几颗物理cpu呢，需要查看关键字“physical id”，像我的显示为physical id:0，表示只有一个物理cpu，如果有第二个则会显示为physical id:1，依次下去。

&emsp;&emsp;另外，uptime命令同样也可以查看系统负载。就一行，和w的第一行一致。



```
[root@localhost ~]# uptime

 19:49:03 up 1 day, 12:35,  2 users,  load average: 0.00, 0.00, 0.00
```
