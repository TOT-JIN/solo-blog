title: CentOS7 安装 Hive 2.3.4 （远程 Metastore Server 模式）
date: '2019-06-10 17:07:34'
updated: '2019-06-10 17:07:34'
tags: [Hadoop, Hive, 大数据]
permalink: /articles/2019/06/10/1560157654923.html
---
分布式环境

> 继 [CentOS7 安装 HA 模式 HDFS 集群](https://17kblog.com/articles/2019/05/19/1558230815733.html)准备分布式环境，同时增加节点 node09 用于部署 metastore database。

| host | cpu | memory | ip | service |
| --- | --- | --- | --- | --- |
| node01 | 1c | 2G | 10.4.96.4 | hive client |
| node02 | 1c | 2G | 10.4.96.5 | thrift server |
| node03 | 1c | 1G | 10.4.96.6 |   |
| node04 | 1c | 1G | 10.4.96.7 |   |
| node05 | 1c | 1G | 10.4.96.8 |   |
| node06 | 1c | 1G | 10.4.96.9 |   |
| node07 | 1c | 1G | 10.4.96.10 |   |
| node08 | 1c | 1G | 10.4.96.11 |   |
| node09 | 1c | 1G | 10.4.96.12 | mysql |

## 1. 安装 MySQL 服务端和客户端

### 1.1 添加 mysql5.7 仓库

```bash
[root@node09 ~]# rpm -ivh https://dev.mysql.com/get/mysql57-community-release-el7-11.noarch.rpm
[root@node09 ~]# yum makecache fast
```

### 1.2 安装 MySQL

```bash
[root@node09 ~]# yum -y install mysql-community-server
```

### 1.3 启动

```bash
[root@node09 ~]# systemctl start mysqld
```

### 1.4 安全访问设置

* 查看默认 root 密码：

  ```bash
  [root@node09 ~]# cat /var/log/mysqld.log | grep -i 'temporary password'
  ```
* 更改 root 密码，移除匿名用户：

  ```bash
  [root@node09 ~]# mysql_secure_installation
  ```
* 移除 root 用户远程登录限制

  ```bash
  [root@node09 ~]# mysql -hlocalhost -pAz123456_ -e "UPDATE mysql.user SET host='10.4.96.%' WHERE user='root';FLUSH PRIVILEGES;"
  ```

## 2. 安装 Hive ([远程 Metastore](https://cwiki.apache.org/confluence/display/Hive/AdminManual+Metastore+Administration#AdminManualMetastoreAdministration-RemoteMetastoreServer) 模式)

> [https://archive.apache.org/dist/hive/hive-2.3.4/apache-hive-2.3.4-bin.tar.gz](https://archive.apache.org/dist/hive/hive-2.3.4/apache-hive-2.3.4-bin.tar.gz)
> [https://repo1.maven.org/maven2/mysql/mysql-connector-java/5.1.48/mysql-connector-java-5.1.48.jar](https://repo1.maven.org/maven2/mysql/mysql-connector-java/5.1.48/mysql-connector-java-5.1.48.jar)

### 2.1 安装应用

创建安装目录

```bash
[root@node01 ~]# for i in `seq 1 2`;do ssh root@node0$i "mkdir -p /opt/bigdata";done
```

下载解压到安装目录

```bash
[root@node01 ~]# for i in `seq 1 2`;do ssh root@node0$i "curl https://archive.apache.org/dist/hive/hive-2.3.4/apache-hive-2.3.4-bin.tar.gz | tar -C /opt/bigdata -zxf -";done
[root@node01 ~]# for i in `seq 1 2`;do ssh root@node0$i "mv /opt/bigdata/apache-hive-2.3.4-bin /opt/bigdata/hive-2.3.4";done
```

更改应用文件属主属组

```bash
[root@node01 ~]# for i in `seq 1 2`;do ssh root@node0$i "chown -R god:root /opt/bigdata/hive-2.3.4";done
```

配置环境变量

```bash
[root@node01 ~]# for i in `seq 1 2`;do ssh root@node0$i "sed -i '\$a\#Hive Environment variables\nexport HIVE_HOME=/opt/bigdata/hive-2.3.4\nexport PATH=\$PATH:\$HIVE_HOME/bin' /etc/profile";done
[root@node01 ~]# for i in `seq 1 2`;do ssh root@node0$i "source /etc/profile";done
```

### 2.2 配置应用

> node02 配置

配置 `hive-site.xml` 文件，特别注意jdbc URL中 *&* 的转义问题

```bash
[root@node02 conf]# pwd
/opt/bigdata/hive-2.3.4/conf
[root@node02 conf]# cp hive-default.xml.template hive-site.xml
```

```bash
[root@node02 conf]# vim hive-site.xml
...
<configuration>
    <property>
        <name>hive.metastore.warehouse.dir</name>
        <value>/user/hive_remote/warehouse</value>
    </property>

    <property>
        <name>javax.jdo.option.ConnectionURL</name>
        <value>jdbc:mysql://node09:3306/hive_remote?createDatabaseIfNotExist=true&amp;verifyServerCertificate=false&amp;useSSL=false</value>
    </property>

    <property>
        <name>javax.jdo.option.ConnectionDriverName</name>
        <value>com.mysql.jdbc.Driver</value>
    </property>

    <property>
        <name>javax.jdo.option.ConnectionUserName</name>
        <value>root</value>
    </property>

    <property>
        <name>javax.jdo.option.ConnectionPassword</name>
        <value>Az123456_</value>
    </property>
</configuration>
```

将 *mysql-connector-java-5.1.48.jar* 拷贝到 hive home 的 lib 目录下，以支持 hive 对 mysql 的连接操作。

```bash
[root@node02 lib]# pwd
/opt/bigdata/hive-2.3.4/lib
[root@node02 lib]# wget https://repo1.maven.org/maven2/mysql/mysql-connector-java/5.1.48/mysql-connector-java-5.1.48.jar
```

> node01 配置

配置 `hive-site.xml` 文件

```bash
[root@node01 conf]# pwd
/opt/bigdata/hive-2.3.4/conf
[root@node01 conf]# cp hive-default.xml.template hive-site.xml
```

```xml
[root@node01 conf]# vim hive-site.xml
...
<configuration>
    <property>
        <name>hive.metastore.warehouse.dir</name>
        <value>/user/hive_remote/warehouse</value>
    </property>

    <property>
        <name>hive.metastore.uris</name>
        <value>thrift://node02:9083</value>
    </property>
</configuration>
```

[Hive 2.1](https://cwiki.apache.org/confluence/display/Hive/GettingStarted#GettingStarted-RunningHiveServer2andBeeline.1) 之后版本要执行的初始命令

```bash
[root@node02 ~]# schematool -dbType mysql -initSchema
```

```bash
[root@node09 ~]# mysql -h10.4.96.12 -pAz123456_ -e "show databases;"
mysql: [Warning] Using a password on the command line interface can be insecure.
+--------------------+
| Database           |
+--------------------+
| information_schema |
| hive_remote               |
| mysql              |
| performance_schema |
| sys                |
+--------------------+
```

### 2.3 启动 hive server

> node02 启动 Thrift server

```bash
[root@node02 ~]# screen -S thrift
[root@node02 ~]# hive --service metastore
2020-05-19 16:57:37: Starting Hive Metastore Server
SLF4J: Class path contains multiple SLF4J bindings.
SLF4J: Found binding in [jar:file:/opt/bigdata/hive-2.3.4/lib/log4j-slf4j-impl-2.6.2.jar!/org/slf4j/impl/StaticLoggerBinder.class]
SLF4J: Found binding in [jar:file:/opt/bigdata/hadoop-2.6.5/share/hadoop/common/lib/slf4j-log4j12-1.7.5.jar!/org/slf4j/impl/StaticLoggerBinder.class]
SLF4J: See http://www.slf4j.org/codes.html#multiple_bindings for an explanation.
SLF4J: Actual binding is of type [org.apache.logging.slf4j.Log4jLoggerFactory]

```

> 此时窗口阻塞住了，按 <Ctrl + a + d> 组合键跳出 screen

### 2.4 测试 hive

> 注意切换到 god 用户了，因为 hdfs 是用 god 用户启动的，参照前面的文章。   真烦，默认用 root 不就得了~
> Hive-on-MR 在 Hive 2 中已弃用，在以后的版本中可能不可用。 考虑使用其他执行引擎（例如 spark，tez）或使用 Hive 1.X 版本。

```bash
[god@node01 ~]# hive
...
Logging initialized using configuration in jar:file:/opt/bigdata/hive-2.3.4/lib/hive-common-2.3.4.jar!/hive-log4j2.properties Async: true
Hive-on-MR is deprecated in Hive 2 and may not be available in the future versions. Consider using a different execution engine (i.e. spark, tez) or using Hive 1.X releases.
hive>
```

## 3. 简单操作

* 创建表

```bash
hive> create EXTERNAL TABLE w_a
    > (
    > id INT,
    > age INT,
    > sex INT
    > )
    > ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    > LINES TERMINATED BY '\n';
OK
Time taken: 1.33 seconds
hive> show tables;
OK
w_a
Time taken: 0.082 seconds, Fetched: 1 row(s)
```

> 此时 hive 会在 hdfs 中创建对应目录
>
> ```
> [god@node01 ~]$ hadoop fs -ls /user/hive_remote/warehouse
> Found 1 items
> drwxr-xr-x   - god supergroup          0 2020-05-18 18:49 /user/hive/warehouse/w_a
> ```
