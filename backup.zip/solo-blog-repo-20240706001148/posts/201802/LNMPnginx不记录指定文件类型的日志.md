title: LNMP--nginx 不记录指定文件类型的日志
date: '2018-02-10 21:44:43'
updated: '2018-02-10 21:44:43'
tags: [lnmp, nginx, 日志]
permalink: /articles/2018/02/10/1518270283733.html
---
# LNMP--nginx 不记录指定文件类型的日志
&emsp;&emsp;先来看看nginx日志相关的配置。

&emsp;（1）日志格式

&emsp;&emsp;在 nginx.conf 中定义日志格式，配置如下：

```
    log_format combined_realip '$remote_addr $http_x_forwarded_for [$time_local]'

    '$host "$request_uri" $status'

    '"$http_referer" "$http_user_agent"';
```


         

&emsp;&emsp;下面的日志格式，会记录代理的ip和真实客户端真实ip，建议用这个配置。

```
log_format main l '$proxy_add_x_forwarded_for - $remote_user [$time_local]'

'"$request" $status $body_bytes_sent'

'"$http_referer" "$http_user_agent"';
```


&emsp;（2）错误日志 error_log 日志级别

&emsp;&emsp;在 502 一节已经提及，error_log 级别分为 debug,info,notice,warn,error,crit 默认为 crit，该级别在日志名后边定义格式如下：

```
error_log /usr/local/nginx/logs/nginx_error.log crit;
```


&emsp;&emsp;crit 记录的日志最少，而 debug 记录的日志最多。如果nginx遇到一些问题，比如502比较频繁出现，但是看默认的 error_log 并没有看到有意义的信息，那么就可以调一下错误日志的级别，当调成 error 级别时，错误日志记录的内容会更加丰富。

&emsp;（3）某些类型的文件不记录日志

&emsp;&emsp;这个就要比apache简单多了。配置如下：

```
location ~ .*\.(gif|jpg|jpeg|png|bmp|swf|js|css)$

   {

        access_log off;

   }
```
