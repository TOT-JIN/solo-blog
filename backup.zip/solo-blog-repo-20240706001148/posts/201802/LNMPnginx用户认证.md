title: LNMP--nginx用户认证
date: '2018-02-01 12:24:13'
updated: '2018-02-01 12:24:13'
tags: [lnmp, nginx, 用户认证]
permalink: /articles/2018/02/01/1517459053733.html
---
# LNMP--nginx用户认证
&emsp;&emsp;在LNMP架构下也能做用户认证。首先需要安装apache，可以使用 yum install httpd 安装。然后生成密码文件。



```
[root@localhost ~]# htpasswd -c -m /usr/local/nginx/conf/htpasswd test

New password:

Re-type new password:

Adding password for user test
```


&emsp;&emsp;这样就添加了 test 用户，第一次添加时需要加 -c 参数，第二次添加时不需要 -c 参数。在nginx的虚拟主机配置文件中添加：



```
    location /uc_server/ {

        auth_basic  "Auth";

        auth_basic_user_file  /usr/local/nginx/conf/htpasswd;

    }
```


&emsp;&emsp;这样就把请求 /uc_server/ 的访问给限制了，只有输入用户名和密码才可以继续访问，基本上和apache的配置类似。

&emsp;&emsp;检查和重新加载配置

```
[root@localhost ~]# /usr/local/nginx/sbin/nginx -t

nginx: the configuration file /usr/local/nginx/conf/nginx.conf syntax is ok

nginx: configuration file /usr/local/nginx/conf/nginx.conf test is successful

[root@localhost ~]# /usr/local/nginx/sbin/nginx -s reload
```


&emsp;&emsp;浏览器访问：

![bf81947f9a3a71970c687a87ea1369b017.png](https://b3logfile.com/file/2020/06/bf81947f9a3a71970c687a87ea1369b017-1dc1ca40.png)

