title: ps 查看进程
date: '2016-08-11 22:45:14'
updated: '2016-08-11 22:45:14'
tags: [ps, cli]
permalink: /articles/2016/08/11/1470926714345.html
---
# ps 查看进程
&emsp;&emsp;查看系统进程命令：ps aux
![bf81947f9a3a71970c687a87ea1369b05.png](https://b3logfile.com/file/2020/06/bf81947f9a3a71970c687a87ea1369b05-ff66a8ba.png)



&emsp;&emsp;命令： ps -elf ，和 ps aux 大同小异。

&emsp;&emsp;几个重要参数的意义：

&emsp;&emsp;&emsp;PID：进程的id，这个id很有用，在linux中内核管理进程就要靠pid来识别和管理某一个进程，比如我想终止某个进程，则用“kill 进程的pid “，但有时不能杀掉，则需要加一个 -9 选项来杀死进程  “kill -9 进程pid”。

&emsp;&emsp;&emsp;STAT：表示进程的状态，进程状态分为一下几种：

&emsp;&emsp;&emsp;D 不能中断的进程（通常为IO）

&emsp;&emsp;&emsp;R 正在运行中的进程

&emsp;&emsp;&emsp;S 已经中断的进程，通常情况下，系统中大部分进程都是这个状态

&emsp;&emsp;&emsp;T 已经停止或者暂停的进程，如果我们正在运行一个命令，比如说sleep 10如果我们按一下 Ctrl+z 让他暂停，那么我们用ps查看就会显示T这个状态

&emsp;&emsp;&emsp;W 这个好像是，从内核 2.6xx 以后，表示为没有足够的内存页分配

&emsp;&emsp;&emsp;X 已经死掉的进程（貌似从来不会出现）

&emsp;&emsp;&emsp;Z 僵尸进程，杀不掉，打不死的垃圾进程，占系统一小点资源，如果太多，就有问题了，一般不会出现。

&emsp;&emsp;&emsp;< 高优先级进程

&emsp;&emsp;&emsp;N 低优先级进程

&emsp;&emsp;&emsp;L 在内存中被锁了内存分页

&emsp;&emsp;&emsp;s 主进程

&emsp;&emsp;&emsp;l 多线程进程

&emsp;&emsp;&emsp;+ 代表在前台运行的进程

   

&emsp;&emsp;&emsp;连同管道符使用的ps



```
 [root@localhost ~]# ps aux |grep -c mingetty

6

[root@localhost ~]# ps aux |grep mingetty

root      1414  0.0  0.0   4064   588 tty2     Ss+  May14   0:00 /sbin/mingetty /dev/tty2

root      1416  0.0  0.0   4064   592 tty3     Ss+  May14   0:00 /sbin/mingetty /dev/tty3

root      1418  0.0  0.0   4064   588 tty4     Ss+  May14   0:00 /sbin/mingetty /dev/tty4

root      1420  0.0  0.0   4064   588 tty5     Ss+  May14   0:00 /sbin/mingetty /dev/tty5

root      1422  0.0  0.0   4064   592 tty6     Ss+  May14   0:00 /sbin/mingetty /dev/tty6

root     51845  0.0  0.0 103316   900 pts/0    S+   01:46   0:00 grep mingetty
```



&emsp;&emsp;可见 6 并不准确，因为使用grep命令时，grep命令本身也算作一个，所以应该是 5 个。
