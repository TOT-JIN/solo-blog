title: docker-iptables安全防护
date: '2017-11-26 12:24:23'
updated: '2017-11-26 12:24:23'
tags: [docker, iptables]
permalink: /articles/2017/11/26/1511670263856.html
---
# docker-iptables安全防护
```
$ cat /usr/local/sbin/iptables.sh
#!/bin/bash
ipt="/sbin/iptables"
$ipt -F DOCKER-USER
$ipt -A DOCKER-USER -j RETURN
$ipt -I DOCKER-USER -p tcp --dport 3306 -j DROP
$ipt -I DOCKER-USER -p tcp --dport 11300 -j DROP
$ipt -I DOCKER-USER -s 172.17.42.0/24 -p tcp --dport 11300 -j ACCEPT
$ipt -I DOCKER-USER -s 180.150.189.89 -p tcp --dport 11300 -j ACCEPT
$ipt -I DOCKER-USER -s 106.75.27.85 -p tcp --dport 11300 -j ACCEPT
```
