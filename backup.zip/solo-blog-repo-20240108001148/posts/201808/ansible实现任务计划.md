title: ansible 实现任务计划
date: '2018-08-04 12:21:14'
updated: '2018-08-04 12:21:14'
tags: [ansible, 自动化运维]
permalink: /articles/2018/08/04/1533356474832.html
---
# ansible 实现任务计划
&emsp;需用模块 cron

&emsp;创建一个任务计划

```
[root@server ~]# ansible client.test.com -m cron -a "name=test_cron job='/bin/bash /usr/local/sbin/1.sh' weekday=6"

client.test.com | SUCCESS => {

    "changed": true,

    "envs": [],

    "jobs": [

        "test_cron"

    ]

}
```


&emsp;查看一下

```
[root@server ~]# ansible client.test.com -m shell -a "crontab -l"

client.test.com | SUCCESS | rc=0 >>

*/10 * * * * ntpdate s1a.time.edu.cn >/dev/null 2>&1

#Ansible: test_cron

* * * * 6 /bin/bash /usr/local/sbin/1.sh
```


&emsp;删除这个test_cron

```
[root@server ~]# ansible client.test.com -m cron -a "name=test_cron state=absent"

client.test.com | SUCCESS => {

    "changed": true,

    "envs": [],

    "jobs": []

}

[root@server ~]# ansible client.test.com -m shell -a "crontab -l"               client.test.com | SUCCESS | rc=0 >>

*/10 * * * * ntpdate s1a.time.edu.cn >/dev/null 2>&1
```


&emsp;任务计划列表里已经没有了test_cron的job



&emsp;其他的时间表示：分钟minute 小时hour 日期day 月份month

```
[root@server ~]# ansible client.test.com -m cron -a "name=test_cron job='/bin/bash /usr/local/sbin/1.sh' day='1-10' weekday=6"

[root@server ~]# ansible client.test.com -m shell -a "crontab -l"               client.test.com | SUCCESS | rc=0 >>

*/10 * * * * ntpdate s1a.time.edu.cn >/dev/null 2>&1

#Ansible: test_cron

* * 1-10 * 6 /bin/bash /usr/local/sbin/1.sh




[root@server ~]# ansible client.test.com -m cron -a "name=test_cron job='/bin/bash /usr/local/sbin/1.sh' day='1,5,10' weekday=6"

[root@server ~]# ansible client.test.com -m shell -a "crontab -l"               client.test.com | SUCCESS | rc=0 >>

*/10 * * * * ntpdate s1a.time.edu.cn >/dev/null 2>&1

#Ansible: test_cron

* * 1,5,10 * 6 /bin/bash /usr/local/sbin/1.sh
```
