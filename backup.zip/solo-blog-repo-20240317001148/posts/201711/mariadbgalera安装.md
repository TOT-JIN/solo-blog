title: mariadb-galera安装
date: '2017-11-20 11:45:24'
updated: '2017-11-20 11:45:24'
tags: [mariadb, galera]
permalink: /articles/2017/11/20/1511149524856.html
---
# mariadb-galera安装

#### 实验环境

操作系统：ubuntu16.04
主机两台： 
        ubuntu190       192.168.1.190
        ubuntu170       192.168.1.170
                       
#### 添加源

```
http://downloads.mariadb.org/mariadb/repositories/
```
```
sudo apt-key adv --recv-keys --keyserver hkp://keyserver.ubuntu.com:80 0xF1656F24C74CD1D8
sudo add-apt-repository 'deb [arch=amd64,i386,ppc64el] http://nyc2.mirrors.digitalocean.com/mariadb/repo/10.1/ubuntu xenial main'
sudo apt-get update
```

#### 安装

```
sudo apt-get install mariadb-server rsync
```

此时galera-3默认被装好：
```
genee@190:~$ sudo dpkg -L galera-3
/.
/usr
/usr/lib
/usr/lib/galera
/usr/lib/galera/libgalera_smm.so
/usr/share
/usr/share/doc
/usr/share/doc/galera-3
/usr/share/doc/galera-3/AUTHORS
/usr/share/doc/galera-3/README.gz
/usr/share/doc/galera-3/changelog.Debian.gz
/usr/share/doc/galera-3/copyright
/usr/lib/libgalera_smm.so
```
#### 初始化mariadb

```
sudo systemctl start mysql
sudo mysql_secure_installation
```
创建节点用户

```
mysql -uroot -p

MariaDB [(none)]> GRANT ALL PRIVILEGES ON *.* TO 'cluster'@'%' IDENTIFIED BY 'password' WITH GRANT OPTION;
MariaDB [(none)]> FLUSH PRIVILEGES;
MariaDB [(none)]> exit
```

停止mariadb服务 ```sudo systemctl stop mysql```

#### DB1设置mariadb galera cluster
##### 配置第一个节点

```
sudo vim /etc/mysql/conf.d/galera.cnf

[mysqld]
binlog_format=ROW
default-storage-engine=innodb
innodb_autoinc_lock_mode=2
bind-address=0.0.0.0

# Galera Provider Configuration
wsrep_on=ON
wsrep_provider=/usr/lib/galera/libgalera_smm.so

# Galera Cluster Configuration
wsrep_cluster_name="cluster_group"
wsrep_cluster_address="gcomm://192.168.1.190,192.168.1.170"

# Galera Synchronization Configuration
wsrep_sst_method=rsync
wsrep_sst_auth=cluster:password

# Galera Node Configuration
wsrep_node_address="192.168.1.190"
wsrep_node_name="ubuntu190"

```

#### 启动第一个节点

```sudo galera_new_cluster```

执行成功后，可以通过以下命令查看：

```
mysql -uroot -p -e "SHOW STATUS LIKE 'wsrep_cluster_size'"
```
```
+--------------------+-------+
| Variable_name      | Value |
+--------------------+-------+
| wsrep_cluster_size | 1     |
+--------------------+-------+
```

#### 配置及打开第二个节点
初始化，创建用户操作同第一个节点，配置galera需要改一些配置

```
[mysqld]
binlog_format=ROW
default-storage-engine=innodb
innodb_autoinc_lock_mode=2
bind-address=0.0.0.0

# Galera Provider Configuration
wsrep_on=ON
wsrep_provider=/usr/lib/galera/libgalera_smm.so

# Galera Cluster Configuration
wsrep_cluster_name="cluster_group"
wsrep_cluster_address="gcomm://192.168.1.190,192.168.1.170"

# Galera Synchronization Configuration
wsrep_sst_method=rsync
wsrep_sst_auth=cluster:Genee83719730

# Galera Node Configuration
wsrep_node_address="192.168.1.170"
wsrep_node_name="ubuntu170"

```
启动mysql:

```sudo systemctl start mysql```

```
mysql -u root -p -e "SHOW STATUS LIKE 'wsrep_cluster_size'"

+--------------------+-------+
| Variable_name      | Value |
+--------------------+-------+
| wsrep_cluster_size | 2     |
+--------------------+-------+
```

> 如需增加节点，在galera.cnf中增加相应配置，并顺序启动就可以了

#### 配置debian维护用户
目前，Ubuntu和Debian的MariaDB服务器进行日常维护，例如作为特殊维护用户的日志循环。 当我们安装MariaDB的，随机生成该用户的凭据，存储在/etc/mysql/debian.cnf ，并插入到MariaDB的的mysql数据库。

当我们提出了我们的群集，从第一节点的密码被复制到其他节点，所以在值debian.cnf不再匹配在数据库中的口令。 这意味着使用维护帐户的任何东西将尝试使用配置文件中的密码连接到数据库，并且除第一个节点之外的所有节点都将失败。

要纠正这一点，我们将我们的第一个节点的debian.cnf复制到其余节点。

完成之后，可以测试维护帐户能够从当地提供的密码连接：
```mysql -udebian-sys-maint -p```
如果不可以连接，验证文件中的密码与第一个节点也相同，替换如下：

```
update mysql.user set password=PASSWORD('password_from_debian.cnf') where User='debian-sys-maint';
```

#### 创建生产环境用户

```
mysql -uroot -p

MariaDB [(none)]> GRANT ALL PRIVILEGES ON *.* TO 'user'@'%' IDENTIFIED BY 'password' WITH GRANT OPTION;
MariaDB [(none)]> FLUSH PRIVILEGES;
MariaDB [(none)]> SELECT User, Host, Password FROM mysql.user;
MariaDB [(none)]> quit
```

> 每个节点都要创建，之后可测试是否复制成功



> lims代码更改默认引擎配置，/var/lib/lims2/application/config/lab.php 、 database.php
