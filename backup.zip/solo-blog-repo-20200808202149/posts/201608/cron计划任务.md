title: cron计划任务
date: '2016-08-15 22:25:42'
updated: '2016-08-15 22:25:42'
tags: [cron]
permalink: /articles/2016/08/15/1471271142345.html
---
# cron计划任务
&emsp;&emsp;大部分系统管理工作都是通过定期自动执行某一个脚本来完成的，这可以用linux的 cron 功能来实现。



&emsp;&emsp;**命令 crontab**

&emsp;&emsp;linux 任务计划功能的操作都是通过crontab 这个命令完成的。其中常用的选项有:

    

&emsp;&emsp;&emsp;-u：指定某个用户，不加 -u 选项则为当前用户

&emsp;&emsp;&emsp;-e：制定计划任务

&emsp;&emsp;&emsp;-l：列出计划任务

&emsp;&emsp;&emsp;-r：删除计划任务

     

&emsp;&emsp;下面建立一个计划任务：



```
[root@localhost ~]# crontab -e

no crontab for root - using an empty one



01 10 05 06 3 echo "ok">/root/cron.log
```


&emsp;&emsp;使用 crontab -e 来进行编写任务计划，实际上是使用vim工具打开了 crontab 的配置文件，在其中写入的 ‘01 10 05 06 3 echo "ok">/root/cron.log ’中每个字段的数字从左到右一次表示：分、时、日、月、周，命令行。这个例子的含义是：在6月5日（这一天必须是星期3）的10点01分执行命令 echo "ok">/root/cron.log 。

&emsp;&emsp;crontab -e 实际上是打开了“/var/spool/cron/username”（root用户打开的是 /var/spool/cron/root）这个文件。使用的是 vim 编辑器，所以保存的话就是在命令模式下输入 ：wq 即可。但是，不能直接去编辑那个文件，可能会出错，一定要使用 crontab -e 来编辑。

&emsp;&emsp;查看已经设定的计划任务使用 crontab -l 命令：



```
[root@localhost ~]# crontab -l

01 10 05 06 3 echo "ok">/root/cron.log
```


&emsp;&emsp;删除计划任务要用 crontab -r



```
[root@localhost ~]# crontab -r

[root@localhost ~]# crontab -l

no crontab for root
```


      

&emsp;&emsp;**例子：**

1.每天凌晨1点20分清除  /var/log/slow.log 这个文件



`20 1 * * *  echo "" > /var/log/slow.log`


2.每周日 3 点执行 “/bin/sh  /usr/local/sbin/backup.sh”



`0 3 * * 0  /bin/sh  /usr/local/sbin/backup.sh`


3.每月14号4点10分执行 “/bin/sh  /usr/local/sbin/backup_month.sh”



`10 4 14 * * /bin/sh  /usr/local/sbin/backup_month.sh`


4.每隔8小时执行 “ntpdate time.windows.com”



`0 */8 * * * ntpdate time.windows.com`


5.每天的1点，12点，18点执行 “/bin/sh  /usr/local/sbin/test.sh”



`0 1,12,18 * * *   /bin/sh  /usr/local/sbin/test.sh`


6.每天的9点到18点执行 “/bin/sh  /usr/local/sbin/test2.sh”



`0 9-18 * * * /bin/sh  /usr/local/sbin/test2.sh`


       

&emsp;&emsp;设置好了所有的计划任务后，需要查看一下crond服务是否启动：



```
[root@localhost ~]# service crond status

crond (pid  1414) 正在运行...


        停止和启动：



[root@localhost ~]# service crond stop

停止 crond：                                               [确定]

[root@localhost ~]# service crond status

crond 已停

[root@localhost ~]# service crond start

正在启动 crond：                                           [确定]
```
