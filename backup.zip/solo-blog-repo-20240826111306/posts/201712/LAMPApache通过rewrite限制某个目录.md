title: LAMP--Apache 通过 rewrite 限制某个目录
date: '2017-12-07 21:34:19'
updated: '2017-12-07 21:34:19'
tags: [lamp, httpd, rewrite]
permalink: /articles/2017/12/07/1512653659673.html
---
# LAMP--Apache 通过 rewrite 限制某个目录
限制网站根目录下的某个子目录，除了deny和allow外，还可以用 rewrite 实现，配置如下：

          <IfModule mod_rewrite.c>

             RewriteEngine on

             RewriteCond %{REQUEST_URI} ^.*/tmp/* [NC]

             RewriteRule .* - [F]

          </IfModule>

这段配置，会把只要是包含 /tmp/ 字样的请求都限制了，比如下面的请求，在这里假设网站域名为 bbs.test.com 。

             bbs.test.com/a/tmp/123.html

             bbs.test.com/ab/tmp/123.html

             bbs.test.com/c/b/a/tmp/123.html
