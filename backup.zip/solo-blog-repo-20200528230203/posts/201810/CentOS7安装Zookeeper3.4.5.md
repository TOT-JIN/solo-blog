title: CentOS7 安装 Zookeeper-3.4.5
date: '2018-10-05 09:53:35'
updated: '2018-10-05 09:53:35'
tags: [Hadoop, Zookeeper, 大数据]
permalink: /articles/2018/10/05/1538704415733.html
---
## 0. 准备安装环境

> 继 [CentOS7 安装 hadoop-1.2.1](https://17kblog.com/articles/2018/10/03/1538531615733.html) 准备环境

## 1. 安装 zookeeper

以下步骤除特殊说明，其余皆在三个节点上执行

### 1.1 安装到指定目录

下载 zookeeper 安装包到/usr/loca/src 目录下

> [https://archive.apache.org/dist/zookeeper/zookeeper-3.4.5/zookeeper-3.4.5.tar.gz](https://archive.apache.org/dist/zookeeper/zookeeper-3.4.5/zookeeper-3.4.5.tar.gz)

```bash
 [root@master /usr/local/src]# ls
zookeeper-3.4.5.tar.gz
```

解压到/usr/local 目录

```bash
[root@master /usr/local]# tar zxf src/zookeeper-3.4.5.tar.gz 
[root@master /usr/local]# cd zookeeper-3.4.5/
[root@master /usr/local/zookeeper-3.4.5]# 
```

### 1.2 配置 zookeeper

#### 创建 **myid** 文件

master 节点：

```bash
[root@master /usr/local/zookeeper-3.4.5]# echo "0" > myid
[root@master /usr/local/zookeeper-3.4.5]# cat myid 
0
```

slave1 节点：

```bash
[root@slave1 /usr/local/zookeeper-3.4.5]# echo "1" > myid
[root@slave1 /usr/local/zookeeper-3.4.5]# cat myid 
1
```

slave2 节点：

```bash
[root@slave2 /usr/local/zookeeper-3.4.5]# echo "2" > myid
[root@slave2 /usr/local/zookeeper-3.4.5]# cat myid 
2
```

## 拷贝生成 zoo.cfg

```bash
[root@master /usr/local/zookeeper-3.4.5/conf]# cp zoo_sample.cfg zoo.cfg
```

配置 datadir 和 server

```bash
[root@master /usr/local/zookeeper-3.4.5/conf]# cat zoo.cfg 
# The number of milliseconds of each tick
tickTime=2000
# The number of ticks that the initial 
# synchronization phase can take
initLimit=10
# The number of ticks that can pass between 
# sending a request and getting an acknowledgement
syncLimit=5
# the directory where the snapshot is stored.
# do not use /tmp for storage, /tmp here is just 
# example sakes.
# dataDir=/tmp/zookeeper
dataDir=/usr/local/zookeeper-3.4.5
# the port at which the clients will connect
clientPort=2181
#
# Be sure to read the maintenance section of the 
# administrator guide before turning on autopurge.
#
# http://zookeeper.apache.org/doc/current/zookeeperAdmin.html#sc_maintenance
#
# The number of snapshots to retain in dataDir
#autopurge.snapRetainCount=3
# Purge task interval in hours
# Set to "0" to disable auto purge feature
#autopurge.purgeInterval=1

server.0=master:8880:7770
server.1=slave1:8881:7771
server.2=slave2:8882:7772
```

## 2. 启动 zookeeper

每个节点执行启动命令

```bash
[root@master /usr/local/zookeeper-3.4.5/bin]# ./zkServer.sh start
```

##3. 检查状态

```bash
[root@master /usr/local/zookeeper-3.4.5/bin]# ./zkServer.sh status
JMX enabled by default
Using config: /usr/local/zookeeper-3.4.5/bin/../conf/zoo.cfg
Mode: follower
```

```bash
[root@slave1 /usr/local/zookeeper-3.4.5/bin]# ./zkServer.sh status
JMX enabled by default
Using config: /usr/local/zookeeper-3.4.5/bin/../conf/zoo.cfg
Mode: leader
```

```bash
[root@slave2 /usr/local/zookeeper-3.4.5/bin]# ./zkServer.sh status
JMX enabled by default
Using config: /usr/local/zookeeper-3.4.5/bin/../conf/zoo.cfg
Mode: follower
```
