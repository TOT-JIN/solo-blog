title: pureftp 部署和优化
date: '2016-09-11 21:15:14'
updated: '2016-09-11 21:15:14'
tags: [pureftp, ftp]
permalink: /articles/2016/09/11/1473599714856.html
---
# pureftp 部署和优化
&emsp;&emsp;FTP是File Transfer Protocol（文件传输协议）的简称，用于Internet上的控制文件的双向传输。用户可以通过它把自己的PC机与世界各地所有运行FTP协议的服务器相连，访问服务器上的大量程序和信息。FTP的主要作用是让用户连接上一个远程计算机（这些计算机上运行着FTP服务器程序）查看远程计算机有哪些文件，然后把文件从远程计算机上拷到本地计算机，或把本地计算机的文件送到远程计算机去。

     

## 安装 pure-ftpd

### （1）下载软件

&emsp;&emsp;Pure-ftpd 的官网是 [http://www.pureftpd.org/project/pure-ftpd](http://www.pureftpd.org/project/pure-ftpd)

```
[root@133 ~]# cd /usr/local/src

[root@133 src]# wget ftp://ftp.pureftpd.org/pub/pure-ftpd/releases/pure-ftpd-1.0.42.tar.bz2
```


### （2）安装 pure-ftpd

```
[root@133 src]# ls

pure-ftpd-1.0.42.tar.bz2

[root@133 src]# tar jxf pure-ftpd-1.0.42.tar.bz2

[root@133 src]# ls

pure-ftpd-1.0.42  pure-ftpd-1.0.42.tar.bz2

[root@133 src]# cd pure-ftpd-1.0.42

[root@133 pure-ftpd-1.0.42]# ./configure \

--prefix=/usr/local/pureftpd \

--without-inetd \

--with-altlog \

--with-puredb \

--with-throttling \

--with-peruserlimits \

--with-tls

[root@133 pure-ftpd-1.0.42]# make

[root@133 pure-ftpd-1.0.42]# echo $?

0

[root@133 pure-ftpd-1.0.42]# make install

[root@133 pure-ftpd-1.0.42]# echo $?

0
```


### （3）配置 pure-ftpd

&emsp;&emsp;Pure-ftpd 编译安装很快就完成了，而且极少有出现错误的时候，下面配置它：

```
[root@133 pure-ftpd-1.0.42]# cd configuration-file/

[root@133 configuration-file]# mkdir -p /usr/local/pureftpd/etc/

[root@133 configuration-file]# cp pure-ftpd.conf /usr/local/pureftpd/etc/pure-ftpd.conf

[root@133 configuration-file]# cp pure-config.pl /usr/local/pureftpd/sbin/pure-config.pl

[root@133 configuration-file]# chmod 755 /usr/local/pureftpd/sbin/pure-config.pl
```

&emsp;&emsp;在启动 pure-ftpd 之前需要先修改配置文件，配置文件为 /usr/local/pureftpd/etc/pure-ftpd.conf，直接清空，加入如下内容：

```
ChrootEveryone              yes

BrokenClientsCompatibility  no

MaxClientsNumber            50

Daemonize                   yes

MaxClientsPerIP             8

VerboseLog                  no

DisplayDotFiles             yes

AnonymousOnly               no

NoAnonymous                 no

SyslogFacility              ftp

DontResolve                 yes

MaxIdleTime                 15

PureDB                        /usr/local/pureftpd/etc/pureftpd.pdb

LimitRecursion              3136 8

AnonymousCanCreateDirs      no

MaxLoad                     4

AntiWarez                   yes

Umask                       133:022

MinUID                      100

AllowUserFXP                no

AllowAnonymousFXP           no

ProhibitDotFilesWrite       no

ProhibitDotFilesRead        no

AutoRename                  no

AnonymousCantUpload         no

PIDFile                     /usr/local/pureftpd/var/run/pure-ftpd.pid

MaxDiskUsage               99

CustomerProof              yes
```


### （4）启动 pure-ftpd

```
[root@133 configuration-file]# /usr/local/pureftpd/sbin/pure-config.pl /usr/local/pureftpd/etc/pure-ftpd.conf

Running: /usr/local/pureftpd/sbin/pure-ftpd -A -c50 -B -C8 -D -fftp -H -I15 -lpuredb:/usr/local/pureftpd/etc/pureftpd.pdb -L3136:8 -m4 -s -U133:022 -u100 -g/usr/local/pureftpd/var/run/pure-ftpd.pid -k99 -Z
```

&emsp;&emsp;如果启动成功了的话，会显示如上以Running为开头的信息，否则就是出错了。pure-ftpd重启就比较麻烦了，因为没有启动脚本，可以借用系统kill工具杀死pure-ftpd，再启动。

```
[root@133 configuration-file]# killall pure-ftpd

[root@133 configuration-file]# /usr/local/pureftpd/sbin/pure-config.pl /usr/local/pureftpd/etc/pure-ftpd.conf

Running: /usr/local/pureftpd/sbin/pure-ftpd -A -c50 -B -C8 -D -fftp -H -I15 -lpuredb:/usr/local/pureftpd/etc/pureftpd.pdb -L3136:8 -m4 -s -U133:022 -u100 -g/usr/local/pureftpd/var/run/pure-ftpd.pid -k99 -Z

```

### （5）建立账号

&emsp;&emsp;Pure-ftpd使用的账号并非 Linux 系统账号，而是虚拟账号。因为这样做比较安全。

```
[root@133 ~]# mkdir -p /data/www/

[root@133 ~]# useradd www

[root@133 ~]# chown -R www:www /data/www/

[root@133 ~]# /usr/local/pureftpd/bin/pure-pw useradd ftp_user1 -uwww -d /data/www/

Password:

Enter it again:
```


&emsp;&emsp;其中，-u将虚拟用户 ftp_user1 与系统用户 www 关联在一起，也就是说使用 ftp_user1 账号登陆 ftp 后，会以 www 的身份来读取文件或下载文件。 -d 后边的目录为 ftp_user1 账户的家目录，这样可以使 ftp_user1 只能访问其家目录 /data/www/。到这里还未完成，还有最关键的一步，就是创建用户信息数据库文件：

```
[root@133 ~]# /usr/local/pureftpd/bin/pure-pw mkdb
```


&emsp;&emsp;pure-pw 还可以列出当前的ftp账号，当然也可以删除某个账号，再创建一个账号：

```
[root@133 ~]# /usr/local/pureftpd/bin/pure-pw useradd ftp_user2 -uwww -d /tmp

Password:

Enter it again:

[root@133 ~]# /usr/local/pureftpd/bin/pure-pw mkdb
```


&emsp;&emsp;列出当前账号：

```
[root@133 ~]# /usr/local/pureftpd/bin/pure-pw list

ftp_user1           /data/www/./

ftp_user2           /tmp/./
```

&emsp;&emsp;删除账号：

```
[root@133 ~]# /usr/local/pureftpd/bin/pure-pw userdel ftp_user2

[root@133 ~]# /usr/local/pureftpd/bin/pure-pw list

ftp_user1           /data/www/./
```


### （6）测试 pure-ftpd

&emsp;&emsp;为了体现真实性，再开一个虚拟机来测试，需要在客户端安装lftp

&emsp;&emsp;服务端创建文件

```
[root@133 ~]# touch /data/www/test.txt
```


&emsp;&emsp;客户端：

```
[root@128 ~]# yum install -y lftp

[root@128 ~]# lftp ftp_user1@192.168.56.133

口令:

lftp ftp_user1@192.168.56.133:/> lcd /usr/local/src           //lcd 命令用于切换本地目录，此处等于是设置下载文件保存地址

lcd 成功, 本地目录=/usr/local/src

lftp ftp_user1@192.168.56.133:/> ls

drwxr-xr-x    2 500        www              4096 Jun 26 09:31 .

drwxr-xr-x    2 500        www              4096 Jun 26 09:31 ..

-rw-r--r--    1 0          0                   0 Jun 26 09:31 test.txt

lftp ftp_user1@192.168.56.133:/> get test.txt

lftp ftp_user1@192.168.56.133:/> quit

[root@128 ~]# ls /usr/local/src/

test.txt
```

&emsp;&emsp;其实最好的测试方法就是在windows机器里按个ftp客户端软件，然后直接测试使用情况。例：filezilla-client：

![bf81947f9a3a71970c687a87ea1369b011.png](https://b3logfile.com/file/2020/06/bf81947f9a3a71970c687a87ea1369b011-bad24b64.png)


    

&emsp;&emsp;对于客户端来说，它的远程站点的根目录就是 服务端的 /data/www/
