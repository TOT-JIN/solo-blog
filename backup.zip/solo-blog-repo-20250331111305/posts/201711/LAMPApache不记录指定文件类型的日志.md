title: LAMP--Apache 不记录指定文件类型的日志
date: '2017-11-04 12:02:58'
updated: '2017-11-04 12:02:58'
tags: [lamp, httpd, 日志]
permalink: /articles/2017/11/04/1509768178673.html
---
# LAMP--Apache 不记录指定文件类型的日志
如果一个站点的访问量特别大，那么访问日志就会很多，但有一些访问日志我们其实是可以忽略的，比如网站的一些图片，还有 js，css 等静态对象。而这些文件的访问往往是巨量的，记录这些日志也没什么用，那就可以忽略掉这些访问的日志了。

相关配置是在虚拟主机配置文件中加入以下语句：

```e-bash
[root@localhost ~]# vim /usr/local/apache2/conf/extra/httpd-vhosts.conf
    SetEnvIf Request_URI ".*\.gif$" p_w_picpath-request
    SetEnvIf Request_URI ".*\.jpg$" p_w_picpath-request
    SetEnvIf Request_URI ".*\.png$" p_w_picpath-request
    SetEnvIf Request_URI ".*\.bmp$" p_w_picpath-request
    SetEnvIf Request_URI ".*\.swf$" p_w_picpath-request
    SetEnvIf Request_URI ".*\.js$" p_w_picpath-request
    SetEnvIf Request_URI ".*\.css$" p_w_picpath-request
    ErrorLog "|/usr/local/apache2/bin/rotatelogs -l /usr/local/apache2/logs/123.com-error_%Y%m%d_log 86400"
    CustomLog "|/usr/local/apache2/bin/rotatelogs -l /usr/local/apache2/logs/123.com-access_%Y%m%d_log 86400" combined env=!p_w_picpath-request
```



说明：在原来日志配置的基础上，增加了一些 p_w_picpath-request 的定义，比如把 gif、jpg、bmp、swf、js、css 等结尾的全标记为 p_w_picpath-request ，然后在配置日志的时候加一个标记 env=!p_w_picpath-request，这里有个叹号，表示取反，不加则表示只记录这些字符结尾的访问日志。

重启apache，浏览器检测日志文件，则没有上述文件类型的访问记录。

```e-bash
[root@localhost ~]# /usr/local/apache2/bin/apachectl -t
Syntax OK
[root@localhost ~]# /usr/local/apache2/bin/apachectl restart
```
