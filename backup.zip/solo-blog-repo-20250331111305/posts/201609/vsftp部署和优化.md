title: vsftp 部署和优化
date: '2016-09-12 09:45:24'
updated: '2016-09-12 09:45:24'
tags: [vsftp, ftp]
permalink: /articles/2016/09/12/1473644724856.html
---
# vsftp 部署和优化
### （1）安装 vsftpd

```
[root@133 ~]# yum install -y vsftpd db4-utils
```


&emsp;&emsp;这里安装两个软件包，同时会把依赖的包安装上。其中db4-utils 用来生成密码库文件。

### （2）建立账号

&emsp;&emsp;vsftpd 默认是可以支持使用系统账号体系登录的，但那样不太安全，所以最好使用虚拟账号体系。

&emsp;&emsp;建立虚拟账号相关联的系统账号

```
[root@133 ~]# useradd virftp -s /sbin/nologin
```


&emsp;&emsp;建立虚拟账户相关的文件

```
[root@133 ~]# vim /etc/vsftpd/vsftpd_login

test1

123456

test2

abcdef
```


 &emsp;&emsp;更改该文件的权限，提升安全级别

```
[root@133 ~]# chmod 600 /etc/vsftpd/vsftpd_login
```


&emsp;&emsp;vsftpd使用的密码文件不是明文的，需要生成对应的库文件

```
[root@133 ~]# db_load -T -t hash -f /etc/vsftpd/vsftpd_login /etc/vsftpd/vsftpd_login.db
```


&emsp;&emsp;建立虚拟账号相关的目录以及配置文件

```
[root@133 ~]# mkdir /etc/vsftpd/vsftpd_user_conf

[root@133 ~]# cd /etc/vsftpd/vsftpd_user_conf/
```


### （3）创建和用户对应的配置文件

```
[root@133 vsftpd_user_conf]# vim test1

local_root=/home/virftp/test1

anonymous_enable=NO

write_enable=YES

local_umask=022

anon_upload_enable=NO

anon_mkdir_write_enable=NO

idle_session_timeout=600

data_connection_timeout=120

max_clients=10

max_per_ip=5

local_max_rate=50000
```

&emsp;&emsp;说明：local_root 为该账号的家目录，anonymous_enable 用来限制是否允许匿名账号登陆，若为NO表示不允许匿名账号登陆，write_enable=YES表示可写，local_umask指定umask值，anon_upload_enable 是否允许匿名账号上传文件，anon_mkdir_write_enable 是否允许匿名账号可写。以上为关键配置参数，创建test2账号的步骤和test1一样。

```
[root@133 vsftpd_user_conf]# mkdir /home/virftp/test1

[root@133 vsftpd_user_conf]# chown -R virftp:virftp /home/virftp

[root@133 vsftpd_user_conf]# vim /etc/pam.d/vsftpd          //在最开头添加如下两行

#%PAM-1.0

auth sufficient /lib64/security/pam_userdb.so db=/etc/vsftpd/vsftpd_login

account sufficient /lib64/security/pam_userdb.so db=/etc/vsftpd/vsftpd_login
```


&emsp;&emsp;说明：32为系统的库文件路径是 /lib/security/pam_userdb.so。

### （4）修改全局配置文件 /etc/vsftpd.conf

```
[root@133 ~]# vim /etc/vsftpd/vsftpd.conf


anonymous_enable=YES              改为       anonymous_enable=NO

#anon_upload_enable=YES           改为       anon_upload_enable=NO

#anon_mkdir_write_enable=YES      改为       anon_mkdir_write_enable=NO
```


&emsp;&emsp;再增添：

```
chroot_local_user=YES

guest_enable=YES

guest_username=virftp

virtual_use_local_privs=YES

user_config_dir=/etc/vsftpd/vsftpd_user_conf
```


&emsp;&emsp;启动服务

```
[root@133 ~]# /etc/init.d/vsftpd start

为 vsftpd 启动 vsftpd：                                    [确定]
```


&emsp;&emsp;如果没有启动成功，很有可能是前面的pure-ftpd服务没有关闭。测试过程和前面pure-ftpd的一样。如果用户登陆不了，查看/var/log/secure日志。
