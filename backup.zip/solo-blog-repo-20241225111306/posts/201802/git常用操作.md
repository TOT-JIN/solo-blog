title: git常用操作
date: '2018-02-28 12:44:31'
updated: '2018-02-28 12:44:31'
tags: [git]
permalink: /articles/2018/02/28/1519793071733.html
---
# git常用操作
## 1.1Git介绍
不介绍了，只是篇操作笔记
## 1.2创建版本仓库并推送文件

```
genee@iZ28031cbq3Z:~$ mkdir gitroot
genee@iZ28031cbq3Z:~$ cd gitroot/
genee@iZ28031cbq3Z:~/gitroot$ git init              //初始化，让gitroot变成git可管理的目录
Initialized empty Git repository in /home/genee/gitroot/.git/
genee@iZ28031cbq3Z:~/gitroot$ ls -la
total 12
drwxrwxr-x 3 genee genee 4096 Apr 23 14:51 .
drwxr-xr-x 8 genee genee 4096 Apr 23 14:51 ..
drwxrwxr-x 7 genee genee 4096 Apr 23 14:51 .git
genee@iZ28031cbq3Z:~/gitroot$ cd .git
genee@iZ28031cbq3Z:~/gitroot/.git$ ls
branches  config  description  HEAD  hooks  info  objects  refs
```
```
genee@iZ28031cbq3Z:~/gitroot$ ls
1.txt
genee@iZ28031cbq3Z:~/gitroot$ git add 1.txt
genee@iZ28031cbq3Z:~/gitroot$ git commit -m "add new 1.txt"
[master (root-commit) 387388d] add new 1.txt
 1 file changed, 11 insertions(+)
 create mode 100644 1.txt
```
### 更改1.txt，并回退到更改之前
```
genee@iZ28031cbq3Z:~/gitroot$ vim 1.txt
genee@iZ28031cbq3Z:~/gitroot$ git status
On branch master
Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

	modified:   1.txt

no changes added to commit (use "git add" and/or "git commit -a")
genee@iZ28031cbq3Z:~/gitroot$ git checkout -- 1.txt    //回退到更改之前
genee@iZ28031cbq3Z:~/gitroot$ git status
On branch master
nothing to commit, working directory clean
```
### 取消git add
```
genee@iZ28031cbq3Z:~/gitroot$ git status
On branch master
Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

	modified:   1.txt

no changes added to commit (use "git add" and/or "git commit -a")
genee@iZ28031cbq3Z:~/gitroot$ git add 1.txt
genee@iZ28031cbq3Z:~/gitroot$ git status
On branch master
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

	modified:   1.txt

genee@iZ28031cbq3Z:~/gitroot$ git reset HEAD 1.txt    //取消git add
Unstaged changes after reset:
M	1.txt
genee@iZ28031cbq3Z:~/gitroot$ git status
On branch master
Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

	modified:   1.txt

no changes added to commit (use "git add" and/or "git commit -a")
genee@iZ28031cbq3Z:~/gitroot$ git checkout 1.txt    //回复到更改之前
```
### 再次更改1.txt
```
genee@iZ28031cbq3Z:~/gitroot$ git status
On branch master
Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

	modified:   1.txt

no changes added to commit (use "git add" and/or "git commit -a")
genee@iZ28031cbq3Z:~/gitroot$ git diff     //对比更改前后变化
diff --git a/1.txt b/1.txt
index 668904e..8c7b0dd 100644
--- a/1.txt
+++ b/1.txt
@@ -3,7 +3,7 @@ agas
 gas
 ha
 gdsfhtr
-
+sgds
 h

 fdhdh
genee@iZ28031cbq3Z:~/gitroot$ git add 1.txt
genee@iZ28031cbq3Z:~/gitroot$ git commit     //不编辑退出即未完成，也可 -m " " 方式插入
Aborting commit due to empty commit message.
genee@iZ28031cbq3Z:~/gitroot$ git status
On branch master
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

	modified:   1.txt
genee@iZ28031cbq3Z:~/gitroot$ git commit -m "add a line"
[master 76a98b5] add a line
 1 file changed, 1 insertion(+), 1 deletion(-)
genee@iZ28031cbq3Z:~/gitroot$ git status
On branch master
nothing to commit, working directory clean
```

## 1.3 版本变更
### git log 查看提交过的版本
```
genee@iZ28031cbq3Z:~/gitroot$ git log
commit 5b6b252673e3e6725ee3316ddfa27ccb5493b2da
Author: zhanjie.jin <m13212183585@163.com>
Date:   Sun Apr 23 15:28:21 2017 +0800

    change 1.txt agin agin

commit fb1cc1656ca44a5e9ec85f3d74a6e24dff8a9320
Author: zhanjie.jin <m13212183585@163.com>
Date:   Sun Apr 23 15:27:46 2017 +0800

    change 1.txt agin

commit 76a98b57b0ea9c7d98b732aef0622ec7e5954f62
Author: zhanjie.jin <m13212183585@163.com>
Date:   Sun Apr 23 15:16:56 2017 +0800

    add a line

commit 387388dd1f37041aa344ba0322f04554909b8dfd
Author: zhanjie.jin <m13212183585@163.com>
Date:   Sun Apr 23 14:59:41 2017 +0800

    add new 1.txt
```
```
genee@iZ28031cbq3Z:~/gitroot$ git log --pretty=oneline
5b6b252673e3e6725ee3316ddfa27ccb5493b2da change 1.txt agin agin
fb1cc1656ca44a5e9ec85f3d74a6e24dff8a9320 change 1.txt agin
76a98b57b0ea9c7d98b732aef0622ec7e5954f62 add a line
387388dd1f37041aa344ba0322f04554909b8dfd add new 1.txt
```
### git reset --hard  xxxx
```
genee@iZ28031cbq3Z:~/gitroot$ git reset --hard 76a9
HEAD is now at 76a98b5 add a line
genee@iZ28031cbq3Z:~/gitroot$ git log --pretty=oneline
76a98b57b0ea9c7d98b732aef0622ec7e5954f62 add a line
387388dd1f37041aa344ba0322f04554909b8dfd add new 1.txt
genee@iZ28031cbq3Z:~/gitroot$ git reflog
76a98b5 HEAD@{0}: reset: moving to 76a9
5b6b252 HEAD@{1}: commit: change 1.txt agin agin
fb1cc16 HEAD@{2}: commit: change 1.txt agin
76a98b5 HEAD@{3}: commit: add a line
387388d HEAD@{4}: commit (initial): add new 1.txt
genee@iZ28031cbq3Z:~/gitroot$ git reset --hard 5b6b
HEAD is now at 5b6b252 change 1.txt agin agin
```
## 1.4创建远程仓库
在GitHub上建立新仓库，并添加好公钥
本地建立仓库，并和远程关联
```
genee@iZ28031cbq3Z:~/learngit$ git remote add origin git@github.com:sanyisheng/learngit.git
genee@iZ28031cbq3Z:~/learngit$ git push -u origin master   首次推送指定远程库和分支，之后git push就可以了
genee@iZ28031cbq3Z:~/learngit$ git pull origin master
```
## 1.5 克隆一个远程仓库
```
genee@iZ28031cbq3Z:~$ git clone git@github.com:aminglinux/monitor.git
```
## 1.6 分支管理
### 查看、建立与切换分支
```
genee@iZ28031cbq3Z:~/learngit$ git branch
* master
genee@iZ28031cbq3Z:~/learngit$ git branch zhanjie.jin
genee@iZ28031cbq3Z:~/learngit$ git branch
* master
  zhanjie.jin
genee@iZ28031cbq3Z:~/learngit$ git checkout zhanjie.jin
Switched to branch \'zhanjie.jin\'
genee@iZ28031cbq3Z:~/learngit$ git branch
  master
* zhanjie.jin
```
```
genee@iZ28031cbq3Z:~/learngit$ vim linux.txt
genee@iZ28031cbq3Z:~/learngit$ git add linux.txt
genee@iZ28031cbq3Z:~/learngit$ git commit
Aborting commit due to empty commit message.
genee@iZ28031cbq3Z:~/learngit$ git commit -m "create linux.txt"
[zhanjie.jin e929165] create linux.txt
 1 file changed, 13 insertions(+)
 create mode 100644 linux.txt
genee@iZ28031cbq3Z:~/learngit$ ls
learngit.txt  LICENSE  linux.txt  readme.txt
genee@iZ28031cbq3Z:~/learngit$ git checkout master
Switched to branch \'master\'
Your branch is up-to-date with \'origin/master\'.
genee@iZ28031cbq3Z:~/learngit$ ls
learngit.txt  LICENSE  readme.txt
```
### 分支的合并和删除
```
genee@iZ28031cbq3Z:~/learngit$ git checkout  master
Switched to branch \'master\'
Your branch is up-to-date with \'origin/master\'.
genee@iZ28031cbq3Z:~/learngit$ ls
learngit.txt  LICENSE  readme.txt
genee@iZ28031cbq3Z:~/learngit$ git merge zhanjie.jin
Updating 7dae4d9..e929165
Fast-forward
 linux.txt | 13 +++++++++++++
 1 file changed, 13 insertions(+)
 create mode 100644 linux.txt
genee@iZ28031cbq3Z:~/learngit$ ls
learngit.txt  LICENSE  linux.txt  readme.txt
genee@iZ28031cbq3Z:~/learngit$ git branch
* master
  zhanjie.jin
```
```
genee@iZ28031cbq3Z:~/learngit$ git branch
  master
* zhanjie.jin
genee@iZ28031cbq3Z:~/learngit$ git branch -d zhanjie.jin
error: Cannot delete the branch \'zhanjie.jin\' which you are currently on.
genee@iZ28031cbq3Z:~/learngit$ git checkout master
Switched to branch \'master\'
Your branch is ahead of \'origin/master\' by 1 commit.
  (use "git push" to publish your local commits)
genee@iZ28031cbq3Z:~/learngit$ git branch
* master
  zhanjie.jin
genee@iZ28031cbq3Z:~/learngit$ git branch -d zhanjie.jin
Deleted branch zhanjie.jin (was e929165).
genee@iZ28031cbq3Z:~/learngit$ git branch
* master

genee@iZ28031cbq3Z:~/learngit$ git branch -D zhanjie.jin   //强制删除
```
## 1.7 现场保留
```
genee@iZ28031cbq3Z:~/learngit$ git status
On branch zhanjie.jin
Your branch is up-to-date with \'origin/zhanjie.jin\'.
Untracked files:
  (use "git add <file>..." to include in what will be committed)

	3.txt

nothing added to commit but untracked files present (use "git add" to track)
genee@iZ28031cbq3Z:~/learngit$ git add 3.txt
genee@iZ28031cbq3Z:~/learngit$ git status
On branch zhanjie.jin
Your branch is up-to-date with \'origin/zhanjie.jin\'.
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

	new file:   3.txt

genee@iZ28031cbq3Z:~/learngit$ git stash
Saved working directory and index state WIP on zhanjie.jin: b37c7ef create test.1
HEAD is now at b37c7ef create test.1
genee@iZ28031cbq3Z:~/learngit$ git status
On branch zhanjie.jin
Your branch is up-to-date with \'origin/zhanjie.jin\'.
nothing to commit, working directory clean
genee@iZ28031cbq3Z:~/learngit$ ls
learngit.txt  LICENSE  linux.txt  readme.txt  test.1
genee@iZ28031cbq3Z:~/learngit$ git stash list
stash@{0}: WIP on zhanjie.jin: b37c7ef create test.1
genee@iZ28031cbq3Z:~/learngit$ vim 4.txt
genee@iZ28031cbq3Z:~/learngit$ git add 4.txt
genee@iZ28031cbq3Z:~/learngit$ git sta
stage    stash    status
genee@iZ28031cbq3Z:~/learngit$ git stash
Saved working directory and index state WIP on zhanjie.jin: b37c7ef create test.1
HEAD is now at b37c7ef create test.1
genee@iZ28031cbq3Z:~/learngit$ ls
learngit.txt  LICENSE  linux.txt  readme.txt  test.1
genee@iZ28031cbq3Z:~/learngit$ git status
On branch zhanjie.jin
Your branch is up-to-date with \'origin/zhanjie.jin\'.
nothing to commit, working directory clean
genee@iZ28031cbq3Z:~/learngit$ ls
learngit.txt  LICENSE  linux.txt  readme.txt  test.1
genee@iZ28031cbq3Z:~/learngit$ git stash list
stash@{0}: WIP on zhanjie.jin: b37c7ef create test.1
stash@{1}: WIP on zhanjie.jin: b37c7ef create test.1
genee@iZ28031cbq3Z:~/learngit$ git stash apply stash@{0}
On branch zhanjie.jin
Your branch is up-to-date with \'origin/zhanjie.jin\'.
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

	new file:   4.txt
genee@iZ28031cbq3Z:~/learngit$ git stash list
stash@{0}: WIP on zhanjie.jin: b37c7ef create test.1
stash@{1}: WIP on zhanjie.jin: b37c7ef create test.1
genee@iZ28031cbq3Z:~/learngit$ ls
4.txt  learngit.txt  LICENSE  linux.txt  readme.txt  test.1
genee@iZ28031cbq3Z:~/learngit$ git stash apply stash@{1}
On branch zhanjie.jin
Your branch is up-to-date with \'origin/zhanjie.jin\'.
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

	new file:   3.txt
	new file:   4.txt

genee@iZ28031cbq3Z:~/learngit$ ls
3.txt  4.txt  learngit.txt  LICENSE  linux.txt  readme.txt  test.1
```
## 1.8 远程分支管理

查看远程库信息，git remote -v

本地新建的分支如果不推送到远程，对其他人不可见

```
genee@iZ28031cbq3Z:~/learngit$ git remote -v
origin	git@github.com:sanyisheng/learngit.git (fetch)
origin	git@github.com:sanyisheng/learngit.git (push)
```

查看远程分支 git ls-remote origin

```
genee@iZ28031cbq3Z:~/learngit$ git ls-remote origin
ec9a76b9b893ae6755b4551c519fb29c96b06bb9	HEAD
ec9a76b9b893ae6755b4551c519fb29c96b06bb9	refs/heads/master
b37c7ef7d9eb847bd9e4ab86b504ec059f244406	refs/heads/zhanjie.jin
e9291650907ea3226c1b42e8752925155d7cabc9	refs/pull/1/head
```

从本地推送分支， git push origin branch-name，如果推送失败，先用git pull抓取远程的新提交

```
genee@iZ28031cbq3Z:~/learngit$ git push origin dev
Counting objects: 4, done.
Compressing objects: 100% (2/2), done.
Writing objects: 100% (4/4), 351 bytes | 0 bytes/s, done.
Total 4 (delta 1), reused 0 (delta 0)
remote: Resolving deltas: 100% (1/1), completed with 1 local object.
To git@github.com:sanyisheng/learngit.git
 * [new branch]      dev -> dev
```


