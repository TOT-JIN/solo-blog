title: shell 函数
date: '2016-10-15 21:21:19'
updated: '2016-10-15 21:21:19'
tags: [shell]
permalink: /articles/2016/10/15/1476537679856.html
---
# shell 函数
&emsp;&emsp;函数就是把一段代码整合在了一个小单元中，并给这个小单元起了一个名字，当用到这段代码时直接调用这个小单元的名字即可。

&emsp;&emsp;格式：

&emsp;&emsp;function f_name() {
&emsp;&emsp;&emsp;&emsp;command
&emsp;&emsp;}   

      
&emsp;&emsp;函数必须放在最前面。

&emsp;&emsp;例：

```
[root@133 ~]# vim function1.sh
#!/bin/bash

input(){
 echo $1
}

input aaa
```

&emsp;&emsp;这个脚本就是一个非常简单的函数，函数名字为input，它的作用就是输出参数1的内容。

```
[root@133 ~]# sh function1.sh
aaa
```

&emsp;&emsp;加法运算：

```
[root@133 ~]# vim function2.sh
#!/bin/bash

sum(){
  s=$[$1+$2]
  echo $s
}

sum 1 2
```

&emsp;&emsp;说明：sum为一个加法运算函数，$1，$2为第一个和第二个参数，sum 1 2 ，其实就是 1+2，最后echo出来它们的和。

&emsp;&emsp;复杂一点的函数：

```
[root@133 ~]# vim function3.sh
#!/bin/bash

ip(){
  ifconfig|grep -A1 "$1"|tail -1|awk '{print $2}'|awk -F ':' '{print $2}'
}
read -p "Please input the eth name:" e
myip=`ip $e`

echo "$e address is $myip"
```

&emsp;&emsp;说明：ip函数其实就是通过grep和awk把网卡的ip给截取出来，只不过网卡的名字是让用户自己输入的。

```
[root@133 ~]# sh function3.sh
Please input the eth name:eth0
eth0 address is 192.168.56.133
```
