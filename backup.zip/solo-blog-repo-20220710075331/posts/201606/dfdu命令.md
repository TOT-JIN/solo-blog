title: df du命令
date: '2016-06-27 21:33:57'
updated: '2016-06-27 21:33:57'
tags: [df, du]
permalink: /articles/2016/06/27/1467034437592.html
---
# df du命令
df 命令

 **df查看已挂载磁盘的总容量、使用容量、剩余容量等。可以不加任何参数，默认按k为单位显示。**

```
[root@localhost ~]# df

Filesystem     1K-blocks    Used Available Use% Mounted on

/dev/sda3       18244476 1603980  15707072  10% /

tmpfs             506228       0    506228   0% /dev/shm

/dev/sda1         194241   27180    156821  15% /boot
```

**df常用选项有 -i  , -h  , -k  , -m**



**-i 查看inodes使用状况**

```
[root@localhost ~]# df -i

Filesystem      Inodes IUsed   IFree IUse% Mounted on

/dev/sda3      1166880 37974 1128906    4% /

tmpfs           126557     1  126556    1% /dev/shm

/dev/sda1        51200    38   51162    1% /boot
```

**-h 使用合适的单位显示，例如 G**

```
[root@localhost ~]# df -h

Filesystem      Size  Used Avail Use% Mounted on

/dev/sda3        18G  1.6G   15G  10% /

tmpfs           495M     0  495M   0% /dev/shm

/dev/sda1       190M   27M  154M  15% /boot
```

**-k , -m 分别以K和M为单位显示**

```
[root@localhost ~]# df -k

Filesystem     1K-blocks    Used Available Use% Mounted on

/dev/sda3       18244476 1603980  15707072  10% /

tmpfs             506228       0    506228   0% /dev/shm

/dev/sda1         194241   27180    156821  15% /boot

[root@localhost ~]# df -m

Filesystem     1M-blocks  Used Available Use% Mounted on

/dev/sda3          17817  1567     15339  10% /

tmpfs                495     0       495   0% /dev/shm

/dev/sda1            190    27       154  15% /boot
```

**各列所代表的含义为：第一列是分区的名字，第二列为该分区总共的容量，第三列为已经使用了多少，第四列为还剩下多少，第五列为已经使用的百分比（如若达到90%以上，就应该关注了，分区满了会引起系统崩溃），最后一列为挂载点，/dev/shm 为内存挂载点，如果想把文件放到内存里，就可以放到/dev/shm/ 目录下。**

---

du 命令



**du 用来查看某个目录或文件所占空间大小。语法： du [-abckmsh] [文件或者目录名] 常用的参数有：**



**-a ：全部文件与目录大小都列出来。如果不加选项和参数只列出目录（包含子目录）大小。**

```
[root@localhost ~]# du dirb

4       dirb/dirc

8       dirb

[root@localhost ~]# du -a dirb

0       dirb/filee

4       dirb/dirc

8       dirb
```

**如果du不指定单位的话，默认显示单位为K。**

**-b ：列出的值以bytes为单位输出。**

**-k ：以KB为单位输出，和默认不加任何选项的输出值是一样的。**

**-m ：以MB为单位输出。**

**-h ：系统自动调节单位，例如文件大小可能就几K，那么就以K为单位显示，如果大到几G，就以G为单位显示。**

```
[root@localhost ~]# du -b /etc/passwd

1023    /etc/passwd

[root@localhost ~]# du -k /etc/passwd

4       /etc/passwd

[root@localhost ~]# du -m /etc/passwd

1       /etc/passwd

[root@localhost ~]# du -h /etc/passwd

4.0K    /etc/passwd
```

**-c 选项为最后加总**

```
[root@localhost ~]# du -c dirb

4       dirb/dirc

8       dirb

8       总用量

[root@localhost ~]# du dirb

4       dirb/dirc

8       dirb
```

**-s 只列出总和**

```
[root@localhost ~]# du -s dirb

8       dirb
```

**单单查看某一目录大小属性，-sh搭配使用最好，du -sh filename**
