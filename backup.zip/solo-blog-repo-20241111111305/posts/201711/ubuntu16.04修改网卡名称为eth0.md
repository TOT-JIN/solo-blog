title: ubuntu16.04修改网卡名称为eth0
date: '2017-11-24 11:52:12'
updated: '2017-11-24 11:52:12'
tags: [ubuntu, 网卡, eth0]
permalink: /articles/2017/11/24/1511495532856.html
---
# ubuntu16.04修改网卡名称为eth0
1. sudo nano /etc/default/grub

找到GRUB_CMDLINE_LINUX="" 
改为GRUB_CMDLINE_LINUX="net.ifnames=0 biosdevname=0" 
然后sudo grub-mkconfig -o /boot/grub/grub.cfg 


2. 打开ubuntu的/etc/network/interfaces文件默认的内容如下：

&emsp;&emsp;&emsp;auto lo 
&emsp;&emsp;&emsp;iface lo inet loopback 

 - 获取动态配置： 

&emsp;&emsp;&emsp;auto eth0 
&emsp;&emsp;&emsp;iface eth0 inet dhcp 

 - 获取静态配置： 

&emsp;&emsp;&emsp;auto eth0 
&emsp;&emsp;&emsp;iface eth0 inet static 
&emsp;&emsp;&emsp;address 192.168.0.1 
&emsp;&emsp;&emsp;netmask 255.255.255.0 
&emsp;&emsp;&emsp;gateway 192.168.0.1 


&emsp;&emsp;重启
