title: 磁盘格式化 mke2fs
date: '2016-07-12 13:43:17'
updated: '2016-07-12 13:43:17'
tags: [mke2fs, mkfs.ext2, mkfs.ext3, mkfs.ext4]
permalink: /articles/2016/07/12/1468302197856.html
---
# 磁盘格式化 mke2fs
**命令： mke2fs  、mkfs.ext2 、mkfs.ext3 、mkfs.ext4**



**mke2fs常用的选项有：**



**-b 分区时设定每个数据区块占用空间的大小，目前支持1024、2048以及4096 bytes每个块**

**-i 设定 inode 的大小**

**-N 设定 inode 数量，有时使用默认的 inode 数不够用，所以要自定义 inode 数量**

**-c 在格式化前先检测一下磁盘是否有问题，加上这个选项后会非常慢**

**-L 预设该分区的标签 label**

**-j 建立ext3格式的分区，如果使用 mkfs.ext3 就不用加这个选项了**

**-t 用来指定什么类型的文件系统，可以是ext2、ext3也可以是ext4**

**-m 格式化时，指定预留给管理员的磁盘比例，是一个百分比，只针对mke2fs命令**

```
[root@localhost ~]# mke2fs -t ext4 /dev/sdb5

mke2fs 1.41.12 (17-May-2010)

文件系统标签=

操作系统:Linux

块大小=4096 (log=2)

分块大小=4096 (log=2)

Stride=0 blocks, Stripe width=0 blocks

66384 inodes, 265056 blocks

13252 blocks (5.00%) reserved for the super user

第一个数据块=0

Maximum filesystem blocks=272629760

9 block groups

32768 blocks per group, 32768 fragments per group

7376 inodes per group

Superblock backups stored on blocks:

        32768, 98304, 163840, 229376

正在写入inode表: 完成

Creating journal (8192 blocks): 完成

Writing superblocks and filesystem accounting information: 完成

This filesystem will be automatically checked every 39 mounts or

180 days, whichever comes first.  Use tune2fs -c or -i to override.
```

**指定文件系统格式为ext4，该命令等同于mkfs.ext4 /dev/sdb5。在上面的例子中有一项指标是”块大小=4096“这里涉及到一个”块“的概念。磁盘在被格式化的时候会预先规定好每一个块的大小，然后再把所有的空间分割成一个一个的小块，存数据的时候也是一个块一个块的去写入。ext文件系统默认块大小为4096也就是4k。在格式化的时候，可以指定块大小为1024、2048、4096（它们是成倍增加的）。虽然格式化时可以指定块大小超过4096，但是一旦超过4096则不能正常挂载。**

**指定块大小：**

```
[root@localhost ~]# mke2fs -t ext4 -b 8192 /dev/sdb5

Warning: blocksize 8192 not usable on most systems.

mke2fs 1.41.12 (17-May-2010)

mke2fs: 8192-byte blocks too big for system (max 4096)

无论如何也要继续? (y,n) y                          //指定块大小为8192会提示，块值设置太大了，我们直接输入y强制格式化。

Warning: 8192-byte blocks too big for system (max 4096), forced to continue

文件系统标签=

操作系统:Linux

块大小=8192 (log=3)

分块大小=8192 (log=3)

Stride=0 blocks, Stripe width=0 blocks

66336 inodes, 132528 blocks

6626 blocks (5.00%) reserved for the super user

第一个数据块=0

Maximum filesystem blocks=150976512

3 block groups

65528 blocks per group, 65528 fragments per group

22112 inodes per group

Superblock backups stored on blocks:

        65528

正在写入inode表: 完成

Creating journal (4096 blocks): 完成

Writing superblocks and filesystem accounting information: 完成

This filesystem will be automatically checked every 27 mounts or

180 days, whichever comes first.  Use tune2fs -c or -i to override.
```

**可以使用-L来指定标签。标签会在挂载磁盘时使用，另外也可以写到配置文件里。**

```
[root@localhost ~]# mke2fs -t ext4 -L TEST -b 8192 /dev/sdb5
```

**命令：e2label**

**该命令用来查看或修改分区的标签**

```
[root@localhost ~]# e2label /dev/sdb5

TEST

[root@localhost ~]# e2label /dev/sdb5 TEST123

[root@localhost ~]# e2label /dev/sdb5

TEST123
```
