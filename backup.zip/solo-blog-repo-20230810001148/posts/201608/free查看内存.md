title: free 查看内存
date: '2016-08-11 12:22:24'
updated: '2016-08-11 12:22:24'
tags: [free, 内存]
permalink: /articles/2016/08/11/1470889344345.html
---
# free 查看内存
```
[root@localhost ~]# free

             total       used       free     shared    buffers     cached

Mem:       1012456     514068     498388        212      25420     398504

-/+ buffers/cache:      90144     922312

Swap:      2097148        832    2096316
```


&emsp;&emsp;只需要free回车就能查看当前系统的总内存大小以及使用内存的情况。从上例中可以查看当前系统内存总大小为1012456（k）已经使用514068，剩余498388。但其实真正的使用以及剩余是第二行“-/+ buffers/cache:”后的信息，因为系统初始化时，就已经分配出很大一部分内存给缓存，这部分缓存用来随时提供给程序使用。如果程序不用，那这部分内存就空闲着。所以实际情况参照第二行，还可以加-m或-g选项分别以Mb或Gb为单位打印内存使用状况：



```
[root@localhost ~]# free -m

             total       used       free     shared    buffers     cached

Mem:           988        501        486          0         24        389

-/+ buffers/cache:         87        901

Swap:         2047          0       2047
```
