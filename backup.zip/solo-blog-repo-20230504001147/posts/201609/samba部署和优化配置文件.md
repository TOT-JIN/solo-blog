title: samba 部署和优化--配置文件
date: '2016-09-12 19:15:44'
updated: '2016-09-12 19:15:44'
tags: [samba]
permalink: /articles/2016/09/12/1473678944856.html
---
# samba 部署和优化--配置文件
&emsp;&emsp;使用samba服务可以实现 windows 和 linux 的文件共享，配置也不难。

### （1）samba 配置文件 smb.conf

&emsp;&emsp;安装系统的时候大多会默认安装 samba，如果没有安装，就用yum。

```
[root@133 ~]# yum install -y samba samba-client
```

&emsp;&emsp;通过修改samba的配置文件 /etc/samba/smb.conf，可以满足我们的各种需求。

&emsp;&emsp;打开配置文件，很多内容都被注释掉了，主要看看未注释的。

```
[global]

        workgroup = MYGROUP

        server string = Samba Server Version %v

        log file = /var/log/samba/log.%m

        max log size = 50

        security = user

        passdb backend = tdbsam

        load printers = yes

        cups options = raw

[homes]

        comment = Home Directories

        browseable = no

        writable = yes

[printers]

        comment = All Printers

        path = /var/spool/samba

        browseable = no

        guest ok = no

        writable = no

        printable = yes
```

&emsp;&emsp;主要有以上三个部分：**[global]**，**[homes]**，**[printers]**

&emsp;&emsp;**[global]** 定义全局的配置，workgroup用来定义工作组。一般情况下，需要把这里的MYGROUP改成 WORKGROUP（Windows默认的工作组名字）。

&emsp;&emsp;**`security = user`**   这里指定samba的安全等级。关于其安全等级有四种：

&emsp;&emsp;&emsp;`share`：用户不需要账户及密码即可登录samba服务器

&emsp;&emsp;&emsp;`user`：由提供服务的samba服务器负责检查账户及密码（默认）

&emsp;&emsp;&emsp;`server`：检测账户及密码的工作由另一台windows或samba服务器负责

&emsp;&emsp;&emsp;`domain`：指定 windows 域控制服务器来验证用户的账户及密码

&emsp;&emsp;**`passdb backend = tdbsam`**    passdb backend是用户后台，samba有三种用户后台：smbpasswd，tdbsam 和 ldapsam。

&emsp;&emsp;&emsp;`smbpasswd`：该方式是使用 smb 工具 smbpasswd 给系统用户（真实用户或虚拟用户）设置一个samba密码，客户端就用此密码访问samba资源。smbpasswd 在 /etc/samba 中，有时需要手工创建该文件。

&emsp;&emsp;&emsp;`tdbsam`：使用数据库文件创建用户数据库。数据库文件叫 passdb.tdb，在 /etc/samba 中。passdb.tdb 用户数据库可使用 smbpasswd -a 创建 samba用户，要创建的 samba 用户必须先是系统用户。也可以使用 pdbedit 创建 samba 用户。pdbedit 参数很多，列出几个主要的：

```
# pdbedit -a username   //新建samba账户

# pdbedit -x username   //删除samba账户

# pdbedit -L    //列出samba用户列表，读取 passdb.tdb 数据库文件

# pdbedit -Lv   //列出 samba 用户列表详细信息

# pdbedit -c "[D]" -u username  //暂停该samba用户账号

# pdbedit -c "[]" -u username   //恢复该samba用户账号
```


&emsp;&emsp;&emsp;`ldapsam`：基于LDAP账户管理方式验证用户。首先要建立LDAP服务，设置 `passdb backend = ldapsam:ldap://LDAP Server`

&emsp;&emsp;**load printers** 和 **cups options** 两个参数用来设置打印机相关

&emsp;&emsp;除了这些参数，还需了解：

&emsp;&emsp;&emsp;`netbios name = MYSERVER`   设置出现在网上邻居中的主机名

&emsp;&emsp;&emsp;`hosts allow = 127.0.   192.168.`     用来设置允许的主机，如果在前面加  ；  号注释掉，则表示允许所有主机

&emsp;&emsp;&emsp;`log file = /var/log/samba/%m.log`   定义samba的日志，这里的%m是上面的netbios name

&emsp;&emsp;&emsp;`max log size = 50`   指定日志的最大容量，单位是K

     

&emsp;&emsp;**[homes]** 该部分内容共享用户自己的家目录，也就是说，当用户登录到samba服务器上时实际上是进入到了该用户的家目录，用户登陆后，共享名不是 homes 而是用户自己的标识符，对于单纯的文件共享的环境来说，这部分可以注释掉。

&emsp;&emsp;**[printers]** 该部分内容设置打印机共享。
