title: ubuntu升级openssh
date: '2018-06-10 12:24:23'
updated: '2018-06-10 12:24:23'
tags: [ubuntu, openssh]
permalink: /articles/2018/06/10/1528604663832.html
---
# ubuntu升级openssh

---

## ubuntu 修复 openssh 版本过低漏洞
---
OpenSSH（OpenBSD Secure Shell）是OpenBSD计划组所维护的一套用于安全访问远程计算机的连接工具。该工具
是SSH协议的开源实现，支持对所有的传输进行加密，可有效阻止窃听、连接劫持以及其他网络级的攻击。sshd是
其中的一个独立守护进程。OpenSSH 7.2p2及之前版本的sshd中的session.c文件中的‘do_setup_env’函数存在安全漏洞。
当程序启用UseLogin功能并且PAM被配置成读取用户主目录中的.pam_environment文件时，本地攻击者可借助/bin/login
程序的特制的环境变量利用该漏洞获取权限；sshd中的session.c文件中存在CRLF注入漏洞。远程攻击者可借助特制的
X11转发数据利用该漏洞绕过既定的shell-command限制。

---

> 线上环境，避免升级出现错误导致ssh服务挂掉，提前安装telnet服务
> $ apt-get install openbsd-inetd telnetd telnet

> $ /etc/init.d/openbsd-inetd restart

> $ netstat -anpt | grep 23

> $ telnet ip

#### 1.下载源码

```
openssl-1.1.1b.tar.gz  # 官方下载地址:  https://www.openssl.org/source/
openssh-7.9p1.tar.gz   # 官方下载地址:  https://fastly.cdn.openbsd.org/pub/OpenBSD/OpenSSH/portable/
zlib-1.2.11.tar.gz     # 官方下载地址:  http://www.zlib.net/
```

#### 2.安装zlib
```

tar xf zlib-1.2.11.tar.gz
cd zlib-1.2.11
./configure --prefix=/usr/local/zlib
make
make install
---------------------------------报错-------------------------------------------
# 报错： c_zlib.c:25:19: fatal error: zlib.h: No such file or directory
# zlib标准安装指导：
# /usr/local/src/zlib-1.2.11
 
# 构建静态库
 ./configure
make test
make install
# 构建共享库
make clean
./configure --shared
make test
make install
cp zutil.h /usr/local/include

```

#### 3.升级openssl
```

tar xf openssl-1.1.1b.tar.gz
cd openssl-1.1.1b
./config shared zlib            #一定要加上shared 参数，要不在安装openssh的时候就无法找到
make
make install
# 备份原来的openssl
mv /usr/bin/openssl /usr/bin/openssl.bak
mv /usr/include/openssl /usr/include/openssl.bak

# 因为源码安装默认安装的位置是 /usr/local/ssl 需要将创建软链接到系统位置
ln -s /usr/local/bin/openssl /usr/bin/openssl
ln -s /usr/local/include/openssl /usr/include/openssl

# 将openssl 的lib 库添加到系统
echo "/usr/local/lib" > /etc/ld.so.conf.d/openssl.conf

#使新添加的lib 被系统找到
ldconfig

# 查看openssl版本
openssl version -a

至此opensll 已经成功升级到1.0.2o

安装完之后使用curl，nodejs等命令如果报错，说明动态库方面调用有问题，报错如下
/usr/local/sbin/xxxx: /usr/local/lib/libssl.so.1.0.0: no version information available (required by /usr/local/sbin/xxxx)
/usr/local/sbin/xxxx: /usr/local/lib/libcrypto.so.1.0.0: no version information available (required by /usr/local/sbin/xxxx)
/usr/local/sbin/xxxx: /usr/local/lib/libcrypto.so.1.0.0: no version information available (required by /usr/local/lib/xxxx-server.so)
/usr/local/sbin/xxxx: /usr/local/lib/libcrypto.so.1.0.0: no version information available (required by /usr/local/lib/xxxx-radius.so)

# 到openssl解压目录下
vim openssl.ld
//文件内容
OPENSSL_1.1.1 {
    global:
    *;
};
make distclean
# 重新编译
./config shared zlib -Wl,--version-script=/usr/local/src/openssl-1.1.1b/openssl.ld -Wl,-Bsymbolic-functions
make
make install

```

#### 4.升级openssh
```
# 备份原openssh文件
cp /etc/init.d/ssh /etc/init.d/ssh.old
cp -r /etc/ssh /etc/ssh.old

# 卸载原openssh
apt-get remove openssh-server openssh-client
tar xf openssh-7.9p1.tar.gz
cd openssh-7.9p1
#需要指定openssl的安装路径
./configure --prefix=/usr --sysconfdir=/etc/ssh --with-md5-passwords --with-pam --with-zlib=/usr/local/zlib --with-ssl-dir=/usr/local --with-privsep-path=/var/lib/sshd
---------------------------------报错-----------------------------------------
# 报错  checking whether OpenSSL's PRNG is internally seeded... yes
#       configure: error: PAM headers not found
# 解决：ubuntu： apt-get install libpam0g-dev   centos: yum -y install pam-devel


make
make install


---------------------------------报错-----------------------------------------
# 报错： Privilege separation user sshd does not exist
vim /etc/passwd
sshd:x:74:74:Privilege-separated SSH:/var/empty/sshd:/sbin/nologin
# 注册名：口令：用户标识号：组标识号：用户名：用户主目录：命令解释程序
# /etc/passwd文件是Linux/UNIX安全的关键文件之一.该文件用于用户登录时校验 用户的口令,当然应当仅对root可写.
------------------------------------------------------------------------------

#可查看当前SSH的版本。
ssh -V

```

1. 修改默认配置文件
    根据之前配置修改,保证配置相同
2. 也可使用原来的配置文件
    cd /etc/ssh
    mv sshd_config sshd_config.default
    cp ../ssh.old/sshd_config ./

    使用原来的/etc/init.d/ssh
    mv /etc/init.d/ssh.old /etc/init.d/ssh

    取消注销指定服务
    systemctl unmask ssh
    重启服务
    systemctl restart ssh


## SSH&SSL弱加密算法漏洞修复

SSH的配置文件中加密算法没有指定，默认支持所有加密算法，包括arcfour,arcfour128,arcfour256等弱加密算法。

修改SSH配置文件，添加加密算法：
```vi /etc/ssh/sshd_config```
最后面添加以下内容（去掉arcfour,arcfour128,arcfour256等弱加密算法）：
```Ciphers aes128-ctr,aes192-ctr,aes256-ctr,aes128-cbc,3des-cbc```

> ssh_config和sshd_config都是ssh服务器的配置文件，二者区别在于，前者是针对客户端的配置文件，后者则是针对服务端的配置文件。

保存文件后重启SSH服务：
```
service ssh restart
```

## ssh 版本号
```
strings /usr/sbin/sshd |grep OpenSSH_7.9
telnet server_ip 22
```
```
sudo sed -i 's/OpenSSH_7.9/OpenSSH_ssh/g' /usr/sbin/sshd
strings /usr/sbin/sshd |grep OpenSSH_7.9
telnet server_ip 22
```


