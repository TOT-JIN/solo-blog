title: shell 中连接符（并且、和、或者）
date: '2016-10-05 12:14:55'
updated: '2016-10-05 12:14:55'
tags: [shell, 与或非]
permalink: /articles/2016/10/05/1475640895856.html
---
# shell 中连接符（并且、和、或者）
**&& 与 ||**

在上面刚刚提到了分号，用于多条命令间的分隔符。另外还有两个可以用于多条命令中间的特殊符号，那就是 “&&” 和 “||” 下面阿铭把这几种情况全列出：

1. command1 ; command2
2. command1 && command2
3. command1 || command2

使用 ”;” 时，不管command1是否执行成功都会执行command2；

使用 “&&” 时，只有command1执行成功后，command2才会执行，否则command2不执行；

使用 “||” 时，command1执行成功后command2 不执行，否则去执行command2，总之command1和command2总有一条命令会执行。
