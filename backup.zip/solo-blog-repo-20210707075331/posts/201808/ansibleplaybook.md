title: ansible playbook
date: '2018-08-05 19:11:44'
updated: '2018-08-05 19:11:44'
tags: [ansible, playbook, 自动化运维]
permalink: /articles/2018/08/05/1533467504832.html
---
# ansible playbook
&emsp;playbook 就相当于把模块写入到配置文件里

&emsp;&emsp;例：

```
[root@server ~]# cd /etc/ansible/

[root@server ansible]# vim test.yml

---

- hosts: client.test.com

  remote_user: root

  tasks:

    - name: test_playbook

      shell: touch /tmp/test.txt
```

&emsp;&emsp;说明：hosts参数指定了对哪些主机进行操作

&emsp;&emsp;&emsp;user参数指定了使用哪个账户登录远程主机操作

&emsp;&emsp;&emsp;tasks指定了一个任务，其下面的name参数同样是对任务的描述，在执行过程中会打印出来。

&emsp;&emsp;执行：ansible-playbook test.yml

```
[root@server ansible]# ansible-playbook test.yml



PLAY [client.test.com] *********************************************************



TASK [setup] *******************************************************************

ok: [client.test.com]



TASK [test_playbook] ***********************************************************

changed: [client.test.com]

 [WARNING]: Consider using file module with state=touch rather than running

touch



PLAY RECAP *********************************************************************

client.test.com            : ok=2    changed=1    unreachable=0    failed=0
```



&emsp;&emsp;例：

```
[root@server ansible]# vim /etc/ansible/create_user.yml

---

- name: create_user

  hosts: testhosts

  user: root

  gather_facts: false

  vars:

   - user: "test"

  tasks:

   - name: create user

     user: name="{{user}}"
```


&emsp;&emsp;说明：name参数对该playbook实现的功能做一个概述，后面执行过程中，会打印name变量的值，可以省略；

&emsp;&emsp;&emsp;gather_facts参数指定了在以下任务部分执行前，是否先执行setup模块获取主机相关信息，这在后面的tasks需要使用setup获取的信息时用到；（# ansible client.test.com -m setup ，setup模块可收集机器信息）  

&emsp;&emsp;&emsp;vars参数，指定了变量，这里指定了一个user变量，其值为test，需要注意的是，变量值一定要用引号引起来；

&emsp;&emsp;&emsp;user参数指定了调用user模块，name是user模块里的一个参数，而增加的用户名字调用了上面user变量的值。



&emsp;&emsp;执行：

```
[root@server ansible]# ansible-playbook create_user.yml



PLAY [create_user] *************************************************************



TASK [create user] *************************************************************

changed: [client.test.com]

changed: [127.0.0.1]



PLAY RECAP *********************************************************************

127.0.0.1                  : ok=1    changed=1    unreachable=0    failed=0

client.test.com            : ok=1    changed=1    unreachable=0    failed=0
```
