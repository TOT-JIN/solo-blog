title: LNMP--nginx 日志切割
date: '2018-02-12 23:24:13'
updated: '2018-02-12 23:24:13'
tags: [lnmp, nginx, 日志]
permalink: /articles/2018/02/12/1518449053733.html
---
# LNMP--nginx 日志切割
&emsp;&emsp;nginx没有apache那样自动切割的工具，但是我们可以自己写脚本，也可以借助CentOS自带的日志归档工具 logrotate 。

&emsp;（1）先来写一个 nginx 日志切割的脚本

&emsp;&emsp;首先确定访问日志路径，假定为/usr/local/nginx/logs/access.log，还要确定 nginx 的 pid 文件所在路径，假定为 /usr/local/nginx/logs/nginx.pid。下面开始写切割日志脚本。

```
[root@localhost ~]# vim /usr/local/sbin/nginx_logrotate.sh

#!/bin/bash

d=`date -d "-1 day" +%Y%m%d`

/bin/mv /usr/local/nginx/logs/access.log /usr/local/nginx/logs/$d_access.log

/bin/kill -HUP `cat /usr/local/nginx/logs/nginx.pid`
```


&emsp;&emsp;然后写一个计划任务，每天0时0分执行该脚本。

&emsp;（2）借助系统的 logrotate 工具实现

```
[root@localhost ~]# vim /etc/logrotate.d/nginx

/usr/local/nginx/logs/*.log {

Daily

Missingok

rotate 52

compress

delaycompress

notifempty

create 644 nobody nobody

sharedscripts

postrotate

[ -f /usr/local/nginx/logs/nginx.pid] && kill -USRl `cat /usr/local/nginx/logs/nginx.pid`

Endscript

}
```


&emsp;&emsp;说明：

&emsp;&emsp;第一行就要定义日志的路径，可以是多个日志。

&emsp;&emsp;daily 表示日志按天归档。

&emsp;&emsp;missingok 表示忽略所有错误，比如日志文件不存在的情况下。

&emsp;&emsp;rotate 52 表示存放的日志个数，最多就52个，最老的会被删除。

&emsp;&emsp;compress 表示日志要压缩。

&emsp;&emsp;delaycompress 表示压缩除了当前和最近之外的所有其他版本。

&emsp;&emsp;notifempty 表示如果日志为空，则不归档。

&emsp;&emsp;create 644 nobody nobody 定义归档日志的权限以及属主和属组。

&emsp;&emsp;sharedscripts 表示所有的日志共享该脚本，因为我们在这里指定的日志文件为多个，用来*.log。

&emsp;&emsp;postrotate 后面跟轮换过日志之后要运行的命令。

&emsp;&emsp;endscript 表示结束了。
