title: LNMP--nginx 访问控制
date: '2018-02-17 12:14:23'
updated: '2018-02-17 12:14:23'
tags: [lnmp, nginx, 访问控制]
permalink: /articles/2018/02/17/1518840863733.html
---
# LNMP--nginx 访问控制
&emsp;&emsp;以下语句的插入请注意对应配置位置，区分全局和局部生效。



&emsp;&emsp;限制只让某个 ip 访问，加如下配置：



```
allow   192.168.1.101;

deny    all;
```




&emsp;&emsp;禁止某个IP或者IP段访问站点的设置方法，首先建立下面的配置文件放在nginx的conf目录下面，命名为deny.ip

```
[root@localhost ~]# vim /usr/local/nginx/conf/deny.ip

deny 192.168.1.11;

deny 192.168.1.123;

deny 10.0.1.0/24;
```




&emsp;&emsp;在对应的虚拟主机配置文件中加入：

```
include deny.ip;
```


&emsp;&emsp;重启一下nginx的服务：

```
[root@localhost ~]# /usr/local/nginx/sbin/nginx -s reload
```


&emsp;&emsp;deny.ip 的格式中也可以用 deny all；



&emsp;&emsp;如果想实现这样的应用：除了几个IP外，其他全部拒绝，需要这样写：

```
allow 1.1.1.1;

allow 1.1.1.2;

deny  all;
```




&emsp;&emsp;有时候会根据目录来限制 php 解析：



```
location ~ .*(diy|template|attachments|forumdata|attachment|image)/.*\.php$

{

      deny  all;

}
```
