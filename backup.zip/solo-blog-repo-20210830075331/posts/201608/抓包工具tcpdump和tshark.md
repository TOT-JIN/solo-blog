title: 抓包工具 tcpdump 和 tshark
date: '2016-08-12 21:25:42'
updated: '2016-08-12 21:25:42'
tags: [tcpdump, tshark, 抓包, cli]
permalink: /articles/2016/08/12/1471008342345.html
---
# 抓包工具 tcpdump 和 tshark
&emsp;&emsp;有时候，我们会想知道某个网卡上都有哪些数据包。尤其是初步判定服务器上有流量攻击时，此时，使用抓包工具来抓一下数据包，就可以知道有哪些 IP 在攻击了。

       

&emsp;&emsp;**tcpdump 工具**

&emsp;&emsp;使用 yum install -y tcpdump 安装，tcpdump -nn -i eth0 抓包
![bf81947f9a3a71970c687a87ea1369b06.png](https://b3logfile.com/file/2020/06/bf81947f9a3a71970c687a87ea1369b06-81e12684.png)



        

&emsp;&emsp;上例中第三列和第四列显示的信息为哪一个IP+port在连接哪一个IP+port，后面的信息是该数据包的相关信息。-i 选项后面跟设备名称，如果想抓eth1网卡的包，后面则要跟eth1。至于 -nn 选项的作用是让第三列和第四列显示成IP+port的形式，如果不加 -nn 则会显示成主机名+服务名称。



```
[root@localhost ~]#tcpdump -nn -i eth1 host 192.168.1.100 and port 80 -c 100 -w 1.cap
```



&emsp;&emsp;说明：可以用host指定ip，port指定端口，-c指定包数量，-w写入指定文件里。这样1.cap文件里面是包的内容，而如果不加-w直接在屏幕上显示的不是数据包，而是数据流向。这个1.cap可以下载到windows上，然后使用wireshark查看。



&emsp;&emsp;**wireshark工具**



 &emsp;&emsp;在linux下使用wireshark是命令行形式的，需要用yum install -y wireshark安装。

&emsp;&emsp;执行的命令为 tshark：

```
[root@localhost ~]#tshark -n -t a -R http.request -T fields -e "frame.time" -e "ip.src" -e "http.host" -e "http.request.method" -e "http.request.uri"
```



&emsp;&emsp;这条命令用于web服务器，可以显示如下信息：

```
Mar 21,2014 15:37:08.857507000 199.30.20.38 k168.123.com GET /thread-4861-1-1.html
```

&emsp;&emsp;这类似于web访问日志，有时候若服务器没有配置访问日志，可以临时使用该命令查看一下当前服务器上的web请求。
