title: shell 中断继续退出
date: '2016-10-14 11:51:19'
updated: '2016-10-14 11:51:19'
tags: [shell]
permalink: /articles/2016/10/14/1476417079856.html
---
# shell 中断继续退出
&emsp;break 直接结束本层循环 

```
#!/bin/bash

for i in `seq 1 5`
do
    echo $i
    if [ $i == 3 ]
    then
       break
    fi

    echo $i
done

echo aaaaaaaa
```

&emsp;continue 忽略 continue 之下的代码，直接进行下一次循环

```
#!/bin/bash

for i in `seq 1 5`
do
   echo $i
   if [ $i == 3 ]
   then
      continue
   fi

   echo $i
done

echo aaaaaaaa
```


&emsp;exit 直接退出shell


```
#!/bin/bash

for i in `seq 1 5`
do
    echo $i

    if [ $i == 3 ]
    then
       exit
    fi

    echo $i
done

echo aaaaaaaa
```


&emsp;执行结果：

```
[root@133 ~]# sh test1.sh
1
1
2
2
3
aaaaaaaa
[root@133 ~]# vim test1.sh
[root@133 ~]# sh test1.sh
1
1
2
2
3
4
4
5
5
aaaaaaaa
[root@133 ~]# vim test1.sh
[root@133 ~]# sh test1.sh
1
1
2
2
3
```
