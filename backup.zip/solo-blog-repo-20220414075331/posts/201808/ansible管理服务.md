title: ansible 管理服务
date: '2018-08-05 12:11:44'
updated: '2018-08-05 12:11:44'
tags: [ansible, 自动化运维]
permalink: /articles/2018/08/05/1533442304832.html
---
# ansible 管理服务
&emsp;模块 yum

&emsp;&emsp;安装一个包

```
[root@server ~]# ansible client.test.com -m yum -a "name=httpd"
```


&emsp;在name后面还可以加上state=installed，不加也能安装

&emsp;&emsp;管理服务 service 模块

```
[root@server ~]# ansible client.test.com -m service -a "name=httpd state=started enabled=no"    //启动服务，不开机启动

client.test.com | SUCCESS => {

    "changed": true,

    "enabled": false,

    "name": "httpd",

    "state": "started"

}


[root@server ~]# ansible client.test.com -m service -a "name=httpd state=stopped enabled=yes"

client.test.com | SUCCESS => {

    "changed": true,

    "enabled": true,

    "name": "httpd",

    "state": "stopped"

}
```




&emsp;ansible文档的使用

&emsp;列出所有模块

```
[root@server ~]# ansible-doc -l
```


&emsp;列出指定模块

```
[root@server ~]# ansible-doc service
```
