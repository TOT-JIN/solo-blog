title: 【CDH6】安装 Hive
date: '2020-12-20 21:53:47'
updated: '2020-12-20 22:06:51'
tags: [大数据, Hadoop, CDH, Hive]
permalink: /articles/2020/12/20/1608472427089.html
---
# 安装 Hive

1. 选择集群，添加 Hive 服务![image20201218151530182.png](https://b3logfile.com/file/2020/12/image20201218151530182-fda27f1c.png)![image20201218151823779.png](https://b3logfile.com/file/2020/12/image20201218151823779-5c2fe8fb.png)
2. 添加服务向导
   选择依赖（只有一项可供选择时则默认跳过），点击“继续”，选择默认角色配置即可：![image20201218152234397.png](https://b3logfile.com/file/2020/12/image20201218152234397-fa83a19f.png)
   点击“继续”之后，需要配置Hive依赖的mysql数据库，需要在cm-s1节点上连接mysql，执行创建数据库及分配权限语句：
   ```
   [root@cm-s1 ~]# mysql -hcm-s1 -pAz123456_ -e "create database hive DEFAULT CHARACTER SET utf8;grant all on hive.* TO 'hive'@'%' IDENTIFIED BY 'Az123456_';flush privileges;"
   ```
   在弹出的页面中选择数据库，填写用户名及密码，点击“测试连接”，测试数据库连接成功后，点击“继续”：![image20201218152517112.png](https://b3logfile.com/file/2020/12/image20201218152517112-101ea318.png)
   点击继续之后，设置hive的数据目录及端口，默认即可，点击继续之后等待Hive安装完成即可。![image20201218152608024.png](https://b3logfile.com/file/2020/12/image20201218152608024-5b971522.png)![image20201218152955862.png](https://b3logfile.com/file/2020/12/image20201218152955862-a1f71cdf.png)
