title: LAMP--Apache 配置防盗链
date: '2017-11-11 09:23:01'
updated: '2017-11-11 09:23:01'
tags: [lamp, httpd, 防盗链]
permalink: /articles/2017/11/11/1510363381673.html
---
# LAMP--Apache 配置防盗链
假设我们的网站域名是 [www.123.com](http://www.123.com/) ，某个图片地址是 [www.123.com/p_w_picpaths/111.jpg](http://www.123.com/p_w_picpaths/111.jpg) ，某个网站为了借用这张图而直接把这个地址放到那个网站上的话，他的用户可以直接从他的网站界面上查看这个图片，而实际上浏览这个图片是从我们的网站上访问的。这样，这个图片所产生的带宽开销由我们承担，但看这个图片的客户却是人家的。所以，为了避免别人盗我们的资源，需要把资源限制一下。

在对应虚拟主机配置文件中，添加如下语句：

```e-bash
[root@localhost ~]# vim /usr/local/apache2/conf/extra/httpd-vhosts.conf
    SetEnvIfNoCase Referer "^http://.*\.123\.com" local_ref
    SetEnvIfNoCase Referer ".*\.test\.com" local_ref
    SetEnvIfNoCase Referer "^$" local_ref
   <filesmatch "\.(txt|doc|mp3|zip|rar|jpg|gif|jpeg)">
    Order Allow,Deny
    Allow from env=local_ref
   </filesmatch>
```



说明：在这段配置中涉及到了一个名词 referer，它其实就是上次访问的网站链接。我们是根据来源链接做限制的，如果来源链接不是我们想要的，就直接拒绝，这就是防盗链的原理。
