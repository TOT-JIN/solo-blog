title: centos7上搭建bind9
date: '2016-09-17 11:45:24'
updated: '2016-09-17 11:45:24'
tags: [bind9]
permalink: /articles/2016/09/17/1474083924856.html
---
# centos7上搭建bind9
&emsp;&emsp;目的： 使用bind9的view功能完成按照来源IP区域解析不同的域名

&emsp;&emsp;安装： sudo yum install bind bind-utils

&emsp;&emsp; **主配置文件：/etc/named.conf**



```
//
// named.conf
//
// Provided by Red Hat bind package to configure the ISC BIND named(8) DNS
// server as a caching only nameserver (as a localhost DNS resolver only).
//
// See /usr/share/doc/bind*/sample/ for example named configuration files.
//
// See the BIND Administrator's Reference Manual (ARM) for details about the
// configuration located in /usr/share/doc/bind-{version}/Bv9ARM.html

include "/etc/named/views.acl.list";   //引入来源及目的IP列表文件

options {
    listen-on port 53 { 127.0.0.1; 192.168.0.160; };
#   listen-on-v6 port 53 { ::1; };
    directory   "/var/named";
    dump-file   "/var/named/data/cache_dump.db";
    statistics-file "/var/named/data/named_stats.txt";
    memstatistics-file "/var/named/data/named_mem_stats.txt";
    allow-query     { any; };
​
    /*
     - If you are building an AUTHORITATIVE DNS server, do NOT enable recursion.
     - If you are building a RECURSIVE (caching) DNS server, you need to enable
       recursion.
     - If your recursive DNS server has a public IP address, you MUST enable access
       control to limit queries to your legitimate users. Failing to do so will
       cause your server to become part of large scale DNS amplification
       attacks. Implementing BCP38 within your network would greatly
       reduce such attack surface
    */
    recursion yes;
    forwarders {
        114.114.114.114;
        119.29.29.29;
    };
    dnssec-enable yes;
    dnssec-validation yes;
    /* Path to ISC DLV key */
    bindkeys-file "/etc/named.iscdlv.key";
    managed-keys-directory "/var/named/dynamic";
    pid-file "/run/named/named.pid";
    session-keyfile "/run/named/session.key";
};

logging {
        channel default_debug {
                file "data/named.run";
                severity dynamic;
        };
};

#zone "." IN {
#   type hint;
#   file "named.ca";
#};
#include "/etc/named.rfc1912.zones";
include "/etc/named.root.key";
view "internal" {
    match-clients { internal; };
    match-destinations { any; };
    recursion yes;
    allow-query { any; };
    zone "." IN {
            type hint;
            file "named.ca";
    };
    include "/etc/named.rfc1912.zones";
    include "/etc/named/internal.conf";
};

view "other" {
    match-clients { any; };
    match-destinations { any; };
    recursion yes;
    allow-query { any; };
    zone "." IN {
            type hint;
            file "named.ca";
    };
    include "/etc/named.rfc1912.zones";
    include "/etc/named/named.conf.local";
};
```

&emsp;&emsp; **zone配置文件(internal): /etc/named/internal.conf**


```
zone "genee.cn" {
    type master;
    file "/etc/named/zones/db.internal.genee.cn"; # zone file path
};
zone "0.168.192.in-addr.arpa" {
    type master;
    file "/etc/named/zones/db.internal.0.168.192";  # 192.168.0.0/24 subnet
};

```


&emsp;&emsp; **zone配置文件(other): /etc/named/named.conf.local**


```
zone "genee.cn" {
    type master;
    file "/etc/named/zones/db.genee.cn"; # zone file path
};
zone "0.168.192.in-addr.arpa" {
    type master;
    file "/etc/named/zones/db.0.168.192";  # 192.168.0.0/24 subnet
};
```


&emsp;&emsp; **来源与目的IP列表文件：/etc/named/views.acl.list**

```
acl "internal" {
       192.168.0.160;
       192.168.0.37;
};

```


&emsp;&emsp; **正向域文件（internal）：/etc/named/zones/db.internal.genee.cn**

```
$TTL    604800
@       IN      SOA     bogon.genee.cn. ns1.genee.cn. (
              4     ; Serial
         604800     ; Refresh
          86400     ; Retry
        2419200     ; Expire
         604800 )   ; Negative Cache TTL
​
; name servers - NS records
        IN      NS      bogon.genee.cn.
        IN      NS      ns1.genee.cn.
​
; name servers - A records
bogon.genee.cn.     IN  A   192.168.0.160
ns1.genee.cn.       IN  A   192.168.0.160
​
; 192.168.0.0/24 - A records
servers.genee.cn.   IN  A   192.168.0.12
e153501.genee.cn.   IN  A   192.168.0.170
rum.genee.cn.       IN  A   192.168.0.6
demo.genee.cn.      IN  A   192.168.0.237
mail.genee.cn.      IN  A   192.168.0.22
```

&emsp;&emsp; **反向域文件（internal）：/etc/named/zones/db.internal.0.168.192**

```
$TTL    604800
@       IN      SOA     bogon.genee.cn. ns1.genee.cn. (
              4     ; Serial
         604800     ; Refresh
          86400     ; Retry
        2419200     ; Expire
         604800 )   ; Negative Cache TTL

; name servers - NS records
        IN      NS      bogon.genee.cn.
        IN      NS      ns1.genee.cn.
​
; PTR Records
12  IN  PTR servers.genee.cn.   ;192.168.0.22
170 IN  PTR e153501.genee.cn.   ;192.168.0.17
237 IN  PTR demo.genee.cn.      ;192.168.0.37
```

&emsp;&emsp; **正向域文件（other）:  /etc/named/zones/db.genee.cn**

```

$TTL    604800
@       IN      SOA     bogon.genee.cn. ns1.genee.cn. (
              4     ; Serial
         604800     ; Refresh
          86400     ; Retry
        2419200     ; Expire
         604800 )   ; Negative Cache TTL

; name servers - NS records
        IN      NS      bogon.genee.cn.
        IN      NS      ns1.genee.cn.
​
; name servers - A records
bogon.genee.cn.     IN  A   192.168.0.160
ns1.genee.cn.       IN  A   192.168.0.160
​
; 192.168.0.0/24 - A records
host1.bj1.example.com.        IN      A      10.11.0.101
host2.bj1.example.com.        IN      A      10.11.0.102
servers.genee.cn.   IN  A   192.168.0.22
e153501.genee.cn.   IN  A   192.168.0.17
reserva.genee.cn.   IN  A   192.168.0.22
rum.genee.cn.       IN  A   192.168.0.26
gordon.genee.cn.    IN  A   192.168.0.5
vodka.genee.cn.     IN  A   192.168.0.2
pms.genee.cn.       IN  A   192.168.0.2
wiki.genee.cn.      IN  A   192.168.0.2
demo.genee.cn.      IN  A   192.168.0.37
```

&emsp;&emsp; **反向域文件（other）:  /etc/named/zones/db.0.168.192**

```

$TTL    604800
@       IN      SOA     bogon.genee.cn. ns1.genee.cn. (
              4     ; Serial
         604800     ; Refresh
          86400     ; Retry
        2419200     ; Expire
         604800 )   ; Negative Cache TTL
​
; name servers - NS records
        IN      NS      bogon.genee.cn.
        IN      NS      ns1.genee.cn.
​
; PTR Records
22  IN  PTR servers.genee.cn.   ;192.168.0.22
17  IN  PTR e153501.genee.cn.   ;192.168.0.17
26  IN  PTR rum.genee.cn.       ;192.168.0.26
5   IN  PTR gordon.genee.cn.    ;192.168.0.5
2   IN  PTR vodka.genee.cn.     ;192.168.0.2
37  IN  PTR demo.genee.cn.      ;192.168.0.37
```
