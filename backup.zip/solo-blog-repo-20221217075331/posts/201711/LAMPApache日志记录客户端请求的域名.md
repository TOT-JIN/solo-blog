title: LAMP--Apache 日志记录客户端请求的域名
date: '2017-11-01 19:52:11'
updated: '2017-11-01 19:52:11'
tags: [lamp, httpd, 请求域名]
permalink: /articles/2017/11/01/1509537131673.html
---
# LAMP--Apache 日志记录客户端请求的域名
apache日志记录客户端请求的域名

http://www.apelearn.com/bbs/thread-1037-1-1.html

(出处: 【阿铭Linux】)




正常情况下，根本就没有必要记录这一项，毕竟咱们大都根据虚拟主机来设置相应的访问日志，但也有个别的情况，比如
ServerName *.abc.com  
这样泛解析的形式，所以有必要记录一下用户请求的域名到底是哪个。

而apache的LogFormat 中正好有一项值满足了这个需求。即 %V  这里是大写的V ,小写的v 记录的是咱们在虚拟主机中设置的ServerName ，这个的确是没有必要记录的。
