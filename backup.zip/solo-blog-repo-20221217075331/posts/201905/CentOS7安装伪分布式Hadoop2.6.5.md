title: CentOS7 安装伪分布式 Hadoop 2.6.5
date: '2019-05-17 09:09:45'
updated: '2019-05-17 09:09:45'
tags: [Hadoop, 伪分布式, hdfs, 大数据]
permalink: /articles/2019/05/17/1558055385791.html
---
# CentOS7 安装伪分布式 Hadoop 2.6.5

## 0.准备环境

单节点：

| 主机名 | CPU | 内存 | IP |
| --- | :-: | :-: | :-: |
| node0 | 1c | 2G | 10.4.96.3 |

### 配置安装环境

* 更改主机名为 node0
* 配置 ssh 秘钥验证，达到无需密码验证登录本节点 root 用户的效果(ssh root@10.4.96.3)
* 配置/etc/hosts 文件，通过 node0 即可域名解析到对应 IP (10.4.96.3)
* 配置正确的时区和时间同步服务
* 关闭防火墙

  ```bash
  [root@node0 ~]# vim /etc/selinux/config
  ...
  SELINUX=disabled
  ...
  [root@node0 ~]# setenforce 0
  [root@node0 ~]# getenforce
  Permissive
  [root@node0 ~]# systemctl stop firewalld
  [root@node0 ~]# systemctl disable firewalld
  ```

  ```bash
  [root@node0 default]# pwd
  /usr/java/default
  [root@node0 default]# tail -n5 /etc/profile

  #Java Environment variables
  export JAVA_HOME=/usr/java/default
  export CLASSPATH=.:$CLASSPATH:$JAVA_HOME/lib
  export PATH=$PATH:$JAVA_HOME/bin

  [root@node0 default]# source /etc/profile
  ```

  ```bash
  [root@node0 default]# which java
  /usr/bin/java
  [root@node0 default]# java -version
  java version "1.8.0_251"
  Java(TM) SE Runtime Environment (build 1.8.0_251-b08)
  Java HotSpot(TM) 64-Bit Server VM (build 25.251-b08, mixed mode)
  ```

## 1. Hadoop 应用部署

伪分布式安装需要单节点具备所有角色

| host | NN | SNN | DN |
| --- | :-: | :-: | :-: |
| node0 | * | * | * |

### 安装应用

下载 Hadoop 安装包到 `/usr/local/src` 目录下

> https://archive.apache.org/dist/hadoop/core/hadoop-2.6.5/hadoop-2.6.5.tar.gz

```bash
[root@node0 src]# ls
hadoop-2.6.5.tar.gz  jdk-8u251-linux-x64.rpm
```

创建安装目录

```bash
[root@node0 ~]# mkdir /opt/bigdata
```

分发到安装目录

```bash
[root@node0 ~]# cd /opt/bigdata/
[root@node0 bigdata]# tar zxf /usr/local/src/hadoop-2.6.5.tar.gz
[root@node0 bigdata]# ls
hadoop-2.6.5
[root@node0 bigdata]# chown -R root:root hadoop-2.6.5
```

配置环境变量

```bash
[root@node0 ~]# tail -n3 /etc/profile
#Hadoop Environment variables
export HADOOP_HOME=/opt/bigdata/hadoop-2.6.5
export PATH=$PATH:$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin
[root@node0 ~]# source /etc/profile
```

### 配置应用

配置 `hadoop-env.sh` 文件

```bash
[root@node0 hadoop]# pwd
/opt/bigdata/hadoop-2.6.5/etc/hadoop
[root@node0 hadoop]# vim hadoop-env.sh
...
export JAVA_HOME=/usr/java/default
```

配置 `core-site.xml` 文件

```xml
[root@node0 hadoop]# vim core-site.xml
...
<configuration>
    <!--指定namenode的地址-->
    <property>
        <name>fs.defaultFS</name>
        <value>hdfs://node0:9000</value>
    </property>
</configuration>
```

配置 `hdfs-site.xml` 文件

```xml
[root@node0 hadoop]# vim hdfs-site.xml
...
<configuration>
    <!--指定hdfs保存数据的副本数量-->
    <property>
        <name>dfs.replication</name>
        <value>1</value>
    </property>
    <!--指定NN保存元数据的位置-->
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>/var/bigdata/hadoop/local/dfs/name</value>
    </property>
    <!--指定DN保存block的位置-->
    <property>
        <name>dfs.datanode.data.dir</name>
        <value>/var/bigdata/hadoop/local/dfs/data</value>
    </property>
    <!--指定SNN的位置-->
    <property>
        <name>dfs.namenode.secondary.http-address</name>
        <value>node0:50090</value>
    </property>
    <!--指定SNN存储fsimage、editlog的位置-->
    <property>
        <name>dfs.namenode.checkpoint.dir</name>
        <value>/var/bigdata/hadoop/local/dfs/secondary</value>
    </property>
</configuration>
```

配置 DN 分布的节点，加入 `slaves` 文件

```bash
[root@node0 hadoop]# vim slaves
node0
```

## 2. 初始化和启动应用

对负责元数据的 NN 做格式化

```bash
[root@node0 ~]# hdfs namenode -format
```

```bash
[root@node0 ~]# ls /var/bigdata/hadoop/local/dfs/name/current/
fsimage_0000000000000000000  fsimage_0000000000000000000.md5  seen_txid  VERSION
```

启动 NN daemon 和 DN daemon：

```bash
[root@node0 ~]# start-dfs.sh
```

```bash
[root@node0 ~]# jps
6001 Jps
5628 NameNode
5742 DataNode
5886 SecondaryNameNode
[root@node0 ~]# ls /var/bigdata/hadoop/local/dfs/
data  name  secondary
```

访问 NN 的 web 页面

http://10.4.96.3:50070/
