title: LAMP--Apache 用户认证
date: '2017-10-21 19:12:31'
updated: '2017-10-21 19:12:31'
tags: [lamp, httpd, 认证]
permalink: /articles/2017/10/21/1508584351673.html
---
# LAMP--Apache 用户认证
在日常管理过程中，不免有些特殊的访问，为了增加安全，可以给它设置一个用户认证机制。比如discuz论坛，它的管理后台本身就有密码，但为了更加安全，可以设置一层用户认证，让某些目录不能被随意访问。

```e-bash
[root@localhost ~]# vim /usr/local/apache2/conf/extra/httpd-vhosts.conf
```



在对应的虚拟主机配置中加入如下配置：

```e-bash
<VirtualHost *:80>
    DocumentRoot "/data/www"
    ServerName www.123.com
  <Directory /data/www/admin.php>
  AllowOverride AuthConfig
  AuthName "Please input the passwd"
  AuthType Basic
  AuthUserFile /data/.htpasswd
  require valid-user
  </Directory>
</VirtualHost>
```



说明：首先指定对哪个目录进行验证，AuthName 自定义，显示在输入密码框的服务器提示栏，AuthUserFile 指定用户密码文件在哪里。

创建进行验证的用户，首次创建需要 -c 选项，目的是为了创建/data/.htpasswd 这个文件，再次创建不能加-c，否则会把之前的覆盖掉。回车输入设定的密码。

```e-bash
[root@localhost ~]# /usr/local/apache2/bin/htpasswd -c /data/.htpasswd test
New password:
Re-type new password:
Adding password for user test
```



重启apache服务

```e-bash
[root@localhost ~]# /usr/local/apache2/bin/apachectl -t
Syntax OK
[root@localhost ~]# /usr/local/apache2/bin/apachectl graceful
```



这里用 graceful 相当于是 reload 配置。
