title: mysql 备份与恢复
date: '2018-09-11 12:43:12'
updated: '2018-09-11 12:43:12'
tags: [mysql]
permalink: /articles/2018/09/11/1536640992812.html
---
# mysql 备份与恢复
&emsp;&emsp;**备份**

```
# mysqldump -uroot -ptest1 db > 1.sql
```


&emsp;&emsp;说明：-p 跟密码，中间不要有空格，后面的db是database名字，mysqldump出来的都是一些sql语句，所以用重定向符合 > 给定向到一个文件中。

&emsp;&emsp;**恢复**

```
# mysql -uroot -ptest1 db < 1.sql
```

&emsp;&emsp;说明：这个过程正好和前面备份是相对的，反向重定向。

&emsp;&emsp;**只备份一个表**

```
# mysqldump -uroot -ptest1 db tb1 > 2.sql
```

&emsp;&emsp;说明：db为数据库名字，tb1是表的名字，恢复时不用加表名了，只需要加数据库名字即可。

&emsp;&emsp;**备份时指定字符集**

```
# mysqldump -uroot -ptest1 --default-character-set=utf8 db > 1.sql
```

&emsp;&emsp;**恢复时也指定字符集**

```
# mysql -uroot -ptest1 --default-character-set=utf8 db < 1.sql
```

&emsp;&emsp;说明：指定字符集的目的是为了避免有的建表sql中并没有指定字符集，而直接使用 mysql 默认字符集的情况，这样会乱码。
