title: LAMP--php 安装扩展模块
date: '2017-12-18 18:31:13'
updated: '2017-12-18 18:31:13'
tags: [lamp, php, 扩展模块]
permalink: /articles/2017/12/18/1513593073673.html
---
# LAMP--php 安装扩展模块
php 和 apache 类似，核心文件为 **/usr/local/php/bin/php**，针对 apache 的是**/usr/local/apache2/modules/libphp5.so** 模块。这两个文件是核心，在编译 php 时会让它提前支持一些功能，比如支持 mysql ，这个功能其实是 php 的一个模块，只不过这个模块是直接和 php 或 libphp5.so 文件编译在一起的。当编译完 php 后，发现还需要让 php 支持另外的模块，这时候可以重新编译 php，加上配置参数，或者直接编译出一个独立的模块文件，然后让 php 去调用它。下面编译 memcache ：

（1）下载 memcache 源码包

```e-bash
[root@localhost src]# wget http://www.lishiming.net/data/p_w_upload/forum/memcache-2.2.3.tgz
```



（2）安装

```e-bash
[root@localhost src]# tar zxvf memcache-2.2.3.tgz
[root@localhost src]# cd memcache-2.2.3
[root@localhost memcache-2.2.3]# /usr/local/php/bin/phpize
```



说明：这一步是借助 php 的 phpize 工具生成 configure 文件。在这一步可能会遇到一些错误：

```
Cannot find autoconf. Please check your autoconf installation and the

$PHP_AUTOCONF environment variable. Then, rerun this script.


[root@localhost memcache-2.2.3]# yum install -y autoconf

```

```
         还有 Cannot find config.m4 ，yum install -y m4。
```

继续：


```e-bash
[root@localhost memcache-2.2.3]# ./configure --with-php-config=/usr/local/php/bin/php-config
[root@localhost memcache-2.2.3]# make
[root@localhost memcache-2.2.3]# echo $?
0
[root@localhost memcache-2.2.3]# make install
Installing shared extensions:     /usr/local/php/lib/php/extensions/no-debug-non-zts-20131226/
[root@localhost memcache-2.2.3]# echo $?
0
[root@localhost memcache-2.2.3]# cp modules/memcache.so /usr/local/php/ext/
```



说明：当 make install 后会生成一个 memcache.so 的模块文件，我们要用的就是它。然后把 memcache.so 拷贝至 php 的 extension_dir 下。查看 php extension_dir 的方法是“/usr/local/php/bin/php -i |grep extension_dir”，修改 extension_dir 的方法是，编辑 php.ini 文件，修改如下：

```e-bash
[root@localhost ~]# vim /usr/local/php/etc/php.ini
extension_dir = "/usr/local/php/ext"
extension=memcache.so
```



保存后可以利用 “/usr/local/php/bin/php -m ”命令检测和查看具体的模块，如果有 memcache 说明配置成功。
