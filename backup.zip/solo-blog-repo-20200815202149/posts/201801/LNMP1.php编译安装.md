title: LNMP--1.php 编译安装
date: '2018-01-02 18:31:13'
updated: '2018-01-02 18:31:13'
tags: [lnmp, php, 编译安装]
permalink: /articles/2018/01/02/1514889073733.html
---
# LNMP--1.php 编译安装
&emsp;&emsp;针对Nginx的php安装和针对apache的php安装是有区别的，因为Nginx中的php是以fastcgi的方式结合nginx的。可以理解为nginx代理了php的fastcgi，而apache是把php作为自己的模块来调用的。

&emsp;&emsp;下载地址：官方 [http://www.php.net/downloads.php](http://www.php.net/downloads.php)  镜像 [http://mirrors.sohu.com/php/php-5.6.10.tar.gz](http://mirrors.sohu.com/php/php-5.6.10.tar.gz)

&emsp;（1）下载源码包

```
[root@localhost ~]# cd /usr/local/src/

[root@localhost src]# wget http://mirrors.sohu.com/php/php-5.6.10.tar.gz
```


&emsp;（2）解压源码包，创建账号

```
[root@localhost src]# tar zxf php-5.6.10.tar.gz

[root@localhost src]# useradd -s /sbin/nologin php-fpm
```


&emsp;&emsp;该账号用来运行 php-fpm 服务，在 LNMP 环境中，php 是以一个服务来提供服务的。

&emsp;（3）配置编译选项

```
[root@localhost php-5.6.10]# ./configure \

--prefix=/usr/local/php \

--with-config-file-path=/usr/local/php/etc \

--enable-fpm \

--with-fpm-user=php-fpm \

--with-fpm-group=php-fpm \

--with-mysql=/usr/local/mysql \

--with-mysql-sock=/tmp/mysql.sock \

--with-libxml-dir \

--with-gd \

--with-jpeg-dir \

--with-png-dir \

--with-freetype-dir \

--with-iconv-dir \

--with-zlib-dir \

--with-mcrypt \

--enable-soap \

--enable-gd-native-ttf \

--enable-ftp \

--enable-mbstring \

--enable-exif \

--enable-zend-multibyte \

--disable-ipv6 \

--with-pear \

--with-curl \

--with-openssl

```

&emsp;&emsp;错误信息：

```
configure: error: Please reinstall the libcurl distribution -

    easy.h should be in <curl-dir>/include/curl/
```


&emsp;&emsp;解决方法：

```
# yum install -y libcurl-devel
```


&emsp;&emsp;错误：

```
configure: error: jpeglib.h not found.

# yum install -y libjpeg-devel
```


```
configure: error: png.h not found.

# yum install -y libpng-devel
```


&emsp;（4）编译 PHP

```
[root@localhost php-5.6.10]# make

[root@localhost php-5.6.10]# echo $?

0
```




&emsp;（5）安装 PHP

```
[root@localhost php-5.6.10]# make install

[root@localhost php-5.6.10]# echo $?

0

```

&emsp;（6）修改配置文件

```
[root@localhost php-5.6.10]# cp php.ini-production /usr/local/php/etc/php.ini

[root@localhost php-5.6.10]# vim /usr/local/php/etc/php-fpm.conf
```


&emsp;&emsp;写入：

```
[global]

pid = /usr/local/php/var/run/php-fpm.pid

error_log = /usr/local/php/var/log/php-fpm.log

[www]

listen = /tmp/php-fcgi.sock

user = php-fpm

group = php-fpm

listen.owner = nobody

listen.group = nobody

pm = dynamic

pm.max_children = 50

pm.start_servers = 20

pm.min_spare_servers = 5

pm.max_spare_servers = 35

pm.max_requests = 500

rlimit_files = 1024
```


&emsp;&emsp;检查配置是否正确：

```
[root@localhost php-5.6.10]# /usr/local/php/sbin/php-fpm -t

[29-Jun-2016 00:17:57] NOTICE: configuration file /usr/local/php/etc/php-fpm.conf test is successful
```


&emsp;（7）启动 php-fpm

&emsp;&emsp;拷贝启动脚本到 /etc/init.d/ 下

```
[root@localhost php-5.6.10]# cp /usr/local/src/php-5.6.10/sapi/fpm/init.d.php-fpm /etc/init.d/php-fpm

[root@localhost php-5.6.10]# chmod 755 /etc/init.d/php-fpm

[root@localhost php-5.6.10]# chkconfig --add php-fpm

[root@localhost php-5.6.10]# chkconfig php-fpm on

[root@localhost php-5.6.10]# service php-fpm start

Starting php-fpm  done

[root@localhost php-5.6.10]# ps aux|grep php-fpm

root     27263  2.6  0.4 109060  4880 ?        Ss   00:24   0:00 php-fpm: master process (/usr/local/php/etc/php-fpm.conf)

php-fpm  27264  0.0  0.4 109060  4348 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27265  0.0  0.4 109060  4348 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27266  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27267  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27268  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27269  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27270  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27271  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27272  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27273  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27274  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27275  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27276  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27277  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27278  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27279  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27280  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27281  0.0  0.4 109060  4352 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27282  0.0  0.4 109060  4356 ?        S    00:24   0:00 php-fpm: pool www

php-fpm  27283  0.0  0.4 109060  4356 ?        S    00:24   0:00 php-fpm: pool www

root     27285  0.0  0.0 103328   868 pts/1    S+   00:24   0:00 grep php-fpm
```
