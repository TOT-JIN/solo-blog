title: LAMP--1.Mysql 安装
date: '2017-10-02 18:29:56'
updated: '2017-10-02 18:29:56'
tags: [lamp, mysql]
permalink: /articles/2017/10/02/1506940196673.html
---
# LAMP--1.Mysql 安装
安装 Mysql 有两种选择，一是源代码安装，二是安装二进制面编译包，为了省时选用第二种。Mysql 安装包可以在Mysql的官网（http://dev.mysql.com/downloads/）下载，有i686和x86_64两个版本选择。我习惯在镜像网站上下载，比如搜狐的开源镜像网站（http://mirrors.sohu.com）。

**下载软件包**

免编译二进制包认准 glibc ，可通过 uname -i 获得linux是多少位的。

```e-bash
[root@localhost ~]# cd /usr/local/src/
[root@localhost ~]# wget http://mirrors.sohu.com/mysql/MySQL-5.1/mysql-5.1.73-linux-x86_64-glibc23.tar.gz
```



**初始化**

```e-bash
[root@localhost src]# ls
mysql-5.1.73-linux-x86_64-glibc23.tar.gz
[root@localhost src]# tar -zxvf mysql-5.1.73-linux-x86_64-glibc23.tar.gz
[root@localhost src]# ls
mysql-5.1.73-linux-x86_64-glibc23  mysql-5.1.73-linux-x86_64-glibc23.tar.gz
[root@localhost src]# mv mysql-5.1.73-linux-x86_64-glibc23 /usr/local/mysql
[root@localhost src]# useradd -s /sbin/nologin mysql            //建立 mysql 用户
[root@localhost src]# cd /usr/local/mysql
[root@localhost mysql]# mkdir -p /data/mysql                 //创建 datadir，数据库文件会放到这里面
[root@localhost mysql]# chown -R mysql:mysql /data/mysql       //更改权限
[root@localhost mysql]# ls -dl /data/mysql
drwxr-xr-x 2 mysql mysql 4096 5月  17 14:49 /data/mysql
[root@localhost mysql]# ./scripts/mysql_install_db --user=mysql --datadir=/data/mysql
```



--user 定义数据库的所属主， --datadir 定义数据库安装到哪里。如果看到两个“OK”说明执行成功。我遇到了一个问题：

```e-bash
Installing MySQL system tables..../bin/mysqld: error while loading shared libraries: libaio.so.1: cannot open shared object file: No such file or directory
[root@localhost mysql]# yum install -y libaio
```



需要使用 yum install -y libaio 解决。

**配置 mysql**

拷贝配置文件

```e-bash
[root@localhost mysql]# cp support-files/my-large.cnf /etc/my.cnf
```


拷贝启动脚本文件并修改其属性

```e-bash
[root@localhost mysql]# cp support-files/mysql.server /etc/init.d/mysqld
[root@localhost mysql]# chmod 755 /etc/init.d/mysqld
```



修改启动脚本

```e-bash
[root@localhost mysql]# vim /etc/init.d/mysqld
```



需要修改的地方是 datadir=/data/mysql

```e-bash
[root@localhost mysql]# chkconfig --add mysqld
[root@localhost mysql]# chkconfig mysqld on
[root@localhost mysql]# service mysqld start
Starting MySQL.. SUCCESS!
```



如果启动不了，到 /data/mysql/ 下查看错误日志，这个日志通常是主机名.err。检查mysql是否启动的命令为：

```e-bash
[root@localhost mysql]# ps aux |grep mysqld
root      4231  0.0  0.1  11304  1496 pts/1    S    16:00   0:00 /bin/sh /usr/local/mysql/bin/mysqld_safe --datadir=/data/mysql --pid-file=/data/mysql/localhost.localdomain.pid
mysql     4346  0.6 44.7 1011204 452716 pts/1  Sl   16:00   0:01 /usr/local/mysql/bin/mysqld --basedir=/usr/local/mysql --datadir=/data/mysql --plugin-dir=/usr/local/mysql/lib/plugin --user=mysql --log-error=/data/mysql/localhost.localdomain.err --pid-file=/data/mysql/localhost.localdomain.pid
root      4385  0.0  0.0 103320   904 pts/1    S+   16:04   0:00 grep mysqld
```
