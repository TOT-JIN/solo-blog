title: CentOS7 安装完全分布式 Hadoop 2.6.5
date: '2019-05-18 09:09:45'
updated: '2019-05-18 09:09:45'
tags: [Hadoop, 分布式, hdfs, 大数据]
permalink: /articles/2019/05/18/1558141785733.html
---
# CentOS7 安装完全分布式 Hadoop 2.6.5

分布式环境：

| node01 | node02 | node03 | node04 |
| --- | --- | --- | --- |
| centos7 | centos7 | centos7 | centos7 |
| 1c | 1c | 1c | 1c |
| 2G | 1G | 1G | 1G |
| 10.4.96.4 | 10.4.96.5 | 10.4.96.6 | 10.4.96.7 |

## 0.初始化三个节点

### 配置环境变量

* 更改主机名分别为 node01、node02、node03、node04
* 配置 ssh 秘钥验证，达到任一节点无需密码验证登录其他站点 root 用户的效果
* 配置/etc/hosts 文件，使任一节点通过 node01、node02、node03、node04 即可域名解析到对应节点 IP
* 关闭防火墙

  ```bash
  [root@node01 ~]# for i in `seq 1 4`;do ssh root@node0$i "sed -i 's/^SELINUX=.*/SELINUX=disabled/' /etc/selinux/config;grep 'SELINUX=disabled' /etc/selinux/config";done

  [root@node01 ~]# for i in `seq 1 4`;do ssh root@node0$i "setenforce 0;getenforce";done

  [root@node01 ~]# for i in `seq 1 4`;do ssh root@node0$i "systemctl stop firewalld;systemctl disable firewalld";done
  ```

  ```bash
  [root@node01 default]# pwd
  /usr/java/default
  [root@node01 default]# tail -n5 /etc/profile

  #Java Environment variables
  export JAVA_HOME=/usr/java/default
  export CLASSPATH=.:$CLASSPATH:$JAVA_HOME/lib
  export PATH=$PATH:$JAVA_HOME/bin

  [root@node01 default]# source /etc/profile
  [root@node01 ~]# for i in `seq 1 4`;do scp /etc/profile root@node0$i:/etc/profile;done
  [root@node01 ~]# for i in `seq 1 4`;do ssh root@node0$i "source /etc/profile";done
  ```

  ```bash
  [root@node01 ~]# for i in `seq 1 4`;do ssh root@node0$i "java -version";done
  ```

## 1. Hadoop 应用部署

完全分布式部署要求节点扮演角色：

| host | NN | SNN | DN |
| --- | :-: | :-: | :-: |
| node01 | * |   |   |
| node02 |   | * | * |
| node03 |   |   | * |
| node04 |   |   | * |

### 安装应用

> https://archive.apache.org/dist/hadoop/core/hadoop-2.6.5/hadoop-2.6.5.tar.gz

创建安装目录

```bash
[root@node01 ~]# for i in `seq 1 4`;do ssh root@node0$i "mkdir -p /opt/bigdata";done
```

分发到安装目录

```bash
[root@node01 ~]# for i in `seq 1 4`;do ssh root@node0$i "curl https://archive.apache.org/dist/hadoop/core/hadoop-2.6.5/hadoop-2.6.5.tar.gz | tar -C /opt/bigdata -zxf -";done
```

更改应用文件属主属组

```bash
[root@node01 ~]# for i in `seq 1 4`;do ssh root@node0$i "chown -R root:root /opt/bigdata/hadoop-2.6.5";done
```

配置环境变量

```bash
[root@node01 ~]# tail -n3 /etc/profile
#Hadoop Environment variables
export HADOOP_HOME=/opt/bigdata/hadoop-2.6.5
export PATH=$PATH:$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin
[root@node01 default]# source /etc/profile
[root@node01 default]# which hdfs
```

分发环境配置文件

```bash
[root@node01 ~]# for i in `seq 1 4`;do scp /etc/profile root@node0$i:/etc/profile;done
[root@node01 ~]# for i in `seq 1 4`;do ssh root@node0$i "source /etc/profile;which hdfs";done
```

### 配置应用

配置 `hadoop-env.sh` 文件

```bash
[root@node01 hadoop]# pwd
/opt/bigdata/hadoop-2.6.5/etc/hadoop
[root@node01 hadoop]# vim hadoop-env.sh
...
export JAVA_HOME=/usr/java/default
```

配置 `core-site.xml` 文件

```xml
[root@node01 hadoop]# vim core-site.xml
...
<configuration>
    <!--指定namenode的地址-->
    <property>
        <name>fs.defaultFS</name>
        <value>hdfs://node01:9000</value>
    </property>
</configuration>
```

配置 `hdfs-site.xml` 文件

```xml
[root@node01 hadoop]# vim hdfs-site.xml
...
<configuration>
    <!--指定hdfs保存数据的副本数量-->
    <property>
        <name>dfs.replication</name>
        <value>3</value>
    </property>
    <!--指定NN保存元数据的位置-->
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>/var/bigdata/hadoop/full/dfs/name</value>
    </property>
    <!--指定DN保存block的位置-->
    <property>
        <name>dfs.datanode.data.dir</name>
        <value>/var/bigdata/hadoop/full/dfs/data</value>
    </property>
    <!--指定SNN的位置-->
    <property>
        <name>dfs.namenode.secondary.http-address</name>
        <value>node02:50090</value>
    </property>
    <!--指定SNN存储fsimage、editlog的位置-->
    <property>
        <name>dfs.namenode.checkpoint.dir</name>
        <value>/var/bigdata/hadoop/full/dfs/secondary</value>
    </property>
</configuration>
```

配置 DN 分布的节点，加入 `slaves` 文件

```bash
[root@node01 hadoop]# vim slaves
node02
node03
node04
```

分发配置文件到其他节点

```bash
[root@node01 hadoop]# for i in `seq 2 4`;do scp hadoop-env.sh root@node0$i:/opt/bigdata/hadoop-2.6.5/etc/hadoop/hadoop-env.sh;done
[root@node01 hadoop]# for i in `seq 2 4`;do scp core-site.xml root@node0$i:/opt/bigdata/hadoop-2.6.5/etc/hadoop/core-site.xml;done
[root@node01 hadoop]# for i in `seq 2 4`;do scp hdfs-site.xml root@node0$i:/opt/bigdata/hadoop-2.6.5/etc/hadoop/hdfs-site.xml;done
[root@node01 hadoop]# for i in `seq 2 4`;do scp slaves root@node0$i:/opt/bigdata/hadoop-2.6.5/etc/hadoop/slaves;done
```

## 2. 初始化和启动应用

**这些操作只需在 node01 节点执行**

对负责元数据的 NN 做格式化

```bash
[root@node01 ~]# hdfs namenode -format
```

```bash
[root@node01 ~]# ls /var/bigdata/hadoop/full/dfs/name/current/
fsimage_0000000000000000000  fsimage_0000000000000000000.md5  seen_txid  VERSION
```

启动 NN daemon 和 DN daemon：

```bash
[root@node01 ~]# start-dfs.sh
```

```bash
[root@node01 ~]# jps
17104 Jps
16862 NameNode
```

```bash
[root@node02 ~]# jps
7588 DataNode
7756 Jps
7678 SecondaryNameNode
```

```bash
[root@node03 ~]# jps
17881 Jps
17722 DataNode
```

```bash
[root@node04 ~]# jps
7892 Jps
7756 DataNode
```

访问 NN 的 web 页面

http://10.4.96.4:50070/
