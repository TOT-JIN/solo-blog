title: screen 命令
date: '2016-08-20 08:45:12'
updated: '2016-08-20 08:45:12'
tags: [screen, cli]
permalink: /articles/2016/08/20/1471653912345.html
---
# screen 命令
&emsp;&emsp;长时间执行一个任务，要防止中途断网等意外情况使执行的任务中断了。把命令或脚本丢到后台运行也不保险。下面有两个解决方案。

&emsp;&emsp;**使用 nohup**



```
[root@localhost ~]# cat /usr/local/sbin/sleep.sh

#!/bin/bash

sleep 1000



[root@localhost ~]# nohup sh /usr/local/sbin/sleep.sh &

[1] 3735

[root@localhost ~]# nohup: 忽略输入并把输出追加到"nohup.out"
```


&emsp;&emsp;直接加一个“&”丢掉后台，在退出终端时很有可能这个脚本也会退出，在前面加上 nohup 就没有问题了，nohup 的作用就是不挂断地运行命令，把运行命令产生的日志都记录到了 nohup 文件里。



&emsp;&emsp;**使用 screen**

&emsp;&emsp;screen是一个可以在多个进程之间多路复用一个物理终端的窗口管理器。screen 中有会话的概念，用户可以在一个screen会话中创建多个screen窗口，在每一个screen窗口中就像操作一个真实的SSH连接窗口那样。

&emsp;&emsp;打开一个会话，直接输入screen命令然后回车，进入screen会话窗口。如果没有screen命令，使用 yum install -y screen 安装。

```
[root@localhost ~]# screen

[root@localhost ~]#
```


       
&emsp;&emsp;screen -ls 查看已经打开的screen会话。

```
[root@localhost ~]# screen -ls

There is a screen on:

        3761.pts-1.localhost    (Attached)

1 Socket in /var/run/screen/S-root.
```


&emsp;&emsp;Ctrl+a +d退出该screen会话，只是退出，并没有结束。结束的话 Ctrl+d或输入exit。

&emsp;&emsp;如果还想再登录某个screen会话，使用 screen -r [screen 编号]，这个编号就是上例中的3761 。当只有一个screen时，后面的编号是可以省略的。当长时间运行命令或脚本时，就打开一个screen会话，然后运行该任务，Ctrl +a+d退出会话，不影响终端窗口上的操作。

&emsp;&emsp;创建新的screen时，指定自定义名称：

```
[root@localhost ~]# screen -S test

[root@localhost ~]# screen -ls

There is a screen on:

        3803.test       (Attached)

1 Socket in /var/run/screen/S-root.



[root@localhost ~]# sh /usr/local/sbin/sleep.sh
```

&emsp;&emsp;要想进入该screen，可以直接 screen -r test：

```
[root@localhost ~]# screen -S test

[detached]

[root@localhost ~]# screen -r test

[root@localhost ~]# screen -ls

There is a screen on:

        3845.test       (Attached)

1 Socket in /var/run/screen/S-root.



[root@localhost ~]# sh /usr/local/sbin/sleep.sh
```
