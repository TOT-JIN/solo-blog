title: while 循环
date: '2016-10-12 21:41:43'
updated: '2016-10-12 21:41:43'
tags: [shell, while]
permalink: /articles/2016/10/12/1476279703856.html
---
# while 循环
while 循环常常用来写死循环脚本，用于监控某项服务。

简单的while脚本

```
[root@133 ~]# vim while.sh
#!/bin/bash

a=5

while [ $a -ge 1 ];do
  echo $a
  a=$[$a-1]
done
```


执行结果：

```
[root@133 ~]# sh while.sh
5
4
3
2
1
```

&emsp;
while循环的格式：

&emsp;while  条件; do
&emsp;&emsp;&emsp;command
&emsp;done

&emsp;
另外可以把循环条件用一个冒号代替，这样可以做到死循环：

&emsp;while :; do
&emsp;&emsp;&emsp;command
&emsp;&emsp;&emsp;sleep 3
&emsp;done

&emsp;
下面写一个判断系统负载的脚本：

```
[root@133 ~]# vim load.sh
#!/bin/bash

while :; do
    load=`uptime|awk '{print $(NF-2)}'|cut -d. -f1`
    if [ $load -gt 10 ];then
       echo "system load is high."|mail -s "system load" test1@163.com
    fi
    sleep 10
done
```


&emsp;&emsp;说明：uptime 命令是用来查看系统负载的，我们用awk截取倒数第三段，也即是平均 1 分钟的系统负载，然后只取整数部分。如果负载高于 10 则会发邮件告警。每隔10秒检查一次。但是，如果系统负载一直高于10，那么将会出现每隔10s发一次邮件的窘况，所以要采取手段避免这种情况发生。
