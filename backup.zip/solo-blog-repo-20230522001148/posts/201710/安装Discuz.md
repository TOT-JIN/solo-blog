title: 安装 Discuz！
date: '2017-10-14 09:07:51'
updated: '2017-10-14 09:07:51'
tags: [lamp, Discuz]
permalink: /articles/2017/10/14/1507943271673.html
---
# 安装 Discuz！
下载 discuz！

```e-bash
[root@localhost ~]# mkdir /data/www
[root@localhost ~]# cd /data/www
[root@localhost www]# wget http://download.comsenz.com/DiscuzX/3.2/Discuz_X3.2_SC_GBK.zip
[root@localhost www]# ls
Discuz_X3.2_SC_GBK.zip
[root@localhost www]# unzip Discuz_X3.2_SC_GBK.zip
[root@localhost www]# mv upload/* .
```



配置第一个虚拟主机

删除 httpd.conf 中的“#Include conf/extra/httpd-vhosts.conf”这行前面的＃号

```e-bash
[root@localhost conf]# pwd
/usr/local/apache2/conf
[root@localhost conf]# ls
extra  httpd.conf  httpd.conf.bak  magic  mime.types  original
[root@localhost conf]# vim httpd.conf
# Virtual hosts
Include conf/extra/httpd-vhosts.conf
```



然后编辑该配置文件

```e-bash
[root@localhost conf]# vim /usr/local/apache2/conf/extra/httpd-vhosts.conf
```



在最后面，加入如下配置：

```e-bash
<VirtualHost *:80>
    DocumentRoot "/data/www"
    ServerName www.123.com
</VirtualHost>
```



重启 apache 服务

```e-bash
[root@localhost conf]# /usr/local/apache2/bin/apachectl -t
Syntax OK
[root@localhost conf]# /usr/local/apache2/bin/apachectl restart
```



配置 mysql ，给 Discuz! 增加一个账户

给 mysql root 账户设置密码，然后命令行进入 mysql ，创建新的库，并创建一个新的账号对该库有所有的权限：

```e-bash
[root@localhost ~]# /usr/local/mysql/bin/mysql -uroot
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 1
Server version: 5.6.31 MySQL Community Server (GPL)
Copyright (c) 2000, 2016, Oracle and/or its affiliates. All rights reserved.
Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.
Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.
mysql> create database discuz;
Query OK, 1 row affected (0.06 sec)
mysql> grant all on discuz.* to 'test'@'localhost' identified by 'test123';
Query OK, 0 rows affected (0.05 sec)
mysql> quit
Bye
```



这样就创建了一个库discuz，又创建了一个用户 test ，密码是 test123 。

安装 Discuz!

"www.123.com" 这个域名是随便定义的，所以不能直接访问，需要绑定hosts，hosts在windows和linux上都是存在的，可以把一个域名指向到一个 ip 上。windows 下的hosts文件路径是在：C:\windows\system32\drivers\etc\hosts，用记事本打开它，然后增加一行，保存：

192.168.56.128   [www.123.com](http://www.123.com/)

这里的 192.168.56.128 是我虚拟机的 ip 。

在浏览器输入：

[http://www.123.com/install/](http://www.123.com/install/)

根据提示，修改对应目录的权限。

```e-bash
[root@localhost ~]# cd /data/www
[root@localhost www]# chown -R daemon:daemon data uc_server/data uc_client/data config
```



让这几个目录支持apache运行账号可写，daemon 就是 apache 的运行账号，在 /usr/local/apache2/conf/httpd.conf 中用 User 和 Group 定义的。

[![wKioL1d7As3j9BGzAACH_038yTY101.png](https://b3logfile.com/file/2020/06/solofetchupload1573963480958343051-829403a3.png "2.PNG")](https://s4.51cto.com/wyfs02/M01/83/B1/wKioL1d7As3j9BGzAACH_038yTY101.png)

[![wKiom1d7As6xykElAAC100KGYKs146.png](https://b3logfile.com/file/2020/06/solofetchupload1374358505642653085-a7179616.png "3.PNG")](https://s4.51cto.com/wyfs02/M01/83/B2/wKiom1d7As6xykElAAC100KGYKs146.png)

数据库名就是上面在mysql创建的数据库。数据库用户名和密码就是上面mysql中创建的用户和密码。管理员密码是discuz内部的。点下一步后，就会看到安装数据库的过程，稍后就弹出“Discuz 应用中心”的界面，不过不需要安装任何应用，直接点右下角“点此访问”，成功安装discuz论坛。
