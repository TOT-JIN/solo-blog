title: LAMP--默认虚拟主机
date: '2017-10-21 19:30:51'
updated: '2017-10-21 19:30:51'
tags: [lamp, 虚拟主机]
permalink: /articles/2017/10/21/1508585451673.html
---
# LAMP--默认虚拟主机
这个默认虚拟主机就是配置文件里的第一个虚拟主机。关于默认虚拟主机有个特点，凡是解析到这台机器的域名，不管是什么域名，只有在配置文件中没有这个域名的配置，都会访问到这个默认主机上来。直接用ip访问，都会访问到这个主机上，为了避免乱解析，所以把第一个默认的主机给禁掉。

```e-bash
[root@localhost ~]# vim /usr/local/apache2/conf/extra/httpd-vhosts.conf
```



在首个虚拟主机位置添加配置：

```e-bash
<VirtualHost *:80>
    DocumentRoot "/tmp/tmp"
    ServerName tmp.com
  <Directory /tmp/tmp>
  Order allow,deny
  Deny from all
  </Directory>
</VirtualHost>
```



创建配置中提到的目录，不然检查配置是否正确时会提示该目录不存在，起到禁用功能的是allow，deny语句。

```e-bash
[root@localhost ~]# mkdir /tmp/tmp
```



重新加载配置

```e-bash
[root@localhost ~]# /usr/local/apache2/bin/apachectl -t
Syntax OK
[root@localhost ~]# /usr/local/apache2/bin/apachectl graceful
```



这时再用ip访问就会提示：

**Forbidden**

You don't have permission to access / on this server.
