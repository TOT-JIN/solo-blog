title: 分区表 fstab
date: '2016-09-21 14:20:25'
updated: '2016-09-21 14:20:25'
tags: [fstab, Linux]
permalink: /articles/2016/09/21/1474438825856.html
---
# 分区表 fstab
**系统启动时会挂载分区，就是通过这个/etc/fstab配置文件配置的。**



```bash
[root@localhost ~]# cat /etc/fstab

#

# /etc/fstab

# Created by anaconda on Tue May 10 16:55:48 2016

#

# Accessible filesystems, by reference, are maintained under '/dev/disk'

# See man pages fstab(5), findfs(8), mount(8) and/or blkid(8) for more info

#

UUID=f77b4c47-ca03-43f9-b420-cc0be633446a /                       ext4    defaults        1 1

UUID=82d89195-8a63-4d3f-944f-03b308893c3f /boot                   ext4    defaults        1 2

UUID=38631717-1603-4987-a781-9e378950bc48 swap                    swap    defaults        0 0

tmpfs                   /dev/shm                tmpfs   defaults        0 0

devpts                  /dev/pts                devpts  gid=5,mode=620  0 0

sysfs                   /sys                    sysfs   defaults        0 0

proc                    /proc                   proc    defaults        0 0
```



第一列就是分区的标识，可以写分区的LABEL，也可以写分区的UUID，也可以写分区名。

第二列是挂载点

第三列是分区的格式

第四列是mount的挂载参数，一般情况下，直接写defaults即可

第五列的数字表示是否被dump备份，是的话为1，不是为0

第六列是开机时是否自检磁盘。1，2都表示检测，0表示不检测。但1,2表示不同的优先级，1更高。所以/ 分区必须设为1，而且整个fstab只允许出现一个1，若有多个分区需要检测，那么都设为2。



第四列的常用选项：

async/sync：async表示和磁盘和内存不同步，系统每隔一段时间把内存数据写入磁盘中，而sync则会时时同步内存和磁盘中的数据；

auto/noauto：开机自动挂载/不自动挂载；

default：按照大多数永久文件系统的缺省值设置挂载定义，它包括了rw，suid，dev，exec，auto，nouser，async

ro：按只读权限挂载

rw：按可读可写权限挂载

exec/noexec：允许/不允许可执行文件执行，所以千万不要把根分区挂载为noexec，那样就无法使用系统了，只能重新做系统了

user/nouser：允许/不允许root外的其他用户挂载分区，为了安全考虑，请用nouser

suid/nosuid：允许/不允许分区有suid属性，一般设置nosuid

usrquota：启动使用者磁盘配额模式，磁盘配额会针对用户限定他们使用的磁盘额度

grquota：启动群组磁盘配额模式



**下面来修改fstab这个文件，增加一行来挂载新增分区：**

```bash
LABEL=TEST              /newdir                 ext4    defaults        0 0

UUID=0fc004b1-f8f4-45e1-b290-12b0d167d017 /newdir6                ext4    defaults        0 0
```



**执行命令mount -a挂载分区表中所有的分区**

```
[root@localhost ~]# mount -a

[root@localhost ~]# df -h

Filesystem      Size  Used Avail Use% Mounted on

/dev/sda3        18G  1.6G   15G  10% /

tmpfs           495M     0  495M   0% /dev/shm

/dev/sda1       190M   27M  154M  15% /boot

/dev/sdb5       988M  1.3M  935M   1% /newdir

/dev/sdb6       988M  1.3M  935M   1% /newdir6
```



**mount命令的 -t 选项用来指定挂载的分区类型，默认不指定会自动识别，例：mount -t ext4 /dev/sdb5 /newdir**

**-o 选项用来指定挂载的分区有哪些特性，即fstab文件中第四列的信息**

```
[root@localhost ~]# mkdir /newdir/dir1

[root@localhost ~]# mount -o remount,ro,sync,noauto /dev/sdb5 /newdir

[root@localhost ~]# mkdir /newdir/dir2
```

mkdir: 无法创建目录"/newdir/dir2": 只读文件系统

**由于指定了ro参数，所以该分区只读了。通过mount命令也可以查看到/dev/sdb5有ro选项**

```
[root@localhost ~]# mount

/dev/sda3 on / type ext4 (rw)

proc on /proc type proc (rw)

sysfs on /sys type sysfs (rw)

devpts on /dev/pts type devpts (rw,gid=5,mode=620)

tmpfs on /dev/shm type tmpfs (rw)

/dev/sda1 on /boot type ext4 (rw)

none on /proc/sys/fs/binfmt_misc type binfmt_misc (rw)

/dev/sdb5 on /newdir type ext4 (ro,sync)

/dev/sdb6 on /newdir6 type ext4 (rw)
```

**下面重新挂载，恢复读写**

```
[root@localhost ~]# mount -o remount /dev/sdb5 /newdir

[root@localhost ~]# mkdir /newdir/dir2

[root@localhost ~]# ls /newdir

dir1  dir2  lost+found
```
