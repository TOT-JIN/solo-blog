title: yum 工具详解
date: '2016-12-11 11:12:45'
updated: '2016-12-11 11:12:45'
tags: [yum, Linux]
permalink: /articles/2016/12/11/1481425965856.html
---
# yum 工具详解
**yum 工具可以联网去下载所需要的 rpm 包，然后自动安装。在这个工程中如果要安装的rpm包有依赖关系，yum会帮我们解决掉这些依赖关系依次安装所有的rpm包。**



**列出所有可用的rpm包**

```e-bash
[root@localhost ~]# yum list |head -n 12
已加载插件：fastestmirror
Loading mirror speeds from cached hostfile
 * base: mirror.bit.edu.cn
 * epel: mirrors.aliyun.com
 * extras: mirrors.sina.cn
 * updates: mirror.bit.edu.cn
已安装的软件包
ConsoleKit.x86_64                           0.4.1-3.el6                  @anaconda-CentOS-201508042137.x86_64/6.7
ConsoleKit-libs.x86_64                      0.4.1-3.el6                  @anaconda-CentOS-201508042137.x86_64/6.7
ConsoleKit-x11.x86_64                       0.4.1-3.el6                  @anaconda-CentOS-201508042137.x86_64/6.7
GConf2.x86_64                               2.28.0-6.el6                 @anaconda-CentOS-201508042137.x86_64/6.7
MAKEDEV.x86_64                              3.24-6.el6                   @anaconda-CentOS-201508042137.x86_64/6.7
```



**从上例可以看到有@符号，代表着此rpm包已安装，未安装不会出现@。如果该rpm包已安装但需要升级则显示 updates。**



**搜索一个 rpm 包**

**命令  yum search [相关关键词]**

```e-bash
[root@localhost ~]# yum search vim
已加载插件：fastestmirror
Loading mirror speeds from cached hostfile
 * base: mirror.bit.edu.cn
 * epel: mirrors.aliyun.com
 * extras: mirrors.sina.cn
 * updates: mirror.bit.edu.cn
==================================================== N/S Matched: vim ====================================================
beakerlib-vim-syntax.noarch : Files for syntax highlighting BeakerLib tests in VIM editor
docker-io-vim.x86_64 : vim syntax highlighting files for docker
protobuf-vim.x86_64 : Vim syntax highlighting for Google Protocol Buffers descriptions
vim-X11.x86_64 : The VIM version of the vi editor for the X Window System
vim-clustershell.noarch : VIM files for ClusterShell
vim-common.x86_64 : The common files needed by any version of the VIM editor
vim-enhanced.x86_64 : A version of the VIM editor which includes recent enhancements
vim-filesystem.x86_64 : VIM filesystem layout
vim-minimal.x86_64 : A minimal version of the VIM editor
vim-halibut.noarch : Syntax file for the halibut manual tool
  Name and summary matches only, use "search all" for everything.
```



**还可以用 grep 过滤**

```e-bash
[root@localhost ~]# yum list |grep vim
vim-common.x86_64                           2:7.4.629-5.el6              @base
vim-enhanced.x86_64                         2:7.4.629-5.el6              @base
vim-filesystem.x86_64                       2:7.4.629-5.el6              @base
vim-minimal.x86_64                          2:7.4.629-5.el6              @anaconda-CentOS-201508042137.x86_64/6.7
beakerlib-vim-syntax.noarch                 1.11-1.el6                   epel
docker-io-vim.x86_64                        1.7.1-2.el6                  epel
protobuf-vim.x86_64                         2.3.0-9.el6                  epel
vim-X11.x86_64                              2:7.4.629-5.el6              base
vim-clustershell.noarch                     1.7.1-1.el6                  epel
vim-halibut.noarch                          1.0-2.20100504svn8934.el6    epel
```



   

**安装一个rpm包**

**命令 yum install [-y] [rpm包名]**

**如果不加 -y 选项，则会以与用户交互的方式安装。会询问是否安装，y/n**

```e-bash
[root@localhost ~]# yum install vim-X11
已加载插件：fastestmirror
设置安装进程
Loading mirror speeds from cached hostfile
 * base: mirror.bit.edu.cn
 * epel: mirrors.aliyun.com
 * extras: mirrors.sina.cn
 * updates: mirror.bit.edu.cn
解决依赖关系
--> 执行事务检查
---> Package vim-X11.x86_64 2:7.4.629-5.el6 will be 安装
--> 完成依赖关系计算
依赖关系解决
==========================================================================================================================
 软件包                     架构                      版本                                  仓库                     大小
==========================================================================================================================
正在安装:
 vim-X11                    x86_64                    2:7.4.629-5.el6                       base                    1.1 M
事务概要
==========================================================================================================================
Install       1 Package(s)
总下载量：1.1 M
Installed size: 2.5 M
确定吗？[y/N]：y
下载软件包：
vim-X11-7.4.629-5.el6.x86_64.rpm                                                                   | 1.1 MB     00:00
运行 rpm_check_debug
执行事务测试
事务测试成功
执行事务
Warning: RPMDB altered outside of yum.
  正在安装   : 2:vim-X11-7.4.629-5.el6.x86_64                                                                         1/1
  Verifying  : 2:vim-X11-7.4.629-5.el6.x86_64                                                                         1/1
已安装:
  vim-X11.x86_64 2:7.4.629-5.el6
完毕！
```



       

**卸载一个 rpm 包**

**命令 yum remove [-y] [rpm包名]**

```e-bash
[root@localhost ~]# yum remove vim-X11
已加载插件：fastestmirror
设置移除进程
解决依赖关系
--> 执行事务检查
---> Package vim-X11.x86_64 2:7.4.629-5.el6 will be 删除
--> 完成依赖关系计算
依赖关系解决
==========================================================================================================================
 软件包                     架构                      版本                                 仓库                      大小
==========================================================================================================================
正在删除:
 vim-X11                    x86_64                    2:7.4.629-5.el6                      @base                    2.5 M
事务概要
==========================================================================================================================
Remove        1 Package(s)
Installed size: 2.5 M
确定吗？[y/N]：y
下载软件包：
运行 rpm_check_debug
执行事务测试
事务测试成功
执行事务
  正在删除   : 2:vim-X11-7.4.629-5.el6.x86_64                                                                         1/1
  Verifying  : 2:vim-X11-7.4.629-5.el6.x86_64                                                                         1/1
删除:
  vim-X11.x86_64 2:7.4.629-5.el6
完毕！
```



**升级一个 rpm 包**

**命令 yum update [-y] [rpm 包]**

```e-bash
[root@localhost ~]# yum update libselinux
已加载插件：fastestmirror
设置更新进程
Loading mirror speeds from cached hostfile
 * base: mirror.bit.edu.cn
 * epel: mirrors.aliyun.com
 * extras: mirrors.sina.cn
 * updates: mirror.bit.edu.cn
不升级任何软件包
```



搭建本地 yum 仓库

挂载光盘

```e-bash
[root@localhost ~]# mount /dev/cdrom /mnt
```



删除 /etc/yum.repos.d 目录下所有的 repo 文件。先备份一个原有的。

```e-bash
[root@localhost ~]# cp -r /etc/yum.repos.d   /etc/yum.repos.d.bak
[root@localhost ~]# rm -rf /etc/yum.repos.d/*
```



创建新文件 dvd.repo

```e-bash
[root@localhost ~]# vim /etc/yum.repos.d/dvd.repo     //加入以下内容：
[dvd]
name=install dvd
baseurl=file:///mnt
enabled=1
gpgcheck=0
```



刷新 repos 生成缓存

```e-bash
[root@localhost ~]# yum makecache
```



如果不想使用本地yum源，需要删除/etc/yum.repos.d/dvd.repo文件，然后恢复原来的配置文件。

---

安装epel扩展源

    

使用yum安装rpm包时，经常会遇到一些包没有，这时候可以尝试安装epel的扩展源，这里有系统不自带的rpm包。

```e-bash
[root@localhost ~]# yum install -y epel-release
[root@localhost ~]# yum list
```



这时会有很多 epel 的 rpm 包。

---

yum 保留已经安装过的包



可以设置使 yum 保留已经下载的 rpm 包，供以后升级或重新安装时使用。

修改 /etc/yum.conf 即可：

```e-bash
           [main]
           cachedir=/home/soft1/yumcache
           keepcache=1
           debuglevel=2
```



cachedir是放置下载的包的地方，可以修改为自己想放置的位置

keepcache为1时表示保存已经下载的rpm包

---

yum 只获取 rpm 包不自动安装



使用 yum-downloadonly 插件

yum 有一个plugin 叫做yum-downloadonly，它就可以为用户实现只下载软件包的功能：

```e-bash
[root@localhost ~]# yum install yum-downloadonly
```



安装完成后， yum 就多了两个命令参数，分别是：

--downloadonly

--downloaddir=/path/to/dir

示例：

```e-bash
[root@localhost ~]# yum install vim --downloadonly --downloaddir=/var
```



就会把vim的安装包下载到/var目录下了。
