title: ansible playbook中的循环
date: '2018-08-06 09:43:14'
updated: '2018-08-06 09:43:14'
tags: [ansible, playbook, 自动化运维]
permalink: /articles/2018/08/06/1533519794832.html
---
# ansible playbook中的循环
&emsp;&emsp;例：

```
[root@server ansible]# vim loop.yml

---

- hosts: testhosts

  user: root

  tasks:

   - name: change mod for file

     file: path=/tmp/{{item}} mode=600 owner=root group=root

     with_items:

      - 1.txt

      - 2.txt

```

&emsp;&emsp;针对file模块来说，item是一个变量，那么根据设定item中的内容可以把执行过程看成一个循环。

&emsp;&emsp;执行结果：

```
[root@server ansible]# ansible-playbook loop.yml



PLAY [testhosts] ***************************************************************



TASK [setup] *******************************************************************

ok: [client.test.com]

ok: [127.0.0.1]



TASK [change mod for file] *****************************************************

changed: [client.test.com] => (item=1.txt)

changed: [127.0.0.1] => (item=1.txt)

changed: [client.test.com] => (item=2.txt)

changed: [127.0.0.1] => (item=2.txt)



PLAY RECAP *********************************************************************

127.0.0.1                  : ok=2    changed=1    unreachable=0    failed=0

client.test.com            : ok=2    changed=1    unreachable=0    failed=0
```


&emsp;&emsp;查看效果：

```
[root@server ansible]# ansible testhosts -m shell -a "ls -ld /tmp/{1.txt,2.txt}"

client.test.com | SUCCESS | rc=0 >>

-rw------- 1 root root 0 7月  11 01:28 /tmp/1.txt

-rw------- 1 root root 0 7月  11 01:28 /tmp/2.txt



127.0.0.1 | SUCCESS | rc=0 >>

-rw------- 1 root root 0 7月  11 01:28 /tmp/1.txt

-rw------- 1 root root 0 7月  11 01:28 /tmp/2.txt
```
