title: linux权限安全
date: '2017-11-26 20:14:32'
updated: '2017-11-26 20:14:32'
tags: [linux, 权限, 等保]
permalink: /articles/2017/11/26/1511698472856.html
---
# linux权限安全
## 账号口令

> 基于ubuntu

### 1.设置最少密码长度限制：至少8个字符
```
sudo apt-get install libpam-cracklib
sudo vim /etc/pam.d/common-password
password        requisite                       pam_cracklib.so retry=3 minlen=8 difok=3
sudo vim /etc/login.defs
PASS_MIN_LEN 8
```

### 2.设置密码复杂度（只对非root用户有效，若使用sudo权限去设置密码，不受限制）
```
sudo apt-get install libpam-pwquality
sudo vim /etc/pam.d/common-password
至少需要一个大写字母：加ucredit=-1
password        requisite                       pam_pwquality.so retry=3 ucredit=-1
至少需要一个小写字母：加lcredit=-1
password        requisite                       pam_pwquality.so retry=3 lcredit=-1
至少需要有一个数字： 加dcredit=-1
password        requisite                       pam_pwquality.so retry=3 dcredit=-1
至少需要一个除数字字母以外的字符： 加ocredit=-1
password        requisite                       pam_pwquality.so retry=3 ocredit=-1
设置最少包含的字符集：minclass=2
password        requisite                       pam_pwquality.so retry=3 minclass=2
自由组合：
password        requisite                       pam_pwquality.so retry=3 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1

```

### 3.设置密码生存周期
编辑/etc/login.defs文件，分别配置如下参数，强制用户每90天更改一次密码，提前七天提醒用户，但只对之后新建用户生效。
```
PASS_MAX_DAYS   90
PASS_MIN_DAYS   0
PASS_WARN_AGE   7
```
对已经存在的用户做更改：sudo chage -M 90 -m 0 -W 7 -I 5 genee
```
sudo chage -M <days> <username>
sudo chage -m <days> <username>
sudo chage -W <days> <username>
sudo chage -I <days> <username>  #密码过期几天后失效
chage -l <username> 查看用户密码配置信息：
```
```
genee@demo:~$ chage -l genee
Last password change                    : Jul 10, 2017
Password expires                    : never
Password inactive                   : never
Account expires                     : never
Minimum number of days between password change      : 0
Maximum number of days between password change      : 99999
Number of days of warning before password expires   : 7
genee@demo:~$ sudo chage -M 90 genee
genee@demo:~$ sudo chage -m 0 genee
genee@demo:~$ sudo chage -W 7 genee
genee@demo:~$ sudo chage -I 5 genee
genee@demo:~$ chage -l genee
Last password change                    : Jul 10, 2017
Password expires                    : Oct 08, 2017
Password inactive                   : Oct 13, 2017
Account expires                     : never
Minimum number of days between password change      : 0
Maximum number of days between password change      : 90
Number of days of warning before password expires   : 7
```
### 4.限制用户su到root
新建用户组wheel
编辑/etc/pam.d/su文件
解除注释或加入如下两行
```
auth       sufficient pam_rootok.so
auth       required   pam_wheel.so group=wheel
```
只能wheel组里的用户能够su

### 5.使用pam锁定多次认证失败用户
编辑/etc/pam.d/common-auth和/etc/pam.d/login文件
加入如下配置：
```
auth    required    pam_tally2.so    deny=3    unlock_time=600 even_deny_root root_unlock_time=1200
```
even_deny_root 也限制root用户；
deny 设置普通用户和root用户连续错误登陆的最大次数，超过最大次数，则锁定该用户
unlock_time 设定普通用户锁定后，多少时间后解锁，单位是秒；
root_unlock_time 设定root用户锁定后，多少时间后解锁，单位是秒；

## 认证授权
### 1.umask设置
编辑/etc/profile文件，加入命令：umask 027
### 2.设置命令行界面超时时间
编辑/etc/profile文件，加入声明变量命令： export TMOUT=1800

## 日志审计
### 1.启用syslog日志审计
创建/var/log/secure、/var/log/cron.log文件,改属主属组分别为syslog adm
编辑/etc/rsyslog.d/50-default.conf文件，更改如下内容：
```
# First some standard log files.  Log by facility.
#
auth,authpriv.*                 /var/log/auth.log
*.*;auth,authpriv.none          -/var/log/syslog
#cron.*                         /var/log/cron.log
#daemon.*                       -/var/log/daemon.log
```
改为：
```
# First some standard log files.  Log by facility.
#
auth.*                          /var/log/auth.log
authpriv.*                      /var/log/secure
*.*;auth,authpriv.none          -/var/log/syslog
cron.*                          /var/log/cron.log
#daemon.*                       -/var/log/daemon.log
```
重启rsyslog服务
增加logrotate配置:
    编辑/etc/logrotate.d/rsyslog文件
    增加/var/log/secure、/var/log/cron.log(一般cron.log已经存在)
### 2.策略配置audit
```sudo apt-get install auditd```
```
sudo vim /etc/audit/audit.rules
...
-w /etc/crontab -p wa -k crontab
-w /etc/hosts -p wa -k hosts
-w /etc/hosts.allow -p wa -k hosts-allow
-w /etc/hosts.deny -p wa -k hosts-deny
-w /etc/fstab -p wa -k fstab
-w /etc/passwd -p wa -k passwd
-w /etc/shadow -p wa -k shadow
-w /etc/group -p wa -k group
-w /etc/gshadow -p wa -k gshadow
-w /etc/ntp.conf -p wa -k ntp
-w /etc/sysctl.conf -p wa -k sysctl
-w /etc/security/limits.conf -p wa -klimits
-w /boot/grub/grub.conf -p wa -k grub
-w /etc/ssh/sshd_config -p wa -k ssh
-w /etc/udev/rules.d/ -p wa -k udev
-w /etc/profile -p wa -k profile
-w /etc/kdump.conf -p wa -k kdump
-w /etc/lvm/lvm.conf -p wa -k lvm
-w /etc/login.defs -p wa -k login-defs
-w /etc/rsyslog.conf -p wa -k rsyslog
-w /etc/sysconfig/i18n -p wa -k i18n
-w /etc/sysconfig/network -p wa -k network
-w /etc/multipath.conf -p wa -k multipath
```
```sudo systemctl restart auditd.service```
## 协议安全
### 1.禁用telnet协议

sudo apt-get install xinetd telnetd
sudo vi /etc/xinetd.d/telnet

```
\# default: on

\# description: The telnet server serves telnet sessions; it uses

\# unencrypted username/password pairs for authentication.

service telnet
{
disable = yes
flags = REUSE
socket_type = stream
wait = no
user = root
server = /usr/sbin/in.telnetd
log_on_failure += USERID
}
​```
```
sudo /etc/init.d/xinetd restart
```


## 其它安全
### 1.配置用户所需最小权限
sudo chmod 600 /etc/shadow

