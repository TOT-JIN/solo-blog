title: LAMP--域名 301 跳转
date: '2017-10-25 10:28:29'
updated: '2017-10-25 10:28:29'
tags: [lamp, 301跳转]
permalink: /articles/2017/10/25/1508898509673.html
---
# LAMP--域名 301 跳转
一个站点可能会有多个域名，而多个域名总得有个主次，例：www.123.com (主)，www.test.com （次）。希望实现不管用哪个域名访问，最终都跳到 [www.123.com](http://www.123.com/) 上。这个行为叫域名跳转，这里的301只是个状态码，跳转除了301外还有302。

```e-bash
[root@localhost ~]# vim /usr/local/apache2/conf/extra/httpd-vhosts.conf
```



在对应的虚拟主机配置文件中加入

```e-bash
   <IfModule mod_rewrite.c>
   RewriteEngine on
   RewriteCond %{HTTP_HOST} ^www.test.com$
   RewriteRule ^/(.*)$ http://www.123.com/$1 [R=301,L]
  </IfModule>
```



如果是多个域名，可以这样设置：

```e-bash
<IfModule mod_rewrite.c>
 RewriteEngine on
 RewriteCond %{HTTP_HOST} ^www.test.com [OR]
 RewriteCond %{HTTP_HOST} ^www.test1.com$
 RewriteRule ^/(.*)$ http://www.123.com/$1 [R=301,L]
</IfModule>
```



或者

```e-bash
<IfModule mod_rewrite.c>
 RewriteEngine on
 RewriteCond %{HTTP_HOST} !^www.123.com$
 RewriteRule ^/(.*)$ http://www.123.com/$1 [R=301,L]
</IfModule>
```



重启 apache 后，在浏览器访问 [www.test.com](http://www.test.com/) 会直接跳到 [www.123.com](http://www.123.com/) 。使用 curl 命令测试一下。

```e-bash
[root@localhost ~]# curl www.test.com -I
HTTP/1.1 301 Moved Permanently
Date: Wed, 18 May 2016 01:46:04 GMT
Server: Apache/2.2.31 (Unix) PHP/5.6.10
Location: http://www.123.com/
Content-Type: text/html; charset=iso-8859-1
```
