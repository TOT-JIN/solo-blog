title: LNMP--nginx 配置静态文件过期时间
date: '2018-02-13 13:14:43'
updated: '2018-02-13 13:14:43'
tags: [lnmp, nginx, 静态文件过期]
permalink: /articles/2018/02/13/1518498883733.html
---
# LNMP--nginx 配置静态文件过期时间
&emsp;&emsp;把指定文件类型不记录日志和该功能一起配置。



```
    location ~ .*\.(gif|jpg|jpeg|png|bmp|swf)$

    {

        expires    30d;

        access_log off;

    }

    location ~ .*\.(js|css)$

    {

        expires    12h;

        access_log off;

    }
```
